# Post-study checkpoint correction

The first completed-run resume validation failed before copying or launching any
process: the historical gates had appended two commands to the build journal,
invalidating its preparation checkpoint. All 528 study processes were already
complete and the final audit passed. No sample was repeated or substituted.

The original identities, build/finished checkpoints, as-run runner and failure log
are preserved under `as-run/`; original nine-line `commands.jsonl` is unchanged.
The first seven lines exactly match the archived build-checkpoint command hash.
They are copied byte-for-byte to `build-commands.jsonl`; the two gate commands
are copied to `gate-commands.jsonl`. The corrected build checkpoint references
the immutable build journal. The runner now uses these separate journals.

Only runner journaling and persistent terminal-invariant handling changed after timing. The identities now
anchor both the as-run runner snapshot and the corrected live runner. C++ driver,
CMake sources, source/library/binary/font identities, fixtures, schedule, index,
correctness output and all raw timings are unchanged. The original identity map
is preserved, rather than representing the corrected runner as the one executed.
A focused regression checks that gate recording leaves the build checkpoint valid.

The corrected runner also preserves geometry/shaping failure stops across resume; a regression verifies no new directory or process is created for such a prior failure. This does not alter the successful schedule or any sample.
