import sys,json
from pathlib import Path
sys.path.insert(0,str(Path('specs/073-rendering-architecture/demonstrator/candidate-scan-continuation').resolve()))
import run as r
w=r.ROOT/'build-ci/073-cache-diagnostic';o=w/'evidence'
with r.recovery.execution_lock(r.ROOT/'build-ci/073-performance-recovery/execution.lock'):
 for arm in ('baseline','retained'):
  raw=o/(arm+'.jsonl');err=o/(arm+'.diagnostics.jsonl')
  cmd=[w/(arm+'-build/runtime-trace'),r.ROOT/'build-ci/073-candidate-runtime-evidence/small-prose-480-64.json','zero','correctness']
  result=r.supervisor.supervise(cmd,raw,err) if not raw.exists() else dict(status='completed',note='Existing diagnostic output retained after journal formatting error')
  r.supervisor.append(o/'commands.jsonl',dict(requestedCommand=list(map(str,cmd)),**result))
  assert result['status']=='completed',result
  rows=[json.loads(x) for x in err.read_text().splitlines()]
  initial=[x for x in rows if x['phase']=='initial']
  assert len(initial)==32
  assert initial[0]['shapeDelta']==1 and initial[0]['cacheEvents']==['missingParagraph','addedParagraph']
  assert all(x['shapeDelta']==0 and x['cacheEvents']==['foundParagraph'] and not x['metadata'] for x in initial[1:])
  print(arm,': initial paragraph 0 miss/shape=1; paragraphs 1–31 hit/shape=0; diagnosis confirmed')
