import sys,json
from pathlib import Path
sys.path.insert(0,str(Path('specs/073-rendering-architecture/demonstrator/candidate-scan-continuation').resolve()))
import run as r
w=r.ROOT/'build-ci/073-cache-regression';o=w/'evidence-v2';o.mkdir()
with r.recovery.execution_lock(r.ROOT/'build-ci/073-performance-recovery/execution.lock'):
 for case in r.fixtures():
  fixture=o/(case['id']+'.json');r.recovery.durable_json(fixture,r.manifest(case))
  for variant in ('zero','padded'):
   raw=o/(case['id']+'-'+variant+'.jsonl')
   result=r.supervisor.supervise([w/'retained-build/runtime-trace',fixture,variant,'correctness'],raw,raw.with_suffix('.stderr'))
   r.supervisor.append(o/'commands.jsonl',result)
   assert result['status']=='completed',result
   for row in r.old.strict_rows(raw):r.validate_lifecycle(row,case['blocks'],True)
 r.gates(w,o)
 print('PASS: 44 real-driver lifecycle fixtures and historical geometry/extent gates')
