
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/baseline-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

000000000045e090 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)>:
  45e090:	48 81 ec 28 02 00 00 	sub    $0x228,%rsp
  45e097:	48 8b 97 80 02 00 00 	mov    0x280(%rdi),%rdx
  45e09e:	48 89 9c 24 10 02 00 	mov    %rbx,0x210(%rsp)
  45e0a5:	00 
  45e0a6:	48 89 fb             	mov    %rdi,%rbx
  45e0a9:	f3 0f 11 44 24 4c    	movss  %xmm0,0x4c(%rsp)
  45e0af:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  45e0b6:	00 00 
  45e0b8:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  45e0bf:	00 
  45e0c0:	48 8b 87 78 02 00 00 	mov    0x278(%rdi),%rax
  45e0c7:	48 39 c2             	cmp    %rax,%rdx
  45e0ca:	0f 84 40 03 00 00    	je     45e410 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x380>
  45e0d0:	66 0f ef c0          	pxor   %xmm0,%xmm0
  45e0d4:	eb 1f                	jmp    45e0f5 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x65>
  45e0d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  45e0dd:	00 00 00 
  45e0e0:	0f 2e 40 1c          	ucomiss 0x1c(%rax),%xmm0
  45e0e4:	7a 17                	jp     45e0fd <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x6d>
  45e0e6:	75 15                	jne    45e0fd <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x6d>
  45e0e8:	48 83 c0 20          	add    $0x20,%rax
  45e0ec:	48 39 d0             	cmp    %rdx,%rax
  45e0ef:	0f 84 1b 03 00 00    	je     45e410 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x380>
  45e0f5:	0f 2e 40 18          	ucomiss 0x18(%rax),%xmm0
  45e0f9:	7a 02                	jp     45e0fd <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x6d>
  45e0fb:	74 e3                	je     45e0e0 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x50>
  45e0fd:	f3 0f 10 4c 24 4c    	movss  0x4c(%rsp),%xmm1
  45e103:	0f 28 05 26 5e 05 00 	movaps 0x55e26(%rip),%xmm0        # 4b3f30 <C.119.3+0x1700>
  45e10a:	b8 ff ff 7f ff       	mov    $0xff7fffff,%eax
  45e10f:	31 c9                	xor    %ecx,%ecx
  45e111:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  45e118:	00 00 
  45e11a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  45e121:	00 
  45e122:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  45e127:	48 89 de             	mov    %rbx,%rsi
  45e12a:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
  45e131:	00 
  45e132:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  45e139:	00 
  45e13a:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  45e141:	00 
  45e142:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  45e149:	00 
  45e14a:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  45e151:	00 
  45e152:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  45e159:	00 
  45e15a:	48 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%rsp)
  45e161:	ff ff 
  45e163:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  45e16a:	00 00 
  45e16c:	48 c7 44 24 68 ff ff 	movq   $0xffffffffffffffff,0x68(%rsp)
  45e173:	ff ff 
  45e175:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  45e17c:	00 00 
  45e17e:	48 c7 44 24 78 ff ff 	movq   $0xffffffffffffffff,0x78(%rsp)
  45e185:	ff ff 
  45e187:	c6 84 24 98 00 00 00 	movb   $0x0,0x98(%rsp)
  45e18e:	00 
  45e18f:	48 c7 84 24 9c 00 00 	movq   $0x0,0x9c(%rsp)
  45e196:	00 00 00 00 00 
  45e19b:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  45e1a2:	00 00 00 00 00 
  45e1a7:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  45e1ae:	00 ff ff ff ff 
  45e1b3:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  45e1ba:	00 00 00 00 00 
  45e1bf:	48 c7 84 24 c0 00 00 	movq   $0xffffffffffffffff,0xc0(%rsp)
  45e1c6:	00 ff ff ff ff 
  45e1cb:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  45e1d2:	00 00 00 00 00 
  45e1d7:	48 c7 84 24 d0 00 00 	movq   $0xffffffffffffffff,0xd0(%rsp)
  45e1de:	00 ff ff ff ff 
  45e1e3:	c6 84 24 f0 00 00 00 	movb   $0x0,0xf0(%rsp)
  45e1ea:	00 
  45e1eb:	48 c7 84 24 f4 00 00 	movq   $0x0,0xf4(%rsp)
  45e1f2:	00 00 00 00 00 
  45e1f7:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  45e1fe:	00 00 00 00 00 
  45e203:	48 c7 84 24 08 01 00 	movq   $0xffffffffffffffff,0x108(%rsp)
  45e20a:	00 ff ff ff ff 
  45e20f:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
  45e216:	00 00 00 00 00 
  45e21b:	48 c7 84 24 18 01 00 	movq   $0xffffffffffffffff,0x118(%rsp)
  45e222:	00 ff ff ff ff 
  45e227:	48 c7 84 24 20 01 00 	movq   $0x0,0x120(%rsp)
  45e22e:	00 00 00 00 00 
  45e233:	48 c7 84 24 28 01 00 	movq   $0xffffffffffffffff,0x128(%rsp)
  45e23a:	00 ff ff ff ff 
  45e23f:	c6 84 24 48 01 00 00 	movb   $0x0,0x148(%rsp)
  45e246:	00 
  45e247:	48 c7 84 24 4c 01 00 	movq   $0x0,0x14c(%rsp)
  45e24e:	00 00 00 00 00 
  45e253:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
  45e25a:	00 00 00 00 00 
  45e25f:	48 c7 84 24 60 01 00 	movq   $0xffffffffffffffff,0x160(%rsp)
  45e266:	00 ff ff ff ff 
  45e26b:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  45e272:	00 
  45e273:	48 8d 44 24 4c       	lea    0x4c(%rsp),%rax
  45e278:	0f 11 84 24 88 01 00 	movups %xmm0,0x188(%rsp)
  45e27f:	00 
  45e280:	66 0f ef c0          	pxor   %xmm0,%xmm0
  45e284:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  45e28b:	00 
  45e28c:	48 8d 05 9d 12 00 00 	lea    0x129d(%rip),%rax        # 45f530 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)>
  45e293:	0f 11 84 24 c8 01 00 	movups %xmm0,0x1c8(%rsp)
  45e29a:	00 
  45e29b:	f3 0f 7e 05 85 e7 0e 	movq   0xee785(%rip),%xmm0        # 54ca28 <vtable for std::_Sp_counted_ptr_inplace<std::unordered_set<int, std::hash<int>, std::equal_to<int>, std::allocator<int> >, std::allocator<void>, (__gnu_cxx::_Lock_policy)2>+0x60>
  45e2a2:	00 
  45e2a3:	66 48 0f 6e f0       	movq   %rax,%xmm6
  45e2a8:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  45e2af:	00 00 00 00 00 
  45e2b4:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
  45e2b8:	48 c7 84 24 70 01 00 	movq   $0xffffffffffffffff,0x170(%rsp)
  45e2bf:	00 ff ff ff ff 
  45e2c4:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
  45e2cb:	00 
  45e2cc:	0f 28 c1             	movaps %xmm1,%xmm0
  45e2cf:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  45e2d6:	00 00 00 00 00 
  45e2db:	48 c7 84 24 80 01 00 	movq   $0xffffffffffffffff,0x180(%rsp)
  45e2e2:	00 ff ff ff ff 
  45e2e7:	c6 84 24 a0 01 00 00 	movb   $0x0,0x1a0(%rsp)
  45e2ee:	00 
  45e2ef:	48 c7 84 24 a4 01 00 	movq   $0x0,0x1a4(%rsp)
  45e2f6:	00 00 00 00 00 
  45e2fb:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  45e302:	00 00 00 00 00 
  45e307:	48 c7 84 24 b0 01 00 	movq   $0x1,0x1b0(%rsp)
  45e30e:	00 01 00 00 00 
  45e313:	66 89 8c 24 ba 01 00 	mov    %cx,0x1ba(%rsp)
  45e31a:	00 
  45e31b:	48 89 9c 24 e0 01 00 	mov    %rbx,0x1e0(%rsp)
  45e322:	00 
  45e323:	e8 38 bc 01 00       	call   479f60 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)>
  45e328:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  45e32f:	00 
  45e330:	48 85 c0             	test   %rax,%rax
  45e333:	74 12                	je     45e347 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x2b7>
  45e335:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
  45e33c:	00 
  45e33d:	ba 03 00 00 00       	mov    $0x3,%edx
  45e342:	48 89 f7             	mov    %rsi,%rdi
  45e345:	ff d0                	call   *%rax
  45e347:	f3 0f 10 84 24 c0 01 	movss  0x1c0(%rsp),%xmm0
  45e34e:	00 00 
  45e350:	f3 0f 10 54 24 4c    	movss  0x4c(%rsp),%xmm2
  45e356:	f3 0f 10 8c 24 c4 01 	movss  0x1c4(%rsp),%xmm1
  45e35d:	00 00 
  45e35f:	8b 83 10 04 00 00    	mov    0x410(%rbx),%eax
  45e365:	0f 14 c8             	unpcklps %xmm0,%xmm1
  45e368:	f3 0f 10 84 24 bc 01 	movss  0x1bc(%rsp),%xmm0
  45e36f:	00 00 
  45e371:	0f 14 c2             	unpcklps %xmm2,%xmm0
  45e374:	0f 16 c1             	movlhps %xmm1,%xmm0
  45e377:	0f 11 83 48 02 00 00 	movups %xmm0,0x248(%rbx)
  45e37e:	85 c0                	test   %eax,%eax
  45e380:	0f 84 0a 04 00 00    	je     45e790 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x700>
  45e386:	48 8b 83 08 04 00 00 	mov    0x408(%rbx),%rax
  45e38d:	f3 0f 10 98 a8 00 00 	movss  0xa8(%rax),%xmm3
  45e394:	00 
  45e395:	f3 0f 10 88 b0 00 00 	movss  0xb0(%rax),%xmm1
  45e39c:	00 
  45e39d:	f3 0f 10 90 ac 00 00 	movss  0xac(%rax),%xmm2
  45e3a4:	00 
  45e3a5:	0f 28 c3             	movaps %xmm3,%xmm0
  45e3a8:	0f 14 c1             	unpcklps %xmm1,%xmm0
  45e3ab:	f3 0f 59 0d 51 8c 04 	mulss  0x48c51(%rip),%xmm1        # 4a7004 <_IO_stdin_used+0x4>
  45e3b2:	00 
  45e3b3:	f3 0f 5c d3          	subss  %xmm3,%xmm2
  45e3b7:	f3 0f 7e c0          	movq   %xmm0,%xmm0
  45e3bb:	0f b6 84 24 bb 01 00 	movzbl 0x1bb(%rsp),%eax
  45e3c2:	00 
  45e3c3:	88 83 5c 02 00 00    	mov    %al,0x25c(%rbx)
  45e3c9:	0f 14 ca             	unpcklps %xmm2,%xmm1
  45e3cc:	f3 0f 7e c9          	movq   %xmm1,%xmm1
  45e3d0:	0f 28 d1             	movaps %xmm1,%xmm2
  45e3d3:	0f 5c d0             	subps  %xmm0,%xmm2
  45e3d6:	0f 58 c1             	addps  %xmm1,%xmm0
  45e3d9:	f3 0f 10 c2          	movss  %xmm2,%xmm0
  45e3dd:	0f 13 83 40 02 00 00 	movlps %xmm0,0x240(%rbx)
  45e3e4:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  45e3eb:	00 
  45e3ec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
  45e3f3:	00 00 
  45e3f5:	0f 85 a6 04 00 00    	jne    45e8a1 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x811>
  45e3fb:	48 8b 9c 24 10 02 00 	mov    0x210(%rsp),%rbx
  45e402:	00 
  45e403:	48 81 c4 28 02 00 00 	add    $0x228,%rsp
  45e40a:	c3                   	ret
  45e40b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  45e410:	f3 0f 10 4c 24 4c    	movss  0x4c(%rsp),%xmm1
  45e416:	80 bb 80 04 00 00 00 	cmpb   $0x0,0x480(%rbx)
  45e41d:	0f 85 e0 fc ff ff    	jne    45e103 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x73>
  45e423:	80 bb 81 04 00 00 00 	cmpb   $0x0,0x481(%rbx)
  45e42a:	0f 85 d3 fc ff ff    	jne    45e103 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x73>
  45e430:	83 bb 40 03 00 00 01 	cmpl   $0x1,0x340(%rbx)
  45e437:	0f 85 c6 fc ff ff    	jne    45e103 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x73>
  45e43d:	83 bb 60 03 00 00 01 	cmpl   $0x1,0x360(%rbx)
  45e444:	0f 85 b9 fc ff ff    	jne    45e103 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x73>
  45e44a:	4c 8b 8b 58 03 00 00 	mov    0x358(%rbx),%r9
  45e451:	f3 41 0f 10 51 50    	movss  0x50(%r9),%xmm2
  45e457:	0f 2f ca             	comiss %xmm2,%xmm1
  45e45a:	0f 82 a3 fc ff ff    	jb     45e103 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x73>
  45e460:	48 8b 83 48 03 00 00 	mov    0x348(%rbx),%rax
  45e467:	4c 89 b4 24 18 02 00 	mov    %r14,0x218(%rsp)
  45e46e:	00 
  45e46f:	31 f6                	xor    %esi,%esi
  45e471:	48 8b 93 88 04 00 00 	mov    0x488(%rbx),%rdx
  45e478:	4c 89 bc 24 20 02 00 	mov    %r15,0x220(%rsp)
  45e47f:	00 
  45e480:	8b 00                	mov    (%rax),%eax
  45e482:	c7 44 24 64 00 00 00 	movl   $0x0,0x64(%rsp)
  45e489:	00 
  45e48a:	49 89 d7             	mov    %rdx,%r15
  45e48d:	48 89 c7             	mov    %rax,%rdi
  45e490:	31 c0                	xor    %eax,%eax
  45e492:	49 89 c6             	mov    %rax,%r14
  45e495:	0f b6 43 38          	movzbl 0x38(%rbx),%eax
  45e499:	88 44 24 68          	mov    %al,0x68(%rsp)
  45e49d:	84 c0                	test   %al,%al
  45e49f:	0f 85 6e 03 00 00    	jne    45e813 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x783>
  45e4a5:	f3 41 0f 10 89 d8 00 	movss  0xd8(%r9),%xmm1
  45e4ac:	00 00 
  45e4ae:	f3 0f 10 3d 7e 5a 05 	movss  0x55a7e(%rip),%xmm7        # 4b3f34 <C.119.3+0x1704>
  45e4b5:	00 
  45e4b6:	66 0f ef ed          	pxor   %xmm5,%xmm5
  45e4ba:	f3 41 0f 10 99 e0 00 	movss  0xe0(%r9),%xmm3
  45e4c1:	00 00 
  45e4c3:	f3 0f 10 25 65 5a 05 	movss  0x55a65(%rip),%xmm4        # 4b3f30 <C.119.3+0x1700>
  45e4ca:	00 
  45e4cb:	f3 41 0f 10 81 dc 00 	movss  0xdc(%r9),%xmm0
  45e4d2:	00 00 
  45e4d4:	0f 28 f7             	movaps %xmm7,%xmm6
  45e4d7:	f3 0f 58 d9          	addss  %xmm1,%xmm3
  45e4db:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  45e4df:	f3 0f c2 f3 01       	cmpltss %xmm3,%xmm6
  45e4e4:	f3 0f 5d c4          	minss  %xmm4,%xmm0
  45e4e8:	0f 54 de             	andps  %xmm6,%xmm3
  45e4eb:	0f 55 f7             	andnps %xmm7,%xmm6
  45e4ee:	0f 56 f3             	orps   %xmm3,%xmm6
  45e4f1:	f3 41 0f 10 99 e4 00 	movss  0xe4(%r9),%xmm3
  45e4f8:	00 00 
  45e4fa:	f3 0f 5f dd          	maxss  %xmm5,%xmm3
  45e4fe:	f3 41 0f 10 a9 98 00 	movss  0x98(%r9),%xmm5
  45e505:	00 00 
  45e507:	f3 0f 58 e9          	addss  %xmm1,%xmm5
  45e50b:	f3 41 0f 58 89 9c 00 	addss  0x9c(%r9),%xmm1
  45e512:	00 00 
  45e514:	f3 0f 5d ec          	minss  %xmm4,%xmm5
  45e518:	0f 28 e7             	movaps %xmm7,%xmm4
  45e51b:	f3 0f c2 e1 01       	cmpltss %xmm1,%xmm4
  45e520:	0f 54 cc             	andps  %xmm4,%xmm1
  45e523:	0f 55 e7             	andnps %xmm7,%xmm4
  45e526:	66 0f ef ff          	pxor   %xmm7,%xmm7
  45e52a:	0f 56 e1             	orps   %xmm1,%xmm4
  45e52d:	f3 41 0f 10 89 a4 00 	movss  0xa4(%r9),%xmm1
  45e534:	00 00 
  45e536:	f3 0f 5f cf          	maxss  %xmm7,%xmm1
  45e53a:	f3 0f 11 4c 24 64    	movss  %xmm1,0x64(%rsp)
  45e540:	8b 93 2c 02 00 00    	mov    0x22c(%rbx),%edx
  45e546:	f6 c2 01             	test   $0x1,%dl
  45e549:	74 03                	je     45e54e <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x4be>
  45e54b:	0f 28 c5             	movaps %xmm5,%xmm0
  45e54e:	83 e2 02             	and    $0x2,%edx
  45e551:	74 03                	je     45e556 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x4c6>
  45e553:	0f 28 f4             	movaps %xmm4,%xmm6
  45e556:	80 7b 39 00          	cmpb   $0x0,0x39(%rbx)
  45e55a:	0f 85 8d 02 00 00    	jne    45e7ed <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x75d>
  45e560:	0f 14 c6             	unpcklps %xmm6,%xmm0
  45e563:	0f 14 dd             	unpcklps %xmm5,%xmm3
  45e566:	0f 28 c8             	movaps %xmm0,%xmm1
  45e569:	0f 16 cb             	movlhps %xmm3,%xmm1
  45e56c:	4c 63 83 70 03 00 00 	movslq 0x370(%rbx),%r8
  45e573:	4c 8b 93 68 03 00 00 	mov    0x368(%rbx),%r10
  45e57a:	49 8d 48 ff          	lea    -0x1(%r8),%rcx
  45e57e:	4d 89 c3             	mov    %r8,%r11
  45e581:	41 39 c8             	cmp    %ecx,%r8d
  45e584:	0f 8e c6 92 bd ff    	jle    37850 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float) [clone .cold]>
  45e58a:	85 c9                	test   %ecx,%ecx
  45e58c:	0f 88 be 92 bd ff    	js     37850 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float) [clone .cold]>
  45e592:	48 89 c8             	mov    %rcx,%rax
  45e595:	0f 28 da             	movaps %xmm2,%xmm3
  45e598:	48 c1 e0 06          	shl    $0x6,%rax
  45e59c:	4c 01 d0             	add    %r10,%rax
  45e59f:	80 78 38 00          	cmpb   $0x0,0x38(%rax)
  45e5a3:	74 2f                	je     45e5d4 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x544>
  45e5a5:	49 89 c8             	mov    %rcx,%r8
  45e5a8:	eb 20                	jmp    45e5ca <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x53a>
  45e5aa:	49 8d 50 ff          	lea    -0x1(%r8),%rdx
  45e5ae:	41 39 d3             	cmp    %edx,%r11d
  45e5b1:	0f 8e 99 92 bd ff    	jle    37850 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float) [clone .cold]>
  45e5b7:	48 89 d0             	mov    %rdx,%rax
  45e5ba:	48 c1 e0 06          	shl    $0x6,%rax
  45e5be:	4c 01 d0             	add    %r10,%rax
  45e5c1:	80 78 38 00          	cmpb   $0x0,0x38(%rax)
  45e5c5:	74 0d                	je     45e5d4 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x544>
  45e5c7:	49 89 d0             	mov    %rdx,%r8
  45e5ca:	f3 0f 5c 58 30       	subss  0x30(%rax),%xmm3
  45e5cf:	4d 85 c0             	test   %r8,%r8
  45e5d2:	75 d6                	jne    45e5aa <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x51a>
  45e5d4:	0f 28 c1             	movaps %xmm1,%xmm0
  45e5d7:	66 0f ef ed          	pxor   %xmm5,%xmm5
  45e5db:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  45e5e0:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
  45e5e4:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  45e5e8:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  45e5ec:	f2 0f 5c c5          	subsd  %xmm5,%xmm0
  45e5f0:	0f 28 e9             	movaps %xmm1,%xmm5
  45e5f3:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
  45e5f8:	0f 15 e9             	unpckhps %xmm1,%xmm5
  45e5fb:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  45e600:	f3 0f 5a ed          	cvtss2sd %xmm5,%xmm5
  45e604:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
  45e608:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  45e60d:	f3 0f 11 64 24 48    	movss  %xmm4,0x48(%rsp)
  45e613:	0f 29 0c 24          	movaps %xmm1,(%rsp)
  45e617:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  45e61c:	f3 0f 11 5c 24 1c    	movss  %xmm3,0x1c(%rsp)
  45e622:	f3 0f 11 54 24 18    	movss  %xmm2,0x18(%rsp)
  45e628:	e8 63 07 bd ff       	call   2ed90 <round@plt>
  45e62d:	0f 28 0c 24          	movaps (%rsp),%xmm1
  45e631:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  45e636:	31 c0                	xor    %eax,%eax
  45e638:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  45e63d:	66 0f ef ed          	pxor   %xmm5,%xmm5
  45e641:	48 83 ec 20          	sub    $0x20,%rsp
  45e645:	45 31 d2             	xor    %r10d,%r10d
  45e648:	f3 0f 10 64 24 68    	movss  0x68(%rsp),%xmm4
  45e64e:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  45e653:	f2 0f 5a e8          	cvtsd2ss %xmm0,%xmm5
  45e657:	48 89 f1             	mov    %rsi,%rcx
  45e65a:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  45e65f:	4c 8b 5c 24 60       	mov    0x60(%rsp),%r11
  45e664:	49 89 f8             	mov    %rdi,%r8
  45e667:	f3 0f 11 a4 24 80 00 	movss  %xmm4,0x80(%rsp)
  45e66e:	00 00 
  45e670:	f3 0f 6f 44 24 7c    	movdqu 0x7c(%rsp),%xmm0
  45e676:	0f 11 0c 24          	movups %xmm1,(%rsp)
  45e67a:	0f 11 44 24 0c       	movups %xmm0,0xc(%rsp)
  45e67f:	66 0f ef c0          	pxor   %xmm0,%xmm0
  45e683:	41 53                	push   %r11
  45e685:	41 52                	push   %r10
  45e687:	52                   	push   %rdx
  45e688:	4c 89 fa             	mov    %r15,%rdx
  45e68b:	50                   	push   %rax
  45e68c:	57                   	push   %rdi
  45e68d:	48 89 df             	mov    %rbx,%rdi
  45e690:	56                   	push   %rsi
  45e691:	f3 0f 10 5c 24 6c    	movss  0x6c(%rsp),%xmm3
  45e697:	4c 89 f6             	mov    %r14,%rsi
  45e69a:	f3 0f 10 54 24 68    	movss  0x68(%rsp),%xmm2
  45e6a0:	0f 28 cb             	movaps %xmm3,%xmm1
  45e6a3:	f3 0f 11 5c 24 68    	movss  %xmm3,0x68(%rsp)
  45e6a9:	0f 14 cd             	unpcklps %xmm5,%xmm1
  45e6ac:	f3 0f 11 6c 24 50    	movss  %xmm5,0x50(%rsp)
  45e6b2:	e8 b9 f0 ff ff       	call   45d770 <skia::textlayout::ParagraphImpl::addLine(SkPoint, SkPoint, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, skia::textlayout::InternalLineMetrics)>
  45e6b7:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  45e6bc:	f3 0f 10 5c 24 68    	movss  0x68(%rsp),%xmm3
  45e6c2:	48 83 c4 50          	add    $0x50,%rsp
  45e6c6:	f3 0f 10 2c 24       	movss  (%rsp),%xmm5
  45e6cb:	0f 28 c3             	movaps %xmm3,%xmm0
  45e6ce:	f3 41 0f 10 49 50    	movss  0x50(%r9),%xmm1
  45e6d4:	f3 0f 5c c3          	subss  %xmm3,%xmm0
  45e6d8:	0f 2e c0             	ucomiss %xmm0,%xmm0
  45e6db:	0f 28 c3             	movaps %xmm3,%xmm0
  45e6de:	7a 1c                	jp     45e6fc <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x66c>
  45e6e0:	0f 54 05 49 43 05 00 	andps  0x54349(%rip),%xmm0        # 4b2a30 <C.119.3+0x200>
  45e6e7:	0f 28 d1             	movaps %xmm1,%xmm2
  45e6ea:	f3 0f c2 05 4d 89 04 	cmpless 0x4894d(%rip),%xmm0        # 4a7040 <_IO_stdin_used+0x40>
  45e6f1:	00 02 
  45e6f3:	0f 54 d0             	andps  %xmm0,%xmm2
  45e6f6:	0f 55 c3             	andnps %xmm3,%xmm0
  45e6f9:	0f 56 c2             	orps   %xmm2,%xmm0
  45e6fc:	f3 0f 11 83 58 02 00 	movss  %xmm0,0x258(%rbx)
  45e703:	00 
  45e704:	f3 0f 10 44 24 4c    	movss  0x4c(%rsp),%xmm0
  45e70a:	8b 93 10 04 00 00    	mov    0x410(%rbx),%edx
  45e710:	0f 14 cb             	unpcklps %xmm3,%xmm1
  45e713:	0f 14 e8             	unpcklps %xmm0,%xmm5
  45e716:	0f 16 e9             	movlhps %xmm1,%xmm5
  45e719:	0f 11 ab 48 02 00 00 	movups %xmm5,0x248(%rbx)
  45e720:	85 d2                	test   %edx,%edx
  45e722:	0f 85 93 00 00 00    	jne    45e7bb <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x72b>
  45e728:	f3 0f 10 9b 30 04 00 	movss  0x430(%rbx),%xmm3
  45e72f:	00 
  45e730:	f3 0f 10 8b 38 04 00 	movss  0x438(%rbx),%xmm1
  45e737:	00 
  45e738:	f3 0f 10 93 34 04 00 	movss  0x434(%rbx),%xmm2
  45e73f:	00 
  45e740:	0f 28 c3             	movaps %xmm3,%xmm0
  45e743:	0f 14 c1             	unpcklps %xmm1,%xmm0
  45e746:	f3 0f 59 0d b6 88 04 	mulss  0x488b6(%rip),%xmm1        # 4a7004 <_IO_stdin_used+0x4>
  45e74d:	00 
  45e74e:	f3 0f 5c d3          	subss  %xmm3,%xmm2
  45e752:	f3 0f 7e c0          	movq   %xmm0,%xmm0
  45e756:	c6 83 5c 02 00 00 00 	movb   $0x0,0x25c(%rbx)
  45e75d:	4c 8b b4 24 18 02 00 	mov    0x218(%rsp),%r14
  45e764:	00 
  45e765:	4c 8b bc 24 20 02 00 	mov    0x220(%rsp),%r15
  45e76c:	00 
  45e76d:	0f 14 ca             	unpcklps %xmm2,%xmm1
  45e770:	f3 0f 7e c9          	movq   %xmm1,%xmm1
  45e774:	0f 28 d1             	movaps %xmm1,%xmm2
  45e777:	0f 5c d0             	subps  %xmm0,%xmm2
  45e77a:	0f 58 c1             	addps  %xmm1,%xmm0
  45e77d:	f3 0f 10 c2          	movss  %xmm2,%xmm0
  45e781:	0f 13 83 40 02 00 00 	movlps %xmm0,0x240(%rbx)
  45e788:	e9 57 fc ff ff       	jmp    45e3e4 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x354>
  45e78d:	0f 1f 00             	nopl   (%rax)
  45e790:	f3 0f 10 9b 30 04 00 	movss  0x430(%rbx),%xmm3
  45e797:	00 
  45e798:	f3 0f 10 8b 38 04 00 	movss  0x438(%rbx),%xmm1
  45e79f:	00 
  45e7a0:	f3 0f 10 93 34 04 00 	movss  0x434(%rbx),%xmm2
  45e7a7:	00 
  45e7a8:	0f 28 c3             	movaps %xmm3,%xmm0
  45e7ab:	0f 14 c1             	unpcklps %xmm1,%xmm0
  45e7ae:	f3 0f 59 0d 4e 88 04 	mulss  0x4884e(%rip),%xmm1        # 4a7004 <_IO_stdin_used+0x4>
  45e7b5:	00 
  45e7b6:	e9 f8 fb ff ff       	jmp    45e3b3 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x323>
  45e7bb:	48 8b 83 08 04 00 00 	mov    0x408(%rbx),%rax
  45e7c2:	f3 0f 10 98 a8 00 00 	movss  0xa8(%rax),%xmm3
  45e7c9:	00 
  45e7ca:	f3 0f 10 88 b0 00 00 	movss  0xb0(%rax),%xmm1
  45e7d1:	00 
  45e7d2:	f3 0f 10 90 ac 00 00 	movss  0xac(%rax),%xmm2
  45e7d9:	00 
  45e7da:	0f 28 c3             	movaps %xmm3,%xmm0
  45e7dd:	0f 14 c1             	unpcklps %xmm1,%xmm0
  45e7e0:	f3 0f 59 0d 1c 88 04 	mulss  0x4881c(%rip),%xmm1        # 4a7004 <_IO_stdin_used+0x4>
  45e7e7:	00 
  45e7e8:	e9 61 ff ff ff       	jmp    45e74e <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x6be>
  45e7ed:	0f 10 8b 4c 04 00 00 	movups 0x44c(%rbx),%xmm1
  45e7f4:	f3 0f 10 bb 60 04 00 	movss  0x460(%rbx),%xmm7
  45e7fb:	00 
  45e7fc:	84 c0                	test   %al,%al
  45e7fe:	74 32                	je     45e832 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x7a2>
  45e800:	f3 0f 10 a3 5c 04 00 	movss  0x45c(%rbx),%xmm4
  45e807:	00 
  45e808:	f3 0f 11 7c 24 64    	movss  %xmm7,0x64(%rsp)
  45e80e:	e9 59 fd ff ff       	jmp    45e56c <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x4dc>
  45e813:	f3 0f 10 25 19 57 05 	movss  0x55719(%rip),%xmm4        # 4b3f34 <C.119.3+0x1704>
  45e81a:	00 
  45e81b:	f3 0f 10 2d 0d 57 05 	movss  0x5570d(%rip),%xmm5        # 4b3f30 <C.119.3+0x1700>
  45e822:	00 
  45e823:	66 0f ef db          	pxor   %xmm3,%xmm3
  45e827:	0f 28 f4             	movaps %xmm4,%xmm6
  45e82a:	0f 28 c5             	movaps %xmm5,%xmm0
  45e82d:	e9 0e fd ff ff       	jmp    45e540 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x4b0>
  45e832:	44 0f 28 d9          	movaps %xmm1,%xmm11
  45e836:	44 0f 28 c1          	movaps %xmm1,%xmm8
  45e83a:	44 0f 28 c9          	movaps %xmm1,%xmm9
  45e83e:	f3 44 0f 10 25 bd 87 	movss  0x487bd(%rip),%xmm12        # 4a7004 <_IO_stdin_used+0x4>
  45e845:	04 00 
  45e847:	44 0f 15 d9          	unpckhps %xmm1,%xmm11
  45e84b:	44 0f c6 c9 55       	shufps $0x55,%xmm1,%xmm9
  45e850:	0f c6 c9 ff          	shufps $0xff,%xmm1,%xmm1
  45e854:	f3 45 0f 59 dc       	mulss  %xmm12,%xmm11
  45e859:	f3 41 0f 59 fc       	mulss  %xmm12,%xmm7
  45e85e:	f3 45 0f 5c c3       	subss  %xmm11,%xmm8
  45e863:	f3 45 0f 58 cb       	addss  %xmm11,%xmm9
  45e868:	f3 0f 5c cf          	subss  %xmm7,%xmm1
  45e86c:	f3 0f 58 bb 5c 04 00 	addss  0x45c(%rbx),%xmm7
  45e873:	00 
  45e874:	f3 44 0f 5f ce       	maxss  %xmm6,%xmm9
  45e879:	44 0f 28 d9          	movaps %xmm1,%xmm11
  45e87d:	41 0f 28 c8          	movaps %xmm8,%xmm1
  45e881:	f3 0f 5f fc          	maxss  %xmm4,%xmm7
  45e885:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  45e889:	f3 44 0f 5d dd       	minss  %xmm5,%xmm11
  45e88e:	0f 28 e7             	movaps %xmm7,%xmm4
  45e891:	41 0f 14 db          	unpcklps %xmm11,%xmm3
  45e895:	41 0f 14 c9          	unpcklps %xmm9,%xmm1
  45e899:	0f 16 cb             	movlhps %xmm3,%xmm1
  45e89c:	e9 cb fc ff ff       	jmp    45e56c <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)+0x4dc>
  45e8a1:	4c 89 b4 24 18 02 00 	mov    %r14,0x218(%rsp)
  45e8a8:	00 
  45e8a9:	4c 89 bc 24 20 02 00 	mov    %r15,0x220(%rsp)
  45e8b0:	00 
  45e8b1:	e8 2a fb bc ff       	call   2e3e0 <__stack_chk_fail@plt>
