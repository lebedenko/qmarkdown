
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/retained-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000037928 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]>:
   37928:	e8 93 76 ff ff       	call   2efc0 <std::__throw_bad_function_call()@plt>
   3792d:	48 8d 3d 41 fc 46 00 	lea    0x46fc41(%rip),%rdi        # 4a7575 <_IO_stdin_used+0x575>
   37934:	e8 87 6f ff ff       	call   2e8c0 <std::__throw_length_error(char const*)@plt>
   37939:	48 8d 3d 1e 00 47 00 	lea    0x47001e(%rip),%rdi        # 4a795e <_IO_stdin_used+0x95e>
   37940:	e8 7b 6f ff ff       	call   2e8c0 <std::__throw_length_error(char const*)@plt>
   37945:	0f 0b                	ud2
