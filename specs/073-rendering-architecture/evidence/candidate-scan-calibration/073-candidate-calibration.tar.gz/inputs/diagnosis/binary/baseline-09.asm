
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/baseline-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

000000000045f530 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)>:
  45f530:	41 54                	push   %r12
  45f532:	55                   	push   %rbp
  45f533:	48 89 fd             	mov    %rdi,%rbp
  45f536:	48 89 cf             	mov    %rcx,%rdi
  45f539:	53                   	push   %rbx
  45f53a:	48 83 ec 70          	sub    $0x70,%rsp
  45f53e:	4c 8b 1e             	mov    (%rsi),%r11
  45f541:	4c 8b 56 08          	mov    0x8(%rsi),%r10
  45f545:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  45f54c:	00 00 
  45f54e:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  45f553:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  45f55a:	00 
  45f55b:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  45f562:	00 
  45f563:	f3 0f 6f 0f          	movdqu (%rdi),%xmm1
  45f567:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  45f56e:	00 
  45f56f:	f3 41 0f 6f 18       	movdqu (%r8),%xmm3
  45f574:	44 0f b6 21          	movzbl (%rcx),%r12d
  45f578:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  45f57f:	00 
  45f580:	f3 0f 7e 06          	movq   (%rsi),%xmm0
  45f584:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
  45f588:	4c 89 de             	mov    %r11,%rsi
  45f58b:	f3 0f 10 11          	movss  (%rcx),%xmm2
  45f58f:	f3 41 0f 6f 21       	movdqu (%r9),%xmm4
  45f594:	48 8b 0a             	mov    (%rdx),%rcx
  45f597:	f3 0f 6f 28          	movdqu (%rax),%xmm5
  45f59b:	f3 0f 11 54 24 5c    	movss  %xmm2,0x5c(%rsp)
  45f5a1:	0f 11 6c 24 30       	movups %xmm5,0x30(%rsp)
  45f5a6:	f3 0f 6f 68 0c       	movdqu 0xc(%rax),%xmm5
  45f5ab:	0f 11 64 24 20       	movups %xmm4,0x20(%rsp)
  45f5b0:	0f 11 6c 24 3c       	movups %xmm5,0x3c(%rsp)
  45f5b5:	0f 11 5c 24 10       	movups %xmm3,0x10(%rsp)
  45f5ba:	0f 11 0c 24          	movups %xmm1,(%rsp)
  45f5be:	4c 8b 42 08          	mov    0x8(%rdx),%r8
  45f5c2:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  45f5c9:	00 
  45f5ca:	4c 89 d2             	mov    %r10,%rdx
  45f5cd:	f3 0f 7e 08          	movq   (%rax),%xmm1
  45f5d1:	e8 9a e1 ff ff       	call   45d770 <skia::textlayout::ParagraphImpl::addLine(SkPoint, SkPoint, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, skia::textlayout::InternalLineMetrics)>
  45f5d6:	48 83 c4 50          	add    $0x50,%rsp
  45f5da:	45 84 e4             	test   %r12b,%r12b
  45f5dd:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
  45f5e3:	48 89 c3             	mov    %rax,%rbx
  45f5e6:	0f 85 a4 00 00 00    	jne    45f690 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0x160>
  45f5ec:	48 8b 45 00          	mov    0x0(%rbp),%rax
  45f5f0:	80 b8 35 02 00 00 00 	cmpb   $0x0,0x235(%rax)
  45f5f7:	0f 85 dc 00 00 00    	jne    45f6d9 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0x1a9>
  45f5fd:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
  45f604:	f3 0f 10 83 80 00 00 	movss  0x80(%rbx),%xmm0
  45f60b:	00 
  45f60c:	66 0f ef c9          	pxor   %xmm1,%xmm1
  45f610:	48 85 d2             	test   %rdx,%rdx
  45f613:	74 05                	je     45f61a <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0xea>
  45f615:	f3 0f 10 4a 50       	movss  0x50(%rdx),%xmm1
  45f61a:	48 8b 93 a0 00 00 00 	mov    0xa0(%rbx),%rdx
  45f621:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  45f625:	66 0f ef c9          	pxor   %xmm1,%xmm1
  45f629:	48 85 d2             	test   %rdx,%rdx
  45f62c:	74 05                	je     45f633 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0x103>
  45f62e:	f3 0f 10 4a 50       	movss  0x50(%rdx),%xmm1
  45f633:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  45f637:	0f 28 c8             	movaps %xmm0,%xmm1
  45f63a:	f3 0f 5c c8          	subss  %xmm0,%xmm1
  45f63e:	0f 2e c9             	ucomiss %xmm1,%xmm1
  45f641:	7a 1c                	jp     45f65f <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0x12f>
  45f643:	0f 28 c8             	movaps %xmm0,%xmm1
  45f646:	0f 54 0d e3 33 05 00 	andps  0x533e3(%rip),%xmm1        # 4b2a30 <C.119.3+0x200>
  45f64d:	f3 0f c2 0d ea 79 04 	cmpnless 0x479ea(%rip),%xmm1        # 4a7040 <_IO_stdin_used+0x40>
  45f654:	00 06 
  45f656:	0f 54 c1             	andps  %xmm1,%xmm0
  45f659:	0f 55 ca             	andnps %xmm2,%xmm1
  45f65c:	0f 56 c1             	orps   %xmm1,%xmm0
  45f65f:	f3 0f 10 90 58 02 00 	movss  0x258(%rax),%xmm2
  45f666:	00 
  45f667:	f3 0f 5f c2          	maxss  %xmm2,%xmm0
  45f66b:	f3 0f 11 80 58 02 00 	movss  %xmm0,0x258(%rax)
  45f672:	00 
  45f673:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  45f678:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
  45f67f:	00 00 
  45f681:	75 73                	jne    45f6f6 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0x1c6>
  45f683:	48 83 c4 20          	add    $0x20,%rsp
  45f687:	5b                   	pop    %rbx
  45f688:	5d                   	pop    %rbp
  45f689:	41 5c                	pop    %r12
  45f68b:	c3                   	ret
  45f68c:	0f 1f 40 00          	nopl   0x0(%rax)
  45f690:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  45f694:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  45f699:	e8 b2 fc ff ff       	call   45f350 <skia::textlayout::ParagraphImpl::getEllipsis() const>
  45f69e:	48 8b 45 08          	mov    0x8(%rbp),%rax
  45f6a2:	ba 01 00 00 00       	mov    $0x1,%edx
  45f6a7:	48 89 df             	mov    %rbx,%rdi
  45f6aa:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  45f6af:	f3 0f 10 00          	movss  (%rax),%xmm0
  45f6b3:	e8 78 d5 00 00       	call   46cc30 <skia::textlayout::TextLine::createEllipsis(float, SkString const&, bool)>
  45f6b8:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  45f6bd:	e8 ce 07 c0 ff       	call   5fe90 <SkString::~SkString()>
  45f6c2:	48 8b 45 00          	mov    0x0(%rbp),%rax
  45f6c6:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
  45f6cc:	80 b8 35 02 00 00 00 	cmpb   $0x0,0x235(%rax)
  45f6d3:	0f 84 24 ff ff ff    	je     45f5fd <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0xcd>
  45f6d9:	48 89 df             	mov    %rbx,%rdi
  45f6dc:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
  45f6e2:	e8 19 db 00 00       	call   46d200 <skia::textlayout::TextLine::createSoftHyphen()>
  45f6e7:	48 8b 45 00          	mov    0x0(%rbp),%rax
  45f6eb:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
  45f6f1:	e9 07 ff ff ff       	jmp    45f5fd <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_invoke(std::_Any_data const&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, skia::textlayout::SkRange<unsigned long>&&, float&&, unsigned long&&, unsigned long&&, SkPoint&&, SkPoint&&, skia::textlayout::InternalLineMetrics&&, bool&&)+0xcd>
  45f6f6:	e8 e5 ec bc ff       	call   2e3e0 <__stack_chk_fail@plt>
