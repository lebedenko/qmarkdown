
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/baseline-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000453370 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)>:
  453370:	83 fa 01             	cmp    $0x1,%edx
  453373:	74 1b                	je     453390 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)+0x20>
  453375:	83 fa 02             	cmp    $0x2,%edx
  453378:	74 36                	je     4533b0 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)+0x40>
  45337a:	83 fa 03             	cmp    $0x3,%edx
  45337d:	74 04                	je     453383 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)+0x13>
  45337f:	85 d2                	test   %edx,%edx
  453381:	74 1d                	je     4533a0 <std::_Function_handler<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool), skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)::{lambda(skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)#1}>::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)+0x30>
  453383:	31 c0                	xor    %eax,%eax
  453385:	c3                   	ret
  453386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  45338d:	00 00 00 
  453390:	48 89 37             	mov    %rsi,(%rdi)
  453393:	31 c0                	xor    %eax,%eax
  453395:	c3                   	ret
  453396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  45339d:	00 00 00 
  4533a0:	48 c7 07 00 00 00 00 	movq   $0x0,(%rdi)
  4533a7:	31 c0                	xor    %eax,%eax
  4533a9:	c3                   	ret
  4533aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  4533b0:	f3 0f 6f 06          	movdqu (%rsi),%xmm0
  4533b4:	31 c0                	xor    %eax,%eax
  4533b6:	0f 11 07             	movups %xmm0,(%rdi)
  4533b9:	c3                   	ret
