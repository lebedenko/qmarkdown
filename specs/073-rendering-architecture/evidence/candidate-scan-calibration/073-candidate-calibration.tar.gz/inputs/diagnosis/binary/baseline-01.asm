
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/baseline-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000037928 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]>:
   37928:	0f 0b                	ud2
   3792a:	e8 91 76 ff ff       	call   2efc0 <std::__throw_bad_function_call()@plt>
