
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/baseline-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000037850 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float) [clone .cold]>:
   37850:	0f 0b                	ud2
