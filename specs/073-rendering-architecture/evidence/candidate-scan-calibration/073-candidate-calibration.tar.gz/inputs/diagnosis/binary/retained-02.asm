
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/retained-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

000000000045b310 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)>:
  45b310:	53                   	push   %rbx
  45b311:	48 89 fb             	mov    %rdi,%rbx
  45b314:	48 83 ec 10          	sub    $0x10,%rsp
  45b318:	f3 0f 6f 06          	movdqu (%rsi),%xmm0
  45b31c:	4c 8b 93 78 02 00 00 	mov    0x278(%rbx),%r10
  45b323:	48 8b 8b 80 02 00 00 	mov    0x280(%rbx),%rcx
  45b32a:	0f 12 d8             	movhlps %xmm0,%xmm3
  45b32d:	66 48 0f 7e c7       	movq   %xmm0,%rdi
  45b332:	66 48 0f 7e d8       	movq   %xmm3,%rax
  45b337:	4c 29 d1             	sub    %r10,%rcx
  45b33a:	48 29 f8             	sub    %rdi,%rax
  45b33d:	48 39 c1             	cmp    %rax,%rcx
  45b340:	75 29                	jne    45b36b <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x5b>
  45b342:	48 c1 f9 05          	sar    $0x5,%rcx
  45b346:	4c 89 d0             	mov    %r10,%rax
  45b349:	45 31 c0             	xor    %r8d,%r8d
  45b34c:	4c 29 d7             	sub    %r10,%rdi
  45b34f:	4c 39 c1             	cmp    %r8,%rcx
  45b352:	0f 84 52 01 00 00    	je     45b4aa <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x19a>
  45b358:	48 8d 14 07          	lea    (%rdi,%rax,1),%rdx
  45b35c:	4c 8b 18             	mov    (%rax),%r11
  45b35f:	49 89 c1             	mov    %rax,%r9
  45b362:	4c 39 1a             	cmp    %r11,(%rdx)
  45b365:	0f 84 45 01 00 00    	je     45b4b0 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x1a0>
  45b36b:	48 8b bb 98 02 00 00 	mov    0x298(%rbx),%rdi
  45b372:	66 0f ef c9          	pxor   %xmm1,%xmm1
  45b376:	48 89 f0             	mov    %rsi,%rax
  45b379:	48 83 83 b0 02 00 00 	addq   $0x1,0x2b0(%rbx)
  45b380:	01 
  45b381:	48 8b b3 a8 02 00 00 	mov    0x2a8(%rbx),%rsi
  45b388:	c6 83 c0 02 00 00 00 	movb   $0x0,0x2c0(%rbx)
  45b38f:	48 c7 83 a8 02 00 00 	movq   $0x0,0x2a8(%rbx)
  45b396:	00 00 00 00 
  45b39a:	0f 11 8b 98 02 00 00 	movups %xmm1,0x298(%rbx)
  45b3a1:	48 85 ff             	test   %rdi,%rdi
  45b3a4:	74 21                	je     45b3c7 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0xb7>
  45b3a6:	48 29 fe             	sub    %rdi,%rsi
  45b3a9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  45b3ae:	e8 ed 2d bd ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  45b3b3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  45b3b8:	4c 8b 93 78 02 00 00 	mov    0x278(%rbx),%r10
  45b3bf:	66 0f ef c9          	pxor   %xmm1,%xmm1
  45b3c3:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  45b3c7:	0f 11 83 78 02 00 00 	movups %xmm0,0x278(%rbx)
  45b3ce:	48 8b 50 10          	mov    0x10(%rax),%rdx
  45b3d2:	48 8b b3 88 02 00 00 	mov    0x288(%rbx),%rsi
  45b3d9:	48 89 93 88 02 00 00 	mov    %rdx,0x288(%rbx)
  45b3e0:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  45b3e7:	00 
  45b3e8:	0f 11 08             	movups %xmm1,(%rax)
  45b3eb:	4d 85 d2             	test   %r10,%r10
  45b3ee:	74 0b                	je     45b3fb <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0xeb>
  45b3f0:	4c 29 d6             	sub    %r10,%rsi
  45b3f3:	4c 89 d7             	mov    %r10,%rdi
  45b3f6:	e8 a5 2d bd ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  45b3fb:	48 8b 83 b0 03 00 00 	mov    0x3b0(%rbx),%rax
  45b402:	48 3b 83 b8 03 00 00 	cmp    0x3b8(%rbx),%rax
  45b409:	74 07                	je     45b412 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x102>
  45b40b:	48 89 83 b8 03 00 00 	mov    %rax,0x3b8(%rbx)
  45b412:	48 8b 83 60 02 00 00 	mov    0x260(%rbx),%rax
  45b419:	48 3b 83 68 02 00 00 	cmp    0x268(%rbx),%rax
  45b420:	74 07                	je     45b429 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x119>
  45b422:	48 89 83 68 02 00 00 	mov    %rax,0x268(%rbx)
  45b429:	48 8b bb 18 04 00 00 	mov    0x418(%rbx),%rdi
  45b430:	c7 83 80 03 00 00 00 	movl   $0x0,0x380(%rbx)
  45b437:	00 00 00 
  45b43a:	48 c7 83 18 04 00 00 	movq   $0x0,0x418(%rbx)
  45b441:	00 00 00 00 
  45b445:	48 85 ff             	test   %rdi,%rdi
  45b448:	74 56                	je     45b4a0 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x190>
  45b44a:	f0 83 6f 08 01       	lock subl $0x1,0x8(%rdi)
  45b44f:	75 4f                	jne    45b4a0 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x190>
  45b451:	48 8b 17             	mov    (%rdi),%rdx
  45b454:	48 8d 0d e5 b1 be ff 	lea    -0x414e1b(%rip),%rcx        # 46640 <SkWeakRefCnt::internal_dispose() const>
  45b45b:	48 8b 42 10          	mov    0x10(%rdx),%rax
  45b45f:	48 39 c8             	cmp    %rcx,%rax
  45b462:	0f 84 a0 00 00 00    	je     45b508 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x1f8>
  45b468:	48 8d 0d 41 b2 be ff 	lea    -0x414dbf(%rip),%rcx        # 466b0 <SkRefCntBase::internal_dispose() const>
  45b46f:	48 39 c8             	cmp    %rcx,%rax
  45b472:	0f 85 cd 00 00 00    	jne    45b545 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x235>
  45b478:	48 8b 42 08          	mov    0x8(%rdx),%rax
  45b47c:	48 8d 15 cd ae be ff 	lea    -0x415133(%rip),%rdx        # 46350 <SkRefCntBase::~SkRefCntBase()>
  45b483:	48 39 d0             	cmp    %rdx,%rax
  45b486:	0f 84 aa 00 00 00    	je     45b536 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x226>
  45b48c:	48 8d 15 ad ae be ff 	lea    -0x415153(%rip),%rdx        # 46340 <SkWeakRefCnt::~SkWeakRefCnt()>
  45b493:	48 39 d0             	cmp    %rdx,%rax
  45b496:	0f 84 9a 00 00 00    	je     45b536 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x226>
  45b49c:	ff d0                	call   *%rax
  45b49e:	66 90                	xchg   %ax,%ax
  45b4a0:	c7 83 50 03 00 00 00 	movl   $0x0,0x350(%rbx)
  45b4a7:	00 00 00 
  45b4aa:	48 83 c4 10          	add    $0x10,%rsp
  45b4ae:	5b                   	pop    %rbx
  45b4af:	c3                   	ret
  45b4b0:	4c 8b 58 08          	mov    0x8(%rax),%r11
  45b4b4:	4c 39 5a 08          	cmp    %r11,0x8(%rdx)
  45b4b8:	0f 85 ad fe ff ff    	jne    45b36b <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x5b>
  45b4be:	4c 8b 58 10          	mov    0x10(%rax),%r11
  45b4c2:	4c 39 5a 10          	cmp    %r11,0x10(%rdx)
  45b4c6:	0f 85 9f fe ff ff    	jne    45b36b <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x5b>
  45b4cc:	f3 0f 10 4a 18       	movss  0x18(%rdx),%xmm1
  45b4d1:	0f 2e 48 18          	ucomiss 0x18(%rax),%xmm1
  45b4d5:	0f 8a 90 fe ff ff    	jp     45b36b <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x5b>
  45b4db:	0f 85 8a fe ff ff    	jne    45b36b <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x5b>
  45b4e1:	f3 0f 10 4a 1c       	movss  0x1c(%rdx),%xmm1
  45b4e6:	49 83 c0 01          	add    $0x1,%r8
  45b4ea:	48 83 c0 20          	add    $0x20,%rax
  45b4ee:	41 0f 2e 49 1c       	ucomiss 0x1c(%r9),%xmm1
  45b4f3:	0f 8a 72 fe ff ff    	jp     45b36b <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x5b>
  45b4f9:	0f 84 50 fe ff ff    	je     45b34f <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x3f>
  45b4ff:	e9 67 fe ff ff       	jmp    45b36b <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x5b>
  45b504:	0f 1f 40 00          	nopl   0x0(%rax)
  45b508:	48 8b 42 18          	mov    0x18(%rdx),%rax
  45b50c:	48 8d 15 dd ad be ff 	lea    -0x415223(%rip),%rdx        # 462f0 <SkWeakRefCnt::weak_dispose() const>
  45b513:	48 39 d0             	cmp    %rdx,%rax
  45b516:	75 34                	jne    45b54c <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x23c>
  45b518:	f0 83 6f 0c 01       	lock subl $0x1,0xc(%rdi)
  45b51d:	75 81                	jne    45b4a0 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x190>
  45b51f:	48 8b 07             	mov    (%rdi),%rax
  45b522:	48 8d 15 17 ae be ff 	lea    -0x4151e9(%rip),%rdx        # 46340 <SkWeakRefCnt::~SkWeakRefCnt()>
  45b529:	48 8b 40 08          	mov    0x8(%rax),%rax
  45b52d:	48 39 d0             	cmp    %rdx,%rax
  45b530:	0f 85 66 ff ff ff    	jne    45b49c <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x18c>
  45b536:	be 10 00 00 00       	mov    $0x10,%esi
  45b53b:	e8 60 2c bd ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  45b540:	e9 5b ff ff ff       	jmp    45b4a0 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x190>
  45b545:	ff d0                	call   *%rax
  45b547:	e9 54 ff ff ff       	jmp    45b4a0 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x190>
  45b54c:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  45b551:	ff d0                	call   *%rax
  45b553:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  45b558:	eb be                	jmp    45b518 <skia::textlayout::ParagraphImpl::experimentalSetSpans(std::vector<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan, std::allocator<skia::textlayout::ParagraphImpl::ExperimentalFragmentSpan> >)+0x208>
