
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/retained-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000479f80 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)>:
  479f80:	48 81 ec 58 02 00 00 	sub    $0x258,%rsp
  479f87:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
  479f8e:	00 
  479f8f:	4c 63 ae 70 03 00 00 	movslq 0x370(%rsi),%r13
  479f96:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  479f9b:	f3 0f 11 44 24 4c    	movss  %xmm0,0x4c(%rsp)
  479fa1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  479fa8:	00 00 
  479faa:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  479fb1:	00 
  479fb2:	48 b8 00 00 00 00 00 	movabs $0x80000000000000,%rax
  479fb9:	00 80 00 
  479fbc:	c7 87 74 01 00 00 00 	movl   $0x800000,0x174(%rdi)
  479fc3:	00 80 00 
  479fc6:	48 89 87 6c 01 00 00 	mov    %rax,0x16c(%rdi)
  479fcd:	4d 85 ed             	test   %r13,%r13
  479fd0:	75 27                	jne    479ff9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x79>
  479fd2:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  479fd9:	00 
  479fda:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
  479fe1:	00 00 
  479fe3:	0f 85 ac 1e 00 00    	jne    47be95 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1f15>
  479fe9:	4c 8b ac 24 40 02 00 	mov    0x240(%rsp),%r13
  479ff0:	00 
  479ff1:	48 81 c4 58 02 00 00 	add    $0x258,%rsp
  479ff8:	c3                   	ret
  479ff9:	48 8b 86 68 03 00 00 	mov    0x368(%rsi),%rax
  47a000:	48 89 ac 24 30 02 00 	mov    %rbp,0x230(%rsp)
  47a007:	00 
  47a008:	48 89 fd             	mov    %rdi,%rbp
  47a00b:	48 8d 7e 10          	lea    0x10(%rsi),%rdi
  47a00f:	48 89 9c 24 28 02 00 	mov    %rbx,0x228(%rsp)
  47a016:	00 
  47a017:	bb 01 00 00 00       	mov    $0x1,%ebx
  47a01c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  47a021:	48 8b 86 f8 01 00 00 	mov    0x1f8(%rsi),%rax
  47a028:	4c 89 bc 24 50 02 00 	mov    %r15,0x250(%rsp)
  47a02f:	00 
  47a030:	49 89 f7             	mov    %rsi,%r15
  47a033:	4c 89 a4 24 38 02 00 	mov    %r12,0x238(%rsp)
  47a03a:	00 
  47a03b:	4c 89 b4 24 48 02 00 	mov    %r14,0x248(%rsp)
  47a042:	00 
  47a043:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  47a04a:	00 
  47a04b:	e8 00 9c fe ff       	call   463c50 <skia::textlayout::ParagraphStyle::effective_align() const>
  47a050:	89 84 24 8c 00 00 00 	mov    %eax,0x8c(%rsp)
  47a057:	49 8b 87 20 02 00 00 	mov    0x220(%r15),%rax
  47a05e:	8b 38                	mov    (%rax),%edi
  47a060:	85 ff                	test   %edi,%edi
  47a062:	75 0b                	jne    47a06f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xef>
  47a064:	49 83 bf 08 02 00 00 	cmpq   $0x0,0x208(%r15)
  47a06b:	00 
  47a06c:	0f 95 c3             	setne  %bl
  47a06f:	41 80 bf 35 02 00 00 	cmpb   $0x0,0x235(%r15)
  47a076:	00 
  47a077:	0f 84 8a 02 00 00    	je     47a307 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x387>
  47a07d:	49 8b 87 38 02 00 00 	mov    0x238(%r15),%rax
  47a084:	49 8d 8f 38 02 00 00 	lea    0x238(%r15),%rcx
  47a08b:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  47a092:	00 
  47a093:	8b 30                	mov    (%rax),%esi
  47a095:	85 f6                	test   %esi,%esi
  47a097:	0f 84 6a 02 00 00    	je     47a307 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x387>
  47a09d:	41 8b 87 2c 02 00 00 	mov    0x22c(%r15),%eax
  47a0a4:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  47a0a9:	45 0f b6 67 38       	movzbl 0x38(%r15),%r12d
  47a0ae:	89 44 24 48          	mov    %eax,0x48(%rsp)
  47a0b2:	4c 8b 77 28          	mov    0x28(%rdi),%r14
  47a0b6:	e8 55 b7 fe ff       	call   465810 <skia::textlayout::Cluster::runOrNull() const>
  47a0bb:	48 85 c0             	test   %rax,%rax
  47a0be:	0f 84 54 02 00 00    	je     47a318 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x398>
  47a0c4:	45 84 e4             	test   %r12b,%r12b
  47a0c7:	0f 85 4b 02 00 00    	jne    47a318 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x398>
  47a0cd:	f3 0f 10 88 d8 00 00 	movss  0xd8(%rax),%xmm1
  47a0d4:	00 
  47a0d5:	f3 0f 10 80 dc 00 00 	movss  0xdc(%rax),%xmm0
  47a0dc:	00 
  47a0dd:	f3 0f 10 b8 98 00 00 	movss  0x98(%rax),%xmm7
  47a0e4:	00 
  47a0e5:	f3 0f 10 15 63 9e 03 	movss  0x39e63(%rip),%xmm2        # 4b3f50 <C.119.3+0x1700>
  47a0ec:	00 
  47a0ed:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  47a0f1:	f3 0f 10 b0 e0 00 00 	movss  0xe0(%rax),%xmm6
  47a0f8:	00 
  47a0f9:	f3 0f 10 2d 53 9e 03 	movss  0x39e53(%rip),%xmm5        # 4b3f54 <C.119.3+0x1704>
  47a100:	00 
  47a101:	f3 0f 58 f9          	addss  %xmm1,%xmm7
  47a105:	f3 0f 10 a0 e4 00 00 	movss  0xe4(%rax),%xmm4
  47a10c:	00 
  47a10d:	f3 0f 58 f1          	addss  %xmm1,%xmm6
  47a111:	0f 28 dd             	movaps %xmm5,%xmm3
  47a114:	f3 0f 5d c2          	minss  %xmm2,%xmm0
  47a118:	f3 0f 5d fa          	minss  %xmm2,%xmm7
  47a11c:	f3 0f 10 90 9c 00 00 	movss  0x9c(%rax),%xmm2
  47a123:	00 
  47a124:	f3 0f c2 de 01       	cmpltss %xmm6,%xmm3
  47a129:	f3 0f 58 d1          	addss  %xmm1,%xmm2
  47a12d:	0f 28 cd             	movaps %xmm5,%xmm1
  47a130:	0f 54 f3             	andps  %xmm3,%xmm6
  47a133:	0f 55 dd             	andnps %xmm5,%xmm3
  47a136:	f3 0f c2 ca 01       	cmpltss %xmm2,%xmm1
  47a13b:	0f 56 de             	orps   %xmm6,%xmm3
  47a13e:	66 0f ef f6          	pxor   %xmm6,%xmm6
  47a142:	f3 0f 5f e6          	maxss  %xmm6,%xmm4
  47a146:	0f 14 c3             	unpcklps %xmm3,%xmm0
  47a149:	0f 54 d1             	andps  %xmm1,%xmm2
  47a14c:	0f 55 cd             	andnps %xmm5,%xmm1
  47a14f:	0f 56 ca             	orps   %xmm2,%xmm1
  47a152:	f3 0f 10 90 a4 00 00 	movss  0xa4(%rax),%xmm2
  47a159:	00 
  47a15a:	0f 14 e7             	unpcklps %xmm7,%xmm4
  47a15d:	0f 16 c4             	movlhps %xmm4,%xmm0
  47a160:	f3 0f 5f d6          	maxss  %xmm6,%xmm2
  47a164:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  47a169:	4c 89 ff             	mov    %r15,%rdi
  47a16c:	48 c7 85 10 01 00 00 	movq   $0x0,0x110(%rbp)
  47a173:	00 00 00 00 
  47a177:	4c 89 b5 20 01 00 00 	mov    %r14,0x120(%rbp)
  47a17e:	48 89 85 08 01 00 00 	mov    %rax,0x108(%rbp)
  47a185:	48 89 85 18 01 00 00 	mov    %rax,0x118(%rbp)
  47a18c:	48 c7 85 28 01 00 00 	movq   $0x0,0x128(%rbp)
  47a193:	00 00 00 00 
  47a197:	48 c7 85 30 01 00 00 	movq   $0xffffffffffffffff,0x130(%rbp)
  47a19e:	ff ff ff ff 
  47a1a2:	44 88 a5 50 01 00 00 	mov    %r12b,0x150(%rbp)
  47a1a9:	48 c7 85 54 01 00 00 	movq   $0x0,0x154(%rbp)
  47a1b0:	00 00 00 00 
  47a1b4:	0f 11 85 38 01 00 00 	movups %xmm0,0x138(%rbp)
  47a1bb:	f3 0f 11 8d 48 01 00 	movss  %xmm1,0x148(%rbp)
  47a1c2:	00 
  47a1c3:	f3 0f 11 95 4c 01 00 	movss  %xmm2,0x14c(%rbp)
  47a1ca:	00 
  47a1cb:	e8 d0 07 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a1d0:	84 c0                	test   %al,%al
  47a1d2:	0f 84 58 01 00 00    	je     47a330 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3b0>
  47a1d8:	e8 c3 4a bb ff       	call   2eca0 <fegetround@plt>
  47a1dd:	c7 84 24 b4 00 00 00 	movl   $0x2,0xb4(%rsp)
  47a1e4:	02 00 00 00 
  47a1e8:	85 c0                	test   %eax,%eax
  47a1ea:	75 20                	jne    47a20c <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x28c>
  47a1ec:	0f ae 9c 24 dc 00 00 	stmxcsr 0xdc(%rsp)
  47a1f3:	00 
  47a1f4:	31 c0                	xor    %eax,%eax
  47a1f6:	66 f7 84 24 dc 00 00 	testw  $0xe040,0xdc(%rsp)
  47a1fd:	00 40 e0 
  47a200:	0f 95 c0             	setne  %al
  47a203:	01 c0                	add    %eax,%eax
  47a205:	89 84 24 b4 00 00 00 	mov    %eax,0xb4(%rsp)
  47a20c:	f3 0f 10 44 24 4c    	movss  0x4c(%rsp),%xmm0
  47a212:	f3 0f 10 15 36 9d 03 	movss  0x39d36(%rip),%xmm2        # 4b3f50 <C.119.3+0x1700>
  47a219:	00 
  47a21a:	b8 03 00 00 00       	mov    $0x3,%eax
  47a21f:	0f 54 05 2a 88 03 00 	andps  0x3882a(%rip),%xmm0        # 4b2a50 <C.119.3+0x200>
  47a226:	49 8b 97 80 02 00 00 	mov    0x280(%r15),%rdx
  47a22d:	0f 2e d0             	ucomiss %xmm0,%xmm2
  47a230:	0f 43 84 24 b4 00 00 	cmovae 0xb4(%rsp),%eax
  47a237:	00 
  47a238:	89 84 24 b4 00 00 00 	mov    %eax,0xb4(%rsp)
  47a23f:	89 c1                	mov    %eax,%ecx
  47a241:	49 8b 87 78 02 00 00 	mov    0x278(%r15),%rax
  47a248:	48 39 c2             	cmp    %rax,%rdx
  47a24b:	0f 84 b6 19 00 00    	je     47bc07 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1c87>
  47a251:	66 0f ef db          	pxor   %xmm3,%xmm3
  47a255:	0f 28 e3             	movaps %xmm3,%xmm4
  47a258:	eb 15                	jmp    47a26f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x2ef>
  47a25a:	0f 2f e0             	comiss %xmm0,%xmm4
  47a25d:	77 24                	ja     47a283 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x303>
  47a25f:	f3 0f 5f c3          	maxss  %xmm3,%xmm0
  47a263:	48 83 c0 20          	add    $0x20,%rax
  47a267:	0f 28 d8             	movaps %xmm0,%xmm3
  47a26a:	48 39 c2             	cmp    %rax,%rdx
  47a26d:	74 22                	je     47a291 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x311>
  47a26f:	f3 0f 10 40 18       	movss  0x18(%rax),%xmm0
  47a274:	0f 28 c8             	movaps %xmm0,%xmm1
  47a277:	0f 54 0d d2 87 03 00 	andps  0x387d2(%rip),%xmm1        # 4b2a50 <C.119.3+0x200>
  47a27e:	0f 2e d1             	ucomiss %xmm1,%xmm2
  47a281:	73 d7                	jae    47a25a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x2da>
  47a283:	48 83 c0 20          	add    $0x20,%rax
  47a287:	b9 04 00 00 00       	mov    $0x4,%ecx
  47a28c:	48 39 c2             	cmp    %rax,%rdx
  47a28f:	75 de                	jne    47a26f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x2ef>
  47a291:	49 63 87 60 03 00 00 	movslq 0x360(%r15),%rax
  47a298:	89 8c 24 b4 00 00 00 	mov    %ecx,0xb4(%rsp)
  47a29f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  47a2a4:	df 6c 24 08          	fildll 0x8(%rsp)
  47a2a8:	48 85 c0             	test   %rax,%rax
  47a2ab:	0f 88 c8 19 00 00    	js     47bc79 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1cf9>
  47a2b1:	d9 e8                	fld1
  47a2b3:	f3 0f 11 5c 24 08    	movss  %xmm3,0x8(%rsp)
  47a2b9:	de c1                	faddp  %st,%st(1)
  47a2bb:	d9 44 24 08          	flds   0x8(%rsp)
  47a2bf:	d8 0d 6f cd 02 00    	fmuls  0x2cd6f(%rip)        # 4a7034 <_IO_stdin_used+0x34>
  47a2c5:	de c9                	fmulp  %st,%st(1)
  47a2c7:	d9 c0                	fld    %st(0)
  47a2c9:	db bc 24 a0 00 00 00 	fstpt  0xa0(%rsp)
  47a2d0:	d9 05 0e d0 02 00    	flds   0x2d00e(%rip)        # 4a72e4 <_IO_stdin_used+0x2e4>
  47a2d6:	d9 c9                	fxch   %st(1)
  47a2d8:	df f1                	fcomip %st(1),%st
  47a2da:	dd d8                	fstp   %st(0)
  47a2dc:	0f 86 3c 19 00 00    	jbe    47bc1e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1c9e>
  47a2e2:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  47a2e9:	00 00 00 00 00 
  47a2ee:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  47a2f5:	00 00 00 00 00 
  47a2fa:	c7 84 24 b4 00 00 00 	movl   $0x5,0xb4(%rsp)
  47a301:	05 00 00 00 
  47a305:	eb 63                	jmp    47a36a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3ea>
  47a307:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
  47a30e:	00 00 00 00 00 
  47a313:	e9 85 fd ff ff       	jmp    47a09d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x11d>
  47a318:	0f 28 05 31 9c 03 00 	movaps 0x39c31(%rip),%xmm0        # 4b3f50 <C.119.3+0x1700>
  47a31f:	f3 0f 10 0d 2d 9c 03 	movss  0x39c2d(%rip),%xmm1        # 4b3f54 <C.119.3+0x1704>
  47a326:	00 
  47a327:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47a32b:	e9 34 fe ff ff       	jmp    47a164 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1e4>
  47a330:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  47a337:	00 00 00 00 00 
  47a33c:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  47a343:	00 00 00 00 00 
  47a348:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  47a34f:	00 00 00 00 00 
  47a354:	c7 84 24 a8 00 00 00 	movl   $0x0,0xa8(%rsp)
  47a35b:	00 00 00 00 
  47a35f:	c7 84 24 b4 00 00 00 	movl   $0x0,0xb4(%rsp)
  47a366:	00 00 00 00 
  47a36a:	49 8d 45 ff          	lea    -0x1(%r13),%rax
  47a36e:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  47a373:	4c 8b ad 18 01 00 00 	mov    0x118(%rbp),%r13
  47a37a:	48 c1 e0 06          	shl    $0x6,%rax
  47a37e:	48 01 c8             	add    %rcx,%rax
  47a381:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  47a386:	4c 39 e8             	cmp    %r13,%rax
  47a389:	0f 84 cb 1a 00 00    	je     47be5a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1eda>
  47a38f:	f3 0f 10 64 24 4c    	movss  0x4c(%rsp),%xmm4
  47a395:	48 8d 85 38 01 00 00 	lea    0x138(%rbp),%rax
  47a39c:	48 83 bc 24 c0 00 00 	cmpq   $0xffffffffffffffff,0xc0(%rsp)
  47a3a3:	00 ff 
  47a3a5:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  47a3aa:	0f 94 c0             	sete   %al
  47a3ad:	0f 28 c4             	movaps %xmm4,%xmm0
  47a3b0:	f3 0f 5c c4          	subss  %xmm4,%xmm0
  47a3b4:	0f 2e c0             	ucomiss %xmm0,%xmm0
  47a3b7:	0f 9b c2             	setnp  %dl
  47a3ba:	21 da                	and    %ebx,%edx
  47a3bc:	20 d8                	and    %bl,%al
  47a3be:	88 94 24 b3 00 00 00 	mov    %dl,0xb3(%rsp)
  47a3c5:	88 84 24 b2 00 00 00 	mov    %al,0xb2(%rsp)
  47a3cc:	0f 85 ad 15 00 00    	jne    47b97f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x19ff>
  47a3d2:	bf 01 00 00 00       	mov    $0x1,%edi
  47a3d7:	66 0f ef db          	pxor   %xmm3,%xmm3
  47a3db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  47a3e0:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  47a3e7:	00 
  47a3e8:	0f b6 8c 24 b3 00 00 	movzbl 0xb3(%rsp),%ecx
  47a3ef:	00 
  47a3f0:	40 88 7c 24 34       	mov    %dil,0x34(%rsp)
  47a3f5:	48 39 85 60 01 00 00 	cmp    %rax,0x160(%rbp)
  47a3fc:	0f 93 c0             	setae  %al
  47a3ff:	21 c1                	and    %eax,%ecx
  47a401:	89 c7                	mov    %eax,%edi
  47a403:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  47a408:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
  47a40d:	4d 89 ee             	mov    %r13,%r14
  47a410:	89 cb                	mov    %ecx,%ebx
  47a412:	40 88 bc 24 8b 00 00 	mov    %dil,0x8b(%rsp)
  47a419:	00 
  47a41a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  47a41f:	49 89 ef             	mov    %rbp,%r15
  47a422:	48 83 e8 40          	sub    $0x40,%rax
  47a426:	f3 0f 11 5c 24 30    	movss  %xmm3,0x30(%rsp)
  47a42c:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  47a431:	e8 6a 05 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a436:	84 c0                	test   %al,%al
  47a438:	0f 84 42 08 00 00    	je     47ac80 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd00>
  47a43e:	8b 94 24 b4 00 00 00 	mov    0xb4(%rsp),%edx
  47a445:	85 d2                	test   %edx,%edx
  47a447:	0f 84 33 0e 00 00    	je     47b280 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1300>
  47a44d:	f3 0f 10 15 fb 9a 03 	movss  0x39afb(%rip),%xmm2        # 4b3f50 <C.119.3+0x1700>
  47a454:	00 
  47a455:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  47a45a:	49 89 c4             	mov    %rax,%r12
  47a45d:	49 39 c6             	cmp    %rax,%r14
  47a460:	0f 83 03 0a 00 00    	jae    47ae69 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xee9>
  47a466:	88 5c 24 60          	mov    %bl,0x60(%rsp)
  47a46a:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  47a46f:	4d 89 f5             	mov    %r14,%r13
  47a472:	66 0f ef db          	pxor   %xmm3,%xmm3
  47a476:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  47a47d:	00 00 
  47a47f:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  47a484:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  47a48b:	00 00 
  47a48d:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  47a492:	4d 89 f7             	mov    %r14,%r15
  47a495:	45 31 f6             	xor    %r14d,%r14d
  47a498:	f3 0f 11 54 24 68    	movss  %xmm2,0x68(%rsp)
  47a49e:	66 90                	xchg   %ax,%ax
  47a4a0:	f3 41 0f 58 5d 30    	addss  0x30(%r13),%xmm3
  47a4a6:	4c 89 ed             	mov    %r13,%rbp
  47a4a9:	49 83 c5 40          	add    $0x40,%r13
  47a4ad:	0f 28 cb             	movaps %xmm3,%xmm1
  47a4b0:	4d 39 ef             	cmp    %r13,%r15
  47a4b3:	0f 83 57 08 00 00    	jae    47ad10 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd90>
  47a4b9:	4c 89 e8             	mov    %r13,%rax
  47a4bc:	eb 14                	jmp    47a4d2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x552>
  47a4be:	66 90                	xchg   %ax,%ax
  47a4c0:	48 83 e8 40          	sub    $0x40,%rax
  47a4c4:	f3 0f 5c 48 30       	subss  0x30(%rax),%xmm1
  47a4c9:	49 39 c7             	cmp    %rax,%r15
  47a4cc:	0f 83 3e 08 00 00    	jae    47ad10 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd90>
  47a4d2:	80 78 f8 00          	cmpb   $0x0,-0x8(%rax)
  47a4d6:	75 e8                	jne    47a4c0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x540>
  47a4d8:	49 39 c7             	cmp    %rax,%r15
  47a4db:	0f 83 2f 08 00 00    	jae    47ad10 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd90>
  47a4e1:	49 8b 57 10          	mov    0x10(%r15),%rdx
  47a4e5:	48 8b 40 d8          	mov    -0x28(%rax),%rax
  47a4e9:	48 92                	xchg   %rax,%rdx
  47a4eb:	4c 89 e7             	mov    %r12,%rdi
  47a4ee:	f3 0f 11 5c 24 20    	movss  %xmm3,0x20(%rsp)
  47a4f4:	48 89 c6             	mov    %rax,%rsi
  47a4f7:	f3 0f 11 4c 24 18    	movss  %xmm1,0x18(%rsp)
  47a4fd:	e8 1e 0d fe ff       	call   45b220 <skia::textlayout::ParagraphImpl::experimentalPadding(skia::textlayout::SkRange<unsigned long>) const>
  47a502:	49 8b 7d d8          	mov    -0x28(%r13),%rdi
  47a506:	4d 8b 94 24 68 02 00 	mov    0x268(%r12),%r10
  47a50d:	00 
  47a50e:	49 8b b4 24 60 02 00 	mov    0x260(%r12),%rsi
  47a515:	00 
  47a516:	f3 0f 10 4c 24 18    	movss  0x18(%rsp),%xmm1
  47a51c:	4c 89 d0             	mov    %r10,%rax
  47a51f:	f3 0f 10 5c 24 20    	movss  0x20(%rsp),%xmm3
  47a525:	48 29 f0             	sub    %rsi,%rax
  47a528:	48 85 c0             	test   %rax,%rax
  47a52b:	7e 34                	jle    47a561 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x5e1>
  47a52d:	48 c1 f8 03          	sar    $0x3,%rax
  47a531:	0f 1f 40 00          	nopl   0x0(%rax)
  47a535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47a53c:	00 00 00 00 
  47a540:	48 89 c2             	mov    %rax,%rdx
  47a543:	48 d1 fa             	sar    $1,%rdx
  47a546:	48 39 3c d6          	cmp    %rdi,(%rsi,%rdx,8)
  47a54a:	0f 83 70 07 00 00    	jae    47acc0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd40>
  47a550:	48 29 d0             	sub    %rdx,%rax
  47a553:	48 8d 74 d6 08       	lea    0x8(%rsi,%rdx,8),%rsi
  47a558:	48 83 e8 01          	sub    $0x1,%rax
  47a55c:	48 85 c0             	test   %rax,%rax
  47a55f:	7f df                	jg     47a540 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x5c0>
  47a561:	49 39 f2             	cmp    %rsi,%r10
  47a564:	0f 84 6e 07 00 00    	je     47acd8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd58>
  47a56a:	48 3b 3e             	cmp    (%rsi),%rdi
  47a56d:	0f 82 65 07 00 00    	jb     47acd8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd58>
  47a573:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  47a577:	4d 85 f6             	test   %r14,%r14
  47a57a:	0f 84 70 07 00 00    	je     47acf0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd70>
  47a580:	f3 0f 10 64 24 4c    	movss  0x4c(%rsp),%xmm4
  47a586:	0f 2f e0             	comiss %xmm0,%xmm4
  47a589:	0f 82 49 07 00 00    	jb     47acd8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd58>
  47a58f:	48 89 ef             	mov    %rbp,%rdi
  47a592:	f3 0f 11 5c 24 18    	movss  %xmm3,0x18(%rsp)
  47a598:	e8 63 b3 fe ff       	call   465900 <skia::textlayout::Cluster::isSoftBreak() const>
  47a59d:	f3 0f 10 5c 24 18    	movss  0x18(%rsp),%xmm3
  47a5a3:	84 c0                	test   %al,%al
  47a5a5:	41 0f b6 45 fa       	movzbl -0x6(%r13),%eax
  47a5aa:	0f 85 c0 0c 00 00    	jne    47b270 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x12f0>
  47a5b0:	4c 39 eb             	cmp    %r13,%rbx
  47a5b3:	0f 84 b7 0c 00 00    	je     47b270 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x12f0>
  47a5b9:	84 c0                	test   %al,%al
  47a5bb:	0f 85 af 0c 00 00    	jne    47b270 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x12f0>
  47a5c1:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  47a5c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  47a5cd:	00 00 00 
  47a5d0:	49 39 dd             	cmp    %rbx,%r13
  47a5d3:	0f 82 c7 fe ff ff    	jb     47a4a0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x520>
  47a5d9:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
  47a5de:	4c 8b 64 24 50       	mov    0x50(%rsp),%r12
  47a5e3:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
  47a5e8:	4d 89 fe             	mov    %r15,%r14
  47a5eb:	0f b6 5c 24 60       	movzbl 0x60(%rsp),%ebx
  47a5f0:	f3 0f 10 54 24 68    	movss  0x68(%rsp),%xmm2
  47a5f6:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  47a5fb:	4d 85 ed             	test   %r13,%r13
  47a5fe:	0f 84 4f 08 00 00    	je     47ae53 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xed3>
  47a604:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  47a609:	0f b6 eb             	movzbl %bl,%ebp
  47a60c:	4c 89 ff             	mov    %r15,%rdi
  47a60f:	4c 89 ee             	mov    %r13,%rsi
  47a612:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  47a619:	00 
  47a61a:	41 89 e8             	mov    %ebp,%r8d
  47a61d:	0f 28 c2             	movaps %xmm2,%xmm0
  47a620:	41 0f b6 94 24 33 02 	movzbl 0x233(%r12),%edx
  47a627:	00 00 
  47a629:	e8 92 ce ff ff       	call   4774c0 <skia::textlayout::TextWrapper::lookAhead(float, skia::textlayout::Cluster*, bool, SkString const*, bool)>
  47a62e:	4c 89 e7             	mov    %r12,%rdi
  47a631:	e8 6a 03 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  47a63d:	00 00 00 
  47a640:	89 ee                	mov    %ebp,%esi
  47a642:	4c 89 ff             	mov    %r15,%rdi
  47a645:	e8 06 f3 ff ff       	call   479950 <skia::textlayout::TextWrapper::moveForward(bool)>
  47a64a:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  47a64f:	49 39 87 18 01 00 00 	cmp    %rax,0x118(%r15)
  47a656:	0f 92 c0             	setb   %al
  47a659:	8b b4 24 8c 00 00 00 	mov    0x8c(%rsp),%esi
  47a660:	21 d8                	and    %ebx,%eax
  47a662:	88 44 24 18          	mov    %al,0x18(%rsp)
  47a666:	e8 c5 f5 ff ff       	call   479c30 <skia::textlayout::TextWrapper::trimEndSpaces(skia::textlayout::TextAlign)>
  47a66b:	49 8b 97 28 01 00 00 	mov    0x128(%r15),%rdx
  47a672:	4c 8d 62 40          	lea    0x40(%rdx),%r12
  47a676:	41 80 bf 6a 01 00 00 	cmpb   $0x0,0x16a(%r15)
  47a67d:	00 
  47a67e:	0f 84 9c 06 00 00    	je     47ad20 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xda0>
  47a684:	f3 41 0f 10 8f 54 01 	movss  0x154(%r15),%xmm1
  47a68b:	00 00 
  47a68d:	49 8b 8f 18 01 00 00 	mov    0x118(%r15),%rcx
  47a694:	48 8d 41 40          	lea    0x40(%rcx),%rax
  47a698:	48 39 d0             	cmp    %rdx,%rax
  47a69b:	72 11                	jb     47a6ae <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x72e>
  47a69d:	eb 15                	jmp    47a6b4 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x734>
  47a69f:	90                   	nop
  47a6a0:	f3 0f 58 48 30       	addss  0x30(%rax),%xmm1
  47a6a5:	48 83 c0 40          	add    $0x40,%rax
  47a6a9:	48 39 d0             	cmp    %rdx,%rax
  47a6ac:	73 06                	jae    47a6b4 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x734>
  47a6ae:	80 78 38 00          	cmpb   $0x0,0x38(%rax)
  47a6b2:	75 ec                	jne    47a6a0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x720>
  47a6b4:	f3 41 0f 10 87 38 01 	movss  0x138(%r15),%xmm0
  47a6bb:	00 00 
  47a6bd:	0f 2e 05 8c 98 03 00 	ucomiss 0x3988c(%rip),%xmm0        # 4b3f50 <C.119.3+0x1700>
  47a6c4:	0f 8a c6 00 00 00    	jp     47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a6ca:	0f 85 c0 00 00 00    	jne    47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a6d0:	f3 41 0f 10 87 3c 01 	movss  0x13c(%r15),%xmm0
  47a6d7:	00 00 
  47a6d9:	0f 2e 05 74 98 03 00 	ucomiss 0x39874(%rip),%xmm0        # 4b3f54 <C.119.3+0x1704>
  47a6e0:	0f 8a aa 00 00 00    	jp     47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a6e6:	0f 85 a4 00 00 00    	jne    47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a6ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47a6f0:	41 0f 2e 87 40 01 00 	ucomiss 0x140(%r15),%xmm0
  47a6f7:	00 
  47a6f8:	0f 8a 92 00 00 00    	jp     47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a6fe:	0f 85 8c 00 00 00    	jne    47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a704:	f3 41 0f 10 87 44 01 	movss  0x144(%r15),%xmm0
  47a70b:	00 00 
  47a70d:	0f 2e 05 3c 98 03 00 	ucomiss 0x3983c(%rip),%xmm0        # 4b3f50 <C.119.3+0x1700>
  47a714:	7a 7a                	jp     47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a716:	75 78                	jne    47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a718:	f3 41 0f 10 87 48 01 	movss  0x148(%r15),%xmm0
  47a71f:	00 00 
  47a721:	0f 2e 05 2c 98 03 00 	ucomiss 0x3982c(%rip),%xmm0        # 4b3f54 <C.119.3+0x1704>
  47a728:	7a 66                	jp     47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a72a:	75 64                	jne    47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a72c:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47a730:	41 0f 2e 87 4c 01 00 	ucomiss 0x14c(%r15),%xmm0
  47a737:	00 
  47a738:	7a 56                	jp     47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a73a:	75 54                	jne    47a790 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x810>
  47a73c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  47a741:	f3 0f 6f 80 30 04 00 	movdqu 0x430(%rax),%xmm0
  47a748:	00 
  47a749:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
  47a750:	00 
  47a751:	f3 0f 6f 80 3c 04 00 	movdqu 0x43c(%rax),%xmm0
  47a758:	00 
  47a759:	0f 11 84 24 fc 01 00 	movups %xmm0,0x1fc(%rsp)
  47a760:	00 
  47a761:	66 0f 6f 84 24 f0 01 	movdqa 0x1f0(%rsp),%xmm0
  47a768:	00 00 
  47a76a:	41 0f 11 87 38 01 00 	movups %xmm0,0x138(%r15)
  47a771:	00 
  47a772:	f3 0f 6f 84 24 f9 01 	movdqu 0x1f9(%rsp),%xmm0
  47a779:	00 00 
  47a77b:	41 0f 11 87 41 01 00 	movups %xmm0,0x141(%r15)
  47a782:	00 
  47a783:	66 90                	xchg   %ax,%ax
  47a785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47a78c:	00 00 00 00 
  47a790:	49 8b 9f 08 01 00 00 	mov    0x108(%r15),%rbx
  47a797:	48 39 d9             	cmp    %rbx,%rcx
  47a79a:	72 5e                	jb     47a7fa <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x87a>
  47a79c:	31 ed                	xor    %ebp,%ebp
  47a79e:	f3 0f 11 4c 24 20    	movss  %xmm1,0x20(%rsp)
  47a7a4:	90                   	nop
  47a7a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47a7ac:	00 00 00 00 
  47a7b0:	48 89 df             	mov    %rbx,%rdi
  47a7b3:	49 89 ed             	mov    %rbp,%r13
  47a7b6:	e8 55 b0 fe ff       	call   465810 <skia::textlayout::Cluster::runOrNull() const>
  47a7bb:	48 89 c5             	mov    %rax,%rbp
  47a7be:	4c 39 e8             	cmp    %r13,%rax
  47a7c1:	74 1a                	je     47a7dd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x85d>
  47a7c3:	48 89 c7             	mov    %rax,%rdi
  47a7c6:	e8 b5 af fe ff       	call   465780 <skia::textlayout::Run::placeholderStyle() const>
  47a7cb:	48 85 c0             	test   %rax,%rax
  47a7ce:	74 0d                	je     47a7dd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x85d>
  47a7d0:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  47a7d5:	48 89 ef             	mov    %rbp,%rdi
  47a7d8:	e8 53 a5 fe ff       	call   464d30 <skia::textlayout::Run::updateMetrics(skia::textlayout::InternalLineMetrics*)>
  47a7dd:	49 8b 8f 18 01 00 00 	mov    0x118(%r15),%rcx
  47a7e4:	48 83 c3 40          	add    $0x40,%rbx
  47a7e8:	48 39 d9             	cmp    %rbx,%rcx
  47a7eb:	73 c3                	jae    47a7b0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x830>
  47a7ed:	f3 0f 10 4c 24 20    	movss  0x20(%rsp),%xmm1
  47a7f3:	49 8b 9f 08 01 00 00 	mov    0x108(%r15),%rbx
  47a7fa:	41 0f 10 af 38 01 00 	movups 0x138(%r15),%xmm5
  47a801:	00 
  47a802:	49 8b 87 48 01 00 00 	mov    0x148(%r15),%rax
  47a809:	f3 41 0f 10 a7 44 01 	movss  0x144(%r15),%xmm4
  47a810:	00 00 
  47a812:	48 8b 69 18          	mov    0x18(%rcx),%rbp
  47a816:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  47a81b:	4c 8b 6b 10          	mov    0x10(%rbx),%r13
  47a81f:	0f 29 ac 24 90 00 00 	movaps %xmm5,0x90(%rsp)
  47a826:	00 
  47a827:	f3 0f 10 44 24 20    	movss  0x20(%rsp),%xmm0
  47a82d:	f3 41 0f 10 af 3c 01 	movss  0x13c(%r15),%xmm5
  47a834:	00 00 
  47a836:	f3 41 0f 10 bf 48 01 	movss  0x148(%r15),%xmm7
  47a83d:	00 00 
  47a83f:	4c 39 64 24 10       	cmp    %r12,0x10(%rsp)
  47a844:	0f 84 a6 08 00 00    	je     47b0f0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1170>
  47a84a:	49 8b 87 28 01 00 00 	mov    0x128(%r15),%rax
  47a851:	48 8b 40 10          	mov    0x10(%rax),%rax
  47a855:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  47a85a:	49 8b 44 24 10       	mov    0x10(%r12),%rax
  47a85f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  47a864:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  47a869:	4c 89 e0             	mov    %r12,%rax
  47a86c:	48 29 f8             	sub    %rdi,%rax
  47a86f:	48 29 fb             	sub    %rdi,%rbx
  47a872:	48 c1 f8 06          	sar    $0x6,%rax
  47a876:	48 c1 fb 06          	sar    $0x6,%rbx
  47a87a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  47a87f:	f6 44 24 48 01       	testb  $0x1,0x48(%rsp)
  47a884:	74 10                	je     47a896 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x916>
  47a886:	80 7c 24 34 00       	cmpb   $0x0,0x34(%rsp)
  47a88b:	74 09                	je     47a896 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x916>
  47a88d:	f3 41 0f 11 a7 38 01 	movss  %xmm4,0x138(%r15)
  47a894:	00 00 
  47a896:	f6 44 24 48 02       	testb  $0x2,0x48(%rsp)
  47a89b:	74 23                	je     47a8c0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x940>
  47a89d:	80 bc 24 8b 00 00 00 	cmpb   $0x0,0x8b(%rsp)
  47a8a4:	00 
  47a8a5:	0f 85 c5 08 00 00    	jne    47b170 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x11f0>
  47a8ab:	4c 39 64 24 10       	cmp    %r12,0x10(%rsp)
  47a8b0:	0f 84 ac 08 00 00    	je     47b162 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x11e2>
  47a8b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  47a8bd:	00 00 00 
  47a8c0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  47a8c5:	80 78 39 00          	cmpb   $0x0,0x39(%rax)
  47a8c9:	0f 85 b1 07 00 00    	jne    47b080 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1100>
  47a8cf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  47a8d4:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  47a8d9:	f3 0f 11 4c 24 34    	movss  %xmm1,0x34(%rsp)
  47a8df:	e8 bc 00 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a8e4:	f3 0f 10 4c 24 34    	movss  0x34(%rsp),%xmm1
  47a8ea:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  47a8ef:	84 c0                	test   %al,%al
  47a8f1:	0f 85 79 06 00 00    	jne    47af70 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xff0>
  47a8f7:	f3 41 0f 10 87 3c 01 	movss  0x13c(%r15),%xmm0
  47a8fe:	00 00 
  47a900:	66 0f ef e4          	pxor   %xmm4,%xmm4
  47a904:	f3 41 0f 10 97 38 01 	movss  0x138(%r15),%xmm2
  47a90b:	00 00 
  47a90d:	f3 41 0f 5a a7 40 01 	cvtss2sd 0x140(%r15),%xmm4
  47a914:	00 00 
  47a916:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  47a91a:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  47a91e:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
  47a922:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  47a927:	f3 0f 11 4c 24 34    	movss  %xmm1,0x34(%rsp)
  47a92d:	f2 0f 58 c4          	addsd  %xmm4,%xmm0
  47a931:	e8 5a 44 bb ff       	call   2ed90 <round@plt>
  47a936:	66 0f ef ff          	pxor   %xmm7,%xmm7
  47a93a:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  47a93f:	49 8b 87 18 01 00 00 	mov    0x118(%r15),%rax
  47a946:	f2 0f 5a f8          	cvtsd2ss %xmm0,%xmm7
  47a94a:	49 39 87 08 01 00 00 	cmp    %rax,0x108(%r15)
  47a951:	f3 41 0f 10 87 54 01 	movss  0x154(%r15),%xmm0
  47a958:	00 00 
  47a95a:	f3 0f 11 7c 24 60    	movss  %xmm7,0x60(%rsp)
  47a960:	49 8b b7 20 01 00 00 	mov    0x120(%r15),%rsi
  47a967:	f3 0f 10 4c 24 34    	movss  0x34(%rsp),%xmm1
  47a96d:	f3 41 0f 10 97 6c 01 	movss  0x16c(%r15),%xmm2
  47a974:	00 00 
  47a976:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  47a97b:	0f 14 c7             	unpcklps %xmm7,%xmm0
  47a97e:	0f 84 2c 07 00 00    	je     47b0b0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1130>
  47a984:	48 39 c5             	cmp    %rax,%rbp
  47a987:	48 89 c7             	mov    %rax,%rdi
  47a98a:	48 0f 43 fd          	cmovae %rbp,%rdi
  47a98e:	31 d2                	xor    %edx,%edx
  47a990:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
  47a995:	74 0b                	je     47a9a2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xa22>
  47a997:	41 0f b6 97 6a 01 00 	movzbl 0x16a(%r15),%edx
  47a99e:	00 
  47a99f:	83 f2 01             	xor    $0x1,%edx
  47a9a2:	48 2b 4c 24 38       	sub    0x38(%rsp),%rcx
  47a9a7:	48 c1 f9 06          	sar    $0x6,%rcx
  47a9ab:	48 8d 41 01          	lea    0x1(%rcx),%rax
  47a9af:	49 8b 8f 10 01 00 00 	mov    0x110(%r15),%rcx
  47a9b6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  47a9bd:	00 
  47a9be:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  47a9c3:	0f 13 84 24 00 01 00 	movlps %xmm0,0x100(%rsp)
  47a9ca:	00 
  47a9cb:	f3 41 0f 6f 87 38 01 	movdqu 0x138(%r15),%xmm0
  47a9d2:	00 00 
  47a9d4:	48 89 bc 24 48 01 00 	mov    %rdi,0x148(%rsp)
  47a9db:	00 
  47a9dc:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  47a9e1:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  47a9e8:	00 
  47a9e9:	f3 41 0f 6f 87 44 01 	movdqu 0x144(%r15),%xmm0
  47a9f0:	00 00 
  47a9f2:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  47a9f9:	00 
  47a9fa:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  47a9ff:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
  47aa06:	00 
  47aa07:	48 89 ac 24 38 01 00 	mov    %rbp,0x138(%rsp)
  47aa0e:	00 
  47aa0f:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
  47aa16:	00 
  47aa17:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
  47aa1e:	00 
  47aa1f:	48 89 bc 24 58 01 00 	mov    %rdi,0x158(%rsp)
  47aa26:	00 
  47aa27:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
  47aa2e:	00 
  47aa2f:	48 89 9c 24 70 01 00 	mov    %rbx,0x170(%rsp)
  47aa36:	00 
  47aa37:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  47aa3e:	00 
  47aa3f:	48 89 b4 24 f8 00 00 	mov    %rsi,0xf8(%rsp)
  47aa46:	00 
  47aa47:	c7 84 24 18 01 00 00 	movl   $0x0,0x118(%rsp)
  47aa4e:	00 00 00 00 
  47aa52:	88 94 24 e6 00 00 00 	mov    %dl,0xe6(%rsp)
  47aa59:	f3 0f 11 8c 24 e8 00 	movss  %xmm1,0xe8(%rsp)
  47aa60:	00 00 
  47aa62:	f3 0f 11 94 24 1c 01 	movss  %xmm2,0x11c(%rsp)
  47aa69:	00 00 
  47aa6b:	0f 11 84 24 dc 01 00 	movups %xmm0,0x1dc(%rsp)
  47aa72:	00 
  47aa73:	48 83 78 10 00       	cmpq   $0x0,0x10(%rax)
  47aa78:	0f 84 aa ce bb ff    	je     37928 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]>
  47aa7e:	f3 0f 11 4c 24 34    	movss  %xmm1,0x34(%rsp)
  47aa84:	48 8d 8c 24 50 01 00 	lea    0x150(%rsp),%rcx
  47aa8b:	00 
  47aa8c:	48 8d 94 24 40 01 00 	lea    0x140(%rsp),%rdx
  47aa93:	00 
  47aa94:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
  47aa9b:	00 
  47aa9c:	48 83 ec 08          	sub    $0x8,%rsp
  47aaa0:	48 8d 84 24 ee 00 00 	lea    0xee(%rsp),%rax
  47aaa7:	00 
  47aaa8:	50                   	push   %rax
  47aaa9:	48 8d 84 24 e0 01 00 	lea    0x1e0(%rsp),%rax
  47aab0:	00 
  47aab1:	50                   	push   %rax
  47aab2:	48 8d 84 24 18 01 00 	lea    0x118(%rsp),%rax
  47aab9:	00 
  47aaba:	50                   	push   %rax
  47aabb:	48 8d 84 24 38 01 00 	lea    0x138(%rsp),%rax
  47aac2:	00 
  47aac3:	50                   	push   %rax
  47aac4:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
  47aacb:	00 
  47aacc:	50                   	push   %rax
  47aacd:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
  47aad4:	00 
  47aad5:	50                   	push   %rax
  47aad6:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
  47aadd:	00 
  47aade:	50                   	push   %rax
  47aadf:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  47aae6:	00 
  47aae7:	48 89 c7             	mov    %rax,%rdi
  47aaea:	4c 8d 8c 24 b0 01 00 	lea    0x1b0(%rsp),%r9
  47aaf1:	00 
  47aaf2:	4c 8d 84 24 a0 01 00 	lea    0x1a0(%rsp),%r8
  47aaf9:	00 
  47aafa:	ff 50 18             	call   *0x18(%rax)
  47aafd:	f3 0f 10 74 24 70    	movss  0x70(%rsp),%xmm6
  47ab03:	f3 0f 10 4c 24 74    	movss  0x74(%rsp),%xmm1
  47ab09:	f3 0f 58 f1          	addss  %xmm1,%xmm6
  47ab0d:	0f 28 c6             	movaps %xmm6,%xmm0
  47ab10:	f3 0f 11 74 24 70    	movss  %xmm6,0x70(%rsp)
  47ab16:	48 83 c4 40          	add    $0x40,%rsp
  47ab1a:	f3 41 0f 5f 87 74 01 	maxss  0x174(%r15),%xmm0
  47ab21:	00 00 
  47ab23:	f3 41 0f 11 87 74 01 	movss  %xmm0,0x174(%r15)
  47ab2a:	00 00 
  47ab2c:	41 80 bf 6a 01 00 00 	cmpb   $0x0,0x16a(%r15)
  47ab33:	00 
  47ab34:	74 08                	je     47ab3e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xbbe>
  47ab36:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
  47ab3d:	00 
  47ab3e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  47ab43:	f3 0f 11 4c 24 50    	movss  %xmm1,0x50(%rsp)
  47ab49:	e8 52 fe fd ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47ab4e:	4d 39 e6             	cmp    %r12,%r14
  47ab51:	0f 93 c2             	setae  %dl
  47ab54:	20 c2                	and    %al,%dl
  47ab56:	88 54 24 34          	mov    %dl,0x34(%rsp)
  47ab5a:	0f 85 62 13 00 00    	jne    47bec2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1f42>
  47ab60:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  47ab66:	41 80 bf 6a 01 00 00 	cmpb   $0x1,0x16a(%r15)
  47ab6d:	01 
  47ab6e:	f3 41 0f 58 87 6c 01 	addss  0x16c(%r15),%xmm0
  47ab75:	00 00 
  47ab77:	f3 0f 10 4c 24 50    	movss  0x50(%rsp),%xmm1
  47ab7d:	f3 41 0f 11 87 6c 01 	movss  %xmm0,0x16c(%r15)
  47ab84:	00 00 
  47ab86:	75 07                	jne    47ab8f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc0f>
  47ab88:	4c 39 64 24 10       	cmp    %r12,0x10(%rsp)
  47ab8d:	74 26                	je     47abb5 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc35>
  47ab8f:	b8 ff ff 7f ff       	mov    $0xff7fffff,%eax
  47ab94:	0f 28 2d b5 93 03 00 	movaps 0x393b5(%rip),%xmm5        # 4b3f50 <C.119.3+0x1700>
  47ab9b:	41 c7 87 54 01 00 00 	movl   $0x0,0x154(%r15)
  47aba2:	00 00 00 00 
  47aba6:	49 89 87 48 01 00 00 	mov    %rax,0x148(%r15)
  47abad:	41 0f 11 af 38 01 00 	movups %xmm5,0x138(%r15)
  47abb4:	00 
  47abb5:	4d 89 a7 08 01 00 00 	mov    %r12,0x108(%r15)
  47abbc:	4c 89 e7             	mov    %r12,%rdi
  47abbf:	49 c7 87 10 01 00 00 	movq   $0x0,0x110(%r15)
  47abc6:	00 00 00 00 
  47abca:	4d 89 a7 18 01 00 00 	mov    %r12,0x118(%r15)
  47abd1:	49 c7 87 20 01 00 00 	movq   $0xffffffffffffffff,0x120(%r15)
  47abd8:	ff ff ff ff 
  47abdc:	f3 0f 11 4c 24 50    	movss  %xmm1,0x50(%rsp)
  47abe2:	e8 29 ac fe ff       	call   465810 <skia::textlayout::Cluster::runOrNull() const>
  47abe7:	f3 0f 10 4c 24 50    	movss  0x50(%rsp),%xmm1
  47abed:	48 85 c0             	test   %rax,%rax
  47abf0:	74 0b                	je     47abfd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc7d>
  47abf2:	48 83 78 40 ff       	cmpq   $0xffffffffffffffff,0x40(%rax)
  47abf7:	0f 84 bb 05 00 00    	je     47b1b8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1238>
  47abfd:	41 c7 87 54 01 00 00 	movl   $0x0,0x154(%r15)
  47ac04:	00 00 00 00 
  47ac08:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  47ac0d:	f3 0f 10 a8 70 04 00 	movss  0x470(%rax),%xmm5
  47ac14:	00 
  47ac15:	f3 0f 5f cd          	maxss  %xmm5,%xmm1
  47ac19:	f3 0f 11 6c 24 50    	movss  %xmm5,0x50(%rsp)
  47ac1f:	f3 0f 11 88 70 04 00 	movss  %xmm1,0x470(%rax)
  47ac26:	00 
  47ac27:	80 bc 24 b2 00 00 00 	cmpb   $0x0,0xb2(%rsp)
  47ac2e:	00 
  47ac2f:	0f 84 5b 01 00 00    	je     47ad90 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe10>
  47ac35:	41 0f b6 87 6a 01 00 	movzbl 0x16a(%r15),%eax
  47ac3c:	00 
  47ac3d:	88 84 24 8b 00 00 00 	mov    %al,0x8b(%rsp)
  47ac44:	84 c0                	test   %al,%al
  47ac46:	0f 84 f0 10 00 00    	je     47bd3c <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1dbc>
  47ac4c:	49 83 87 60 01 00 00 	addq   $0x1,0x160(%r15)
  47ac53:	01 
  47ac54:	4d 8b b7 18 01 00 00 	mov    0x118(%r15),%r14
  47ac5b:	4c 3b 74 24 10       	cmp    0x10(%rsp),%r14
  47ac60:	0f 84 f0 10 00 00    	je     47bd56 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1dd6>
  47ac66:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  47ac6b:	0f b6 9c 24 b3 00 00 	movzbl 0xb3(%rsp),%ebx
  47ac72:	00 
  47ac73:	e8 28 fd fd ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47ac78:	84 c0                	test   %al,%al
  47ac7a:	0f 85 be f7 ff ff    	jne    47a43e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4be>
  47ac80:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  47ac85:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  47ac8a:	0f b6 eb             	movzbl %bl,%ebp
  47ac8d:	4c 89 ff             	mov    %r15,%rdi
  47ac90:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  47ac97:	00 
  47ac98:	f3 0f 10 44 24 4c    	movss  0x4c(%rsp),%xmm0
  47ac9e:	41 89 e8             	mov    %ebp,%r8d
  47aca1:	41 0f b6 94 24 33 02 	movzbl 0x233(%r12),%edx
  47aca8:	00 00 
  47acaa:	e8 11 c8 ff ff       	call   4774c0 <skia::textlayout::TextWrapper::lookAhead(float, skia::textlayout::Cluster*, bool, SkString const*, bool)>
  47acaf:	4c 89 e7             	mov    %r12,%rdi
  47acb2:	e8 e9 fc fd ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47acb7:	e9 84 f9 ff ff       	jmp    47a640 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x6c0>
  47acbc:	0f 1f 40 00          	nopl   0x0(%rax)
  47acc0:	48 85 d2             	test   %rdx,%rdx
  47acc3:	0f 84 98 f8 ff ff    	je     47a561 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x5e1>
  47acc9:	48 89 d0             	mov    %rdx,%rax
  47accc:	e9 6f f8 ff ff       	jmp    47a540 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x5c0>
  47acd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47acd8:	41 0f b6 45 fa       	movzbl -0x6(%r13),%eax
  47acdd:	84 c0                	test   %al,%al
  47acdf:	0f 84 eb f8 ff ff    	je     47a5d0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x650>
  47ace5:	e9 ef f8 ff ff       	jmp    47a5d9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x659>
  47acea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  47acf0:	f3 0f 10 7c 24 4c    	movss  0x4c(%rsp),%xmm7
  47acf6:	0f 2f f8             	comiss %xmm0,%xmm7
  47acf9:	0f 83 b1 01 00 00    	jae    47aeb0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xf30>
  47acff:	41 0f b6 45 fa       	movzbl -0x6(%r13),%eax
  47ad04:	4d 89 ee             	mov    %r13,%r14
  47ad07:	eb d4                	jmp    47acdd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd5d>
  47ad09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47ad10:	49 8b 47 10          	mov    0x10(%r15),%rax
  47ad14:	48 89 c2             	mov    %rax,%rdx
  47ad17:	e9 cd f7 ff ff       	jmp    47a4e9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x569>
  47ad1c:	0f 1f 40 00          	nopl   0x0(%rax)
  47ad20:	f3 41 0f 10 87 58 01 	movss  0x158(%r15),%xmm0
  47ad27:	00 00 
  47ad29:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  47ad2e:	4c 89 e0             	mov    %r12,%rax
  47ad31:	0f 28 c8             	movaps %xmm0,%xmm1
  47ad34:	49 39 cc             	cmp    %rcx,%r12
  47ad37:	72 15                	jb     47ad4e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xdce>
  47ad39:	eb 19                	jmp    47ad54 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xdd4>
  47ad3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  47ad40:	f3 0f 58 48 30       	addss  0x30(%rax),%xmm1
  47ad45:	48 83 c0 40          	add    $0x40,%rax
  47ad49:	48 39 c8             	cmp    %rcx,%rax
  47ad4c:	73 06                	jae    47ad54 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xdd4>
  47ad4e:	80 78 38 00          	cmpb   $0x0,0x38(%rax)
  47ad52:	75 ec                	jne    47ad40 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xdc0>
  47ad54:	80 7a 38 00          	cmpb   $0x0,0x38(%rdx)
  47ad58:	74 19                	je     47ad73 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xdf3>
  47ad5a:	48 3b 54 24 10       	cmp    0x10(%rsp),%rdx
  47ad5f:	73 12                	jae    47ad73 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xdf3>
  47ad61:	4d 89 a7 28 01 00 00 	mov    %r12,0x128(%r15)
  47ad68:	49 c7 87 30 01 00 00 	movq   $0x0,0x130(%r15)
  47ad6f:	00 00 00 00 
  47ad73:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
  47ad78:	0f 85 0a 04 00 00    	jne    47b188 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1208>
  47ad7e:	49 8b 8f 18 01 00 00 	mov    0x118(%r15),%rcx
  47ad85:	49 89 c4             	mov    %rax,%r12
  47ad88:	e9 27 f9 ff ff       	jmp    47a6b4 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x734>
  47ad8d:	0f 1f 00             	nopl   (%rax)
  47ad90:	0f b6 bc 24 8b 00 00 	movzbl 0x8b(%rsp),%edi
  47ad97:	00 
  47ad98:	4c 89 fd             	mov    %r15,%rbp
  47ad9b:	f3 0f 10 5c 24 30    	movss  0x30(%rsp),%xmm3
  47ada1:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  47ada6:	40 84 ff             	test   %dil,%dil
  47ada9:	0f 85 ae 09 00 00    	jne    47b75d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x17dd>
  47adaf:	48 83 85 60 01 00 00 	addq   $0x1,0x160(%rbp)
  47adb6:	01 
  47adb7:	4c 8b ad 18 01 00 00 	mov    0x118(%rbp),%r13
  47adbe:	4c 39 6c 24 10       	cmp    %r13,0x10(%rsp)
  47adc3:	0f 85 17 f6 ff ff    	jne    47a3e0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x460>
  47adc9:	8b 5c 24 48          	mov    0x48(%rsp),%ebx
  47adcd:	83 e3 01             	and    $0x1,%ebx
  47add0:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  47add5:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47add9:	eb 34                	jmp    47ae0f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe8f>
  47addb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  47ade0:	f3 0f 7e 95 70 01 00 	movq   0x170(%rbp),%xmm2
  47ade7:	00 
  47ade8:	f3 0f 7e d9          	movq   %xmm1,%xmm3
  47adec:	f3 0f 7e c2          	movq   %xmm2,%xmm0
  47adf0:	0f c2 c3 01          	cmpltps %xmm3,%xmm0
  47adf4:	0f 54 c8             	andps  %xmm0,%xmm1
  47adf7:	0f 55 c2             	andnps %xmm2,%xmm0
  47adfa:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47adfe:	0f 56 c1             	orps   %xmm1,%xmm0
  47ae01:	0f 28 da             	movaps %xmm2,%xmm3
  47ae04:	0f 13 85 70 01 00 00 	movlps %xmm0,0x170(%rbp)
  47ae0b:	49 83 c5 40          	add    $0x40,%r13
  47ae0f:	0f 28 ca             	movaps %xmm2,%xmm1
  47ae12:	0f 14 cb             	unpcklps %xmm3,%xmm1
  47ae15:	4d 39 e5             	cmp    %r12,%r13
  47ae18:	0f 84 a2 00 00 00    	je     47aec0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xf40>
  47ae1e:	c6 85 6b 01 00 00 01 	movb   $0x1,0x16b(%rbp)
  47ae25:	41 80 7d 3a 00       	cmpb   $0x0,0x3a(%r13)
  47ae2a:	75 b4                	jne    47ade0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe60>
  47ae2c:	41 80 7d 38 00       	cmpb   $0x0,0x38(%r13)
  47ae31:	0f 84 d9 02 00 00    	je     47b110 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1190>
  47ae37:	f3 0f 5f 95 70 01 00 	maxss  0x170(%rbp),%xmm2
  47ae3e:	00 
  47ae3f:	f3 41 0f 58 5d 30    	addss  0x30(%r13),%xmm3
  47ae45:	f3 0f 11 95 70 01 00 	movss  %xmm2,0x170(%rbp)
  47ae4c:	00 
  47ae4d:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47ae51:	eb b8                	jmp    47ae0b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe8b>
  47ae53:	4d 85 e4             	test   %r12,%r12
  47ae56:	75 11                	jne    47ae69 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xee9>
  47ae58:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  47ae5d:	48 85 c0             	test   %rax,%rax
  47ae60:	49 89 c4             	mov    %rax,%r12
  47ae63:	4c 0f 44 64 24 10    	cmove  0x10(%rsp),%r12
  47ae69:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  47ae6e:	0f b6 eb             	movzbl %bl,%ebp
  47ae71:	4c 89 ff             	mov    %r15,%rdi
  47ae74:	4c 89 e6             	mov    %r12,%rsi
  47ae77:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  47ae7e:	00 
  47ae7f:	41 89 e8             	mov    %ebp,%r8d
  47ae82:	0f 28 c2             	movaps %xmm2,%xmm0
  47ae85:	41 0f b6 95 33 02 00 	movzbl 0x233(%r13),%edx
  47ae8c:	00 
  47ae8d:	e8 2e c6 ff ff       	call   4774c0 <skia::textlayout::TextWrapper::lookAhead(float, skia::textlayout::Cluster*, bool, SkString const*, bool)>
  47ae92:	4c 89 ef             	mov    %r13,%rdi
  47ae95:	e8 06 fb fd ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47ae9a:	84 c0                	test   %al,%al
  47ae9c:	0f 84 9e f7 ff ff    	je     47a640 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x6c0>
  47aea2:	41 c6 87 68 01 00 00 	movb   $0x1,0x168(%r15)
  47aea9:	01 
  47aeaa:	e9 91 f7 ff ff       	jmp    47a640 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x6c0>
  47aeaf:	90                   	nop
  47aeb0:	4d 89 ee             	mov    %r13,%r14
  47aeb3:	e9 d7 f6 ff ff       	jmp    47a58f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x60f>
  47aeb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  47aebf:	00 
  47aec0:	f3 0f 7e 95 70 01 00 	movq   0x170(%rbp),%xmm2
  47aec7:	00 
  47aec8:	f3 0f 7e d9          	movq   %xmm1,%xmm3
  47aecc:	41 8b 87 10 04 00 00 	mov    0x410(%r15),%eax
  47aed3:	f3 0f 7e c2          	movq   %xmm2,%xmm0
  47aed7:	0f c2 c3 01          	cmpltps %xmm3,%xmm0
  47aedb:	0f 54 c8             	andps  %xmm0,%xmm1
  47aede:	0f 55 c2             	andnps %xmm2,%xmm0
  47aee1:	0f 56 c1             	orps   %xmm1,%xmm0
  47aee4:	0f 13 85 70 01 00 00 	movlps %xmm0,0x170(%rbp)
  47aeeb:	85 c0                	test   %eax,%eax
  47aeed:	0f 85 8d 08 00 00    	jne    47b780 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1800>
  47aef3:	85 db                	test   %ebx,%ebx
  47aef5:	0f 85 89 0d 00 00    	jne    47bc84 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1d04>
  47aefb:	f3 0f 10 8d 38 01 00 	movss  0x138(%rbp),%xmm1
  47af02:	00 
  47af03:	44 0f b6 a5 6a 01 00 	movzbl 0x16a(%rbp),%r12d
  47af0a:	00 
  47af0b:	f6 44 24 48 02       	testb  $0x2,0x48(%rsp)
  47af10:	0f 84 83 0d 00 00    	je     47bc99 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1d19>
  47af16:	45 84 e4             	test   %r12b,%r12b
  47af19:	0f 85 7a 0d 00 00    	jne    47bc99 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1d19>
  47af1f:	f3 0f 10 85 48 01 00 	movss  0x148(%rbp),%xmm0
  47af26:	00 
  47af27:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  47af2b:	f3 0f 11 85 3c 01 00 	movss  %xmm0,0x13c(%rbp)
  47af32:	00 
  47af33:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  47af37:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
  47af3b:	66 0f ef c9          	pxor   %xmm1,%xmm1
  47af3f:	f3 0f 5a 8d 40 01 00 	cvtss2sd 0x140(%rbp),%xmm1
  47af46:	00 
  47af47:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
  47af4b:	e8 40 3e bb ff       	call   2ed90 <round@plt>
  47af50:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  47af54:	f3 0f 5f 85 6c 01 00 	maxss  0x16c(%rbp),%xmm0
  47af5b:	00 
  47af5c:	f3 0f 11 85 6c 01 00 	movss  %xmm0,0x16c(%rbp)
  47af63:	00 
  47af64:	e9 52 08 00 00       	jmp    47b7bb <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x183b>
  47af69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47af70:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  47af75:	48 89 ea             	mov    %rbp,%rdx
  47af78:	4c 89 ee             	mov    %r13,%rsi
  47af7b:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  47af80:	f3 0f 11 4c 24 34    	movss  %xmm1,0x34(%rsp)
  47af86:	e8 35 03 fe ff       	call   45b2c0 <skia::textlayout::ParagraphImpl::experimentalVerticalPadding(skia::textlayout::SkRange<unsigned long>) const>
  47af8b:	f3 0f 10 4c 24 34    	movss  0x34(%rsp),%xmm1
  47af91:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  47af96:	f3 0f 10 25 b2 7a 03 	movss  0x37ab2(%rip),%xmm4        # 4b2a50 <C.119.3+0x200>
  47af9d:	00 
  47af9e:	44 0f 28 c0          	movaps %xmm0,%xmm8
  47afa2:	f3 0f 10 05 5a c0 02 	movss  0x2c05a(%rip),%xmm0        # 4a7004 <_IO_stdin_used+0x4>
  47afa9:	00 
  47afaa:	f3 0f 10 3d 92 c0 02 	movss  0x2c092(%rip),%xmm7        # 4a7044 <_IO_stdin_used+0x44>
  47afb1:	00 
  47afb2:	0f 28 dc             	movaps %xmm4,%xmm3
  47afb5:	f3 41 0f 59 87 40 01 	mulss  0x140(%r15),%xmm0
  47afbc:	00 00 
  47afbe:	0f 28 d0             	movaps %xmm0,%xmm2
  47afc1:	f3 41 0f 5c 97 38 01 	subss  0x138(%r15),%xmm2
  47afc8:	00 00 
  47afca:	f3 41 0f 58 d0       	addss  %xmm8,%xmm2
  47afcf:	0f 28 ea             	movaps %xmm2,%xmm5
  47afd2:	0f 54 ec             	andps  %xmm4,%xmm5
  47afd5:	0f 2e fd             	ucomiss %xmm5,%xmm7
  47afd8:	76 31                	jbe    47b00b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x108b>
  47afda:	f3 0f 2c c2          	cvttss2si %xmm2,%eax
  47afde:	66 0f ef ed          	pxor   %xmm5,%xmm5
  47afe2:	44 0f 28 ca          	movaps %xmm2,%xmm9
  47afe6:	f3 44 0f 10 15 2d c0 	movss  0x2c02d(%rip),%xmm10        # 4a701c <_IO_stdin_used+0x1c>
  47afed:	02 00 
  47afef:	0f 55 da             	andnps %xmm2,%xmm3
  47aff2:	f3 0f 2a e8          	cvtsi2ss %eax,%xmm5
  47aff6:	f3 44 0f c2 cd 06    	cmpnless %xmm5,%xmm9
  47affc:	45 0f 54 ca          	andps  %xmm10,%xmm9
  47b000:	f3 41 0f 58 e9       	addss  %xmm9,%xmm5
  47b005:	0f 56 eb             	orps   %xmm3,%xmm5
  47b008:	0f 28 d5             	movaps %xmm5,%xmm2
  47b00b:	f3 41 0f 58 87 3c 01 	addss  0x13c(%r15),%xmm0
  47b012:	00 00 
  47b014:	f3 41 0f 58 c0       	addss  %xmm8,%xmm0
  47b019:	0f 28 e8             	movaps %xmm0,%xmm5
  47b01c:	0f 54 ec             	andps  %xmm4,%xmm5
  47b01f:	0f 2e fd             	ucomiss %xmm5,%xmm7
  47b022:	76 2c                	jbe    47b050 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x10d0>
  47b024:	f3 0f 2c c0          	cvttss2si %xmm0,%eax
  47b028:	66 0f ef ed          	pxor   %xmm5,%xmm5
  47b02c:	0f 28 f0             	movaps %xmm0,%xmm6
  47b02f:	f3 0f 10 3d e5 bf 02 	movss  0x2bfe5(%rip),%xmm7        # 4a701c <_IO_stdin_used+0x1c>
  47b036:	00 
  47b037:	0f 55 e0             	andnps %xmm0,%xmm4
  47b03a:	f3 0f 2a e8          	cvtsi2ss %eax,%xmm5
  47b03e:	f3 0f c2 f5 06       	cmpnless %xmm5,%xmm6
  47b043:	0f 54 f7             	andps  %xmm7,%xmm6
  47b046:	f3 0f 58 ee          	addss  %xmm6,%xmm5
  47b04a:	0f 56 ec             	orps   %xmm4,%xmm5
  47b04d:	0f 28 c5             	movaps %xmm5,%xmm0
  47b050:	0f 57 15 39 79 03 00 	xorps  0x37939(%rip),%xmm2        # 4b2990 <C.119.3+0x140>
  47b057:	66 0f ef e4          	pxor   %xmm4,%xmm4
  47b05b:	41 c7 87 40 01 00 00 	movl   $0x0,0x140(%r15)
  47b062:	00 00 00 00 
  47b066:	0f 28 da             	movaps %xmm2,%xmm3
  47b069:	0f 14 d8             	unpcklps %xmm0,%xmm3
  47b06c:	41 0f 13 9f 38 01 00 	movlps %xmm3,0x138(%r15)
  47b073:	00 
  47b074:	e9 9d f8 ff ff       	jmp    47a916 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x996>
  47b079:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47b080:	0f 10 90 4c 04 00 00 	movups 0x44c(%rax),%xmm2
  47b087:	41 80 bf 50 01 00 00 	cmpb   $0x0,0x150(%r15)
  47b08e:	00 
  47b08f:	0f 84 bb 05 00 00    	je     47b650 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x16d0>
  47b095:	48 8b 80 5c 04 00 00 	mov    0x45c(%rax),%rax
  47b09c:	41 0f 11 97 38 01 00 	movups %xmm2,0x138(%r15)
  47b0a3:	00 
  47b0a4:	49 89 87 48 01 00 00 	mov    %rax,0x148(%r15)
  47b0ab:	e9 1f f8 ff ff       	jmp    47a8cf <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x94f>
  47b0b0:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  47b0b4:	0f 85 ca f8 ff ff    	jne    47a984 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xa04>
  47b0ba:	49 39 c5             	cmp    %rax,%r13
  47b0bd:	48 89 c7             	mov    %rax,%rdi
  47b0c0:	49 0f 43 fd          	cmovae %r13,%rdi
  47b0c4:	31 d2                	xor    %edx,%edx
  47b0c6:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
  47b0cb:	74 0b                	je     47b0d8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1158>
  47b0cd:	41 0f b6 97 6a 01 00 	movzbl 0x16a(%r15),%edx
  47b0d4:	00 
  47b0d5:	83 f2 01             	xor    $0x1,%edx
  47b0d8:	49 8b b7 10 01 00 00 	mov    0x110(%r15),%rsi
  47b0df:	4c 89 ed             	mov    %r13,%rbp
  47b0e2:	48 89 d8             	mov    %rbx,%rax
  47b0e5:	48 89 f1             	mov    %rsi,%rcx
  47b0e8:	e9 c9 f8 ff ff       	jmp    47a9b6 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xa36>
  47b0ed:	0f 1f 00             	nopl   (%rax)
  47b0f0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  47b0f5:	48 8b 80 48 03 00 00 	mov    0x348(%rax),%rax
  47b0fc:	8b 00                	mov    (%rax),%eax
  47b0fe:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  47b103:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  47b108:	e9 57 f7 ff ff       	jmp    47a864 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x8e4>
  47b10d:	0f 1f 00             	nopl   (%rax)
  47b110:	4c 89 ef             	mov    %r13,%rdi
  47b113:	f3 0f 11 5c 24 10    	movss  %xmm3,0x10(%rsp)
  47b119:	f3 0f 11 54 24 08    	movss  %xmm2,0x8(%rsp)
  47b11f:	e8 3c a7 fe ff       	call   465860 <skia::textlayout::Cluster::run() const>
  47b124:	f3 41 0f 10 45 30    	movss  0x30(%r13),%xmm0
  47b12a:	f3 0f 10 5c 24 10    	movss  0x10(%rsp),%xmm3
  47b130:	48 83 78 40 ff       	cmpq   $0xffffffffffffffff,0x40(%rax)
  47b135:	f3 0f 10 54 24 08    	movss  0x8(%rsp),%xmm2
  47b13b:	f3 0f 58 d8          	addss  %xmm0,%xmm3
  47b13f:	0f 84 98 05 00 00    	je     47b6dd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x175d>
  47b145:	f3 0f 5f 95 70 01 00 	maxss  0x170(%rbp),%xmm2
  47b14c:	00 
  47b14d:	f3 0f 5f c2          	maxss  %xmm2,%xmm0
  47b151:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47b155:	f3 0f 11 85 70 01 00 	movss  %xmm0,0x170(%rbp)
  47b15c:	00 
  47b15d:	e9 a9 fc ff ff       	jmp    47ae0b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe8b>
  47b162:	41 80 bf 6a 01 00 00 	cmpb   $0x0,0x16a(%r15)
  47b169:	00 
  47b16a:	0f 85 50 f7 ff ff    	jne    47a8c0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x940>
  47b170:	f3 41 0f 11 87 3c 01 	movss  %xmm0,0x13c(%r15)
  47b177:	00 00 
  47b179:	0f 28 e8             	movaps %xmm0,%xmm5
  47b17c:	e9 3f f7 ff ff       	jmp    47a8c0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x940>
  47b181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47b188:	f3 41 0f 6f 8f 28 01 	movdqu 0x128(%r15),%xmm1
  47b18f:	00 00 
  47b191:	49 89 c4             	mov    %rax,%r12
  47b194:	f3 41 0f 11 87 54 01 	movss  %xmm0,0x154(%r15)
  47b19b:	00 00 
  47b19d:	66 48 0f 7e c9       	movq   %xmm1,%rcx
  47b1a2:	41 0f 11 8f 18 01 00 	movups %xmm1,0x118(%r15)
  47b1a9:	00 
  47b1aa:	0f 28 c8             	movaps %xmm0,%xmm1
  47b1ad:	e9 02 f5 ff ff       	jmp    47a6b4 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x734>
  47b1b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  47b1b8:	41 80 bf 50 01 00 00 	cmpb   $0x0,0x150(%r15)
  47b1bf:	00 
  47b1c0:	0f 85 37 fa ff ff    	jne    47abfd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc7d>
  47b1c6:	f3 0f 10 80 d8 00 00 	movss  0xd8(%rax),%xmm0
  47b1cd:	00 
  47b1ce:	f3 0f 10 90 dc 00 00 	movss  0xdc(%rax),%xmm2
  47b1d5:	00 
  47b1d6:	f3 0f 10 98 e0 00 00 	movss  0xe0(%rax),%xmm3
  47b1dd:	00 
  47b1de:	f3 0f 10 a8 98 00 00 	movss  0x98(%rax),%xmm5
  47b1e5:	00 
  47b1e6:	f3 0f 10 a0 e4 00 00 	movss  0xe4(%rax),%xmm4
  47b1ed:	00 
  47b1ee:	f3 0f 58 d0          	addss  %xmm0,%xmm2
  47b1f2:	f3 41 0f 5f a7 40 01 	maxss  0x140(%r15),%xmm4
  47b1f9:	00 00 
  47b1fb:	f3 0f 58 d8          	addss  %xmm0,%xmm3
  47b1ff:	f3 0f 58 e8          	addss  %xmm0,%xmm5
  47b203:	f3 41 0f 5d 97 38 01 	minss  0x138(%r15),%xmm2
  47b20a:	00 00 
  47b20c:	f3 41 0f 5d af 44 01 	minss  0x144(%r15),%xmm5
  47b213:	00 00 
  47b215:	f3 41 0f 5f 9f 3c 01 	maxss  0x13c(%r15),%xmm3
  47b21c:	00 00 
  47b21e:	0f 14 e5             	unpcklps %xmm5,%xmm4
  47b221:	0f 14 d3             	unpcklps %xmm3,%xmm2
  47b224:	0f 16 d4             	movlhps %xmm4,%xmm2
  47b227:	41 0f 11 97 38 01 00 	movups %xmm2,0x138(%r15)
  47b22e:	00 
  47b22f:	f3 0f 58 80 9c 00 00 	addss  0x9c(%rax),%xmm0
  47b236:	00 
  47b237:	f3 0f 10 90 a4 00 00 	movss  0xa4(%rax),%xmm2
  47b23e:	00 
  47b23f:	f3 41 0f 7e a7 48 01 	movq   0x148(%r15),%xmm4
  47b246:	00 00 
  47b248:	0f 14 c2             	unpcklps %xmm2,%xmm0
  47b24b:	f3 0f 7e d4          	movq   %xmm4,%xmm2
  47b24f:	f3 0f 7e e8          	movq   %xmm0,%xmm5
  47b253:	0f c2 d5 01          	cmpltps %xmm5,%xmm2
  47b257:	0f 54 c2             	andps  %xmm2,%xmm0
  47b25a:	0f 55 d4             	andnps %xmm4,%xmm2
  47b25d:	0f 56 d0             	orps   %xmm0,%xmm2
  47b260:	41 0f 13 97 48 01 00 	movlps %xmm2,0x148(%r15)
  47b267:	00 
  47b268:	e9 90 f9 ff ff       	jmp    47abfd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc7d>
  47b26d:	0f 1f 00             	nopl   (%rax)
  47b270:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  47b275:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
  47b27a:	e9 5e fa ff ff       	jmp    47acdd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd5d>
  47b27f:	90                   	nop
  47b280:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  47b287:	00 00 
  47b289:	4d 89 f5             	mov    %r14,%r13
  47b28c:	45 31 e4             	xor    %r12d,%r12d
  47b28f:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  47b296:	00 
  47b297:	88 9c 24 db 00 00 00 	mov    %bl,0xdb(%rsp)
  47b29e:	f3 0f 10 15 aa 8c 03 	movss  0x38caa(%rip),%xmm2        # 4b3f50 <C.119.3+0x1700>
  47b2a5:	00 
  47b2a6:	66 0f ef db          	pxor   %xmm3,%xmm3
  47b2aa:	41 ba 05 00 00 00    	mov    $0x5,%r10d
  47b2b0:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
  47b2b7:	00 
  47b2b8:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  47b2bf:	00 
  47b2c0:	49 89 d1             	mov    %rdx,%r9
  47b2c3:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  47b2c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  47b2cf:	00 
  47b2d0:	4c 3b 6c 24 10       	cmp    0x10(%rsp),%r13
  47b2d5:	0f 83 50 01 00 00    	jae    47b42b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x14ab>
  47b2db:	f3 41 0f 10 45 30    	movss  0x30(%r13),%xmm0
  47b2e1:	49 83 c5 40          	add    $0x40,%r13
  47b2e5:	f3 0f 58 d8          	addss  %xmm0,%xmm3
  47b2e9:	0f 54 05 60 77 03 00 	andps  0x37760(%rip),%xmm0        # 4b2a50 <C.119.3+0x200>
  47b2f0:	0f 2e d0             	ucomiss %xmm0,%xmm2
  47b2f3:	0f 82 1f 03 00 00    	jb     47b618 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1698>
  47b2f9:	0f 28 c3             	movaps %xmm3,%xmm0
  47b2fc:	0f 54 05 4d 77 03 00 	andps  0x3774d(%rip),%xmm0        # 4b2a50 <C.119.3+0x200>
  47b303:	0f 2e d0             	ucomiss %xmm0,%xmm2
  47b306:	0f 82 24 03 00 00    	jb     47b630 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x16b0>
  47b30c:	0f 28 c3             	movaps %xmm3,%xmm0
  47b30f:	4c 89 eb             	mov    %r13,%rbx
  47b312:	4d 39 ee             	cmp    %r13,%r14
  47b315:	0f 83 cd 02 00 00    	jae    47b5e8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1668>
  47b31b:	0f 28 c3             	movaps %xmm3,%xmm0
  47b31e:	4c 89 eb             	mov    %r13,%rbx
  47b321:	eb 3c                	jmp    47b35f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x13df>
  47b323:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47b32a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47b331:	00 00 00 00 
  47b335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47b33c:	00 00 00 00 
  47b340:	f3 0f 5c 43 f0       	subss  -0x10(%rbx),%xmm0
  47b345:	48 83 eb 40          	sub    $0x40,%rbx
  47b349:	0f 28 c8             	movaps %xmm0,%xmm1
  47b34c:	0f 54 0d fd 76 03 00 	andps  0x376fd(%rip),%xmm1        # 4b2a50 <C.119.3+0x200>
  47b353:	0f 2e d1             	ucomiss %xmm1,%xmm2
  47b356:	45 0f 42 e2          	cmovb  %r10d,%r12d
  47b35a:	49 39 de             	cmp    %rbx,%r14
  47b35d:	73 10                	jae    47b36f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x13ef>
  47b35f:	80 7b f8 00          	cmpb   $0x0,-0x8(%rbx)
  47b363:	75 db                	jne    47b340 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x13c0>
  47b365:	0f 28 c8             	movaps %xmm0,%xmm1
  47b368:	0f 54 0d e1 76 03 00 	andps  0x376e1(%rip),%xmm1        # 4b2a50 <C.119.3+0x200>
  47b36f:	0f 2e d1             	ucomiss %xmm1,%xmm2
  47b372:	0f 83 70 02 00 00    	jae    47b5e8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1668>
  47b378:	41 bc 05 00 00 00    	mov    $0x5,%r12d
  47b37e:	4d 8b 9f 68 02 00 00 	mov    0x268(%r15),%r11
  47b385:	49 8b bf 60 02 00 00 	mov    0x260(%r15),%rdi
  47b38c:	0f c6 c0 e0          	shufps $0xe0,%xmm0,%xmm0
  47b390:	4d 8b 45 d8          	mov    -0x28(%r13),%r8
  47b394:	4c 89 d8             	mov    %r11,%rax
  47b397:	48 29 f8             	sub    %rdi,%rax
  47b39a:	48 85 c0             	test   %rax,%rax
  47b39d:	7e 45                	jle    47b3e4 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1464>
  47b39f:	48 c1 f8 03          	sar    $0x3,%rax
  47b3a3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47b3aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47b3b1:	00 00 00 00 
  47b3b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47b3bc:	00 00 00 00 
  47b3c0:	48 89 c6             	mov    %rax,%rsi
  47b3c3:	48 d1 fe             	sar    $1,%rsi
  47b3c6:	48 8d 2c f7          	lea    (%rdi,%rsi,8),%rbp
  47b3ca:	4c 39 45 00          	cmp    %r8,0x0(%rbp)
  47b3ce:	0f 83 94 00 00 00    	jae    47b468 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x14e8>
  47b3d4:	48 29 f0             	sub    %rsi,%rax
  47b3d7:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
  47b3db:	48 83 e8 01          	sub    $0x1,%rax
  47b3df:	48 85 c0             	test   %rax,%rax
  47b3e2:	7f dc                	jg     47b3c0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1440>
  47b3e4:	49 39 fb             	cmp    %rdi,%r11
  47b3e7:	0f 84 93 00 00 00    	je     47b480 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1500>
  47b3ed:	4c 3b 07             	cmp    (%rdi),%r8
  47b3f0:	0f 82 8a 00 00 00    	jb     47b480 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1500>
  47b3f6:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  47b3fc:	75 05                	jne    47b403 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1483>
  47b3fe:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  47b403:	be 01 00 00 00       	mov    $0x1,%esi
  47b408:	48 39 d1             	cmp    %rdx,%rcx
  47b40b:	74 7a                	je     47b487 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1507>
  47b40d:	4c 89 2a             	mov    %r13,(%rdx)
  47b410:	48 83 c2 20          	add    $0x20,%rdx
  47b414:	48 89 5a e8          	mov    %rbx,-0x18(%rdx)
  47b418:	40 88 72 f8          	mov    %sil,-0x8(%rdx)
  47b41c:	0f 13 42 f0          	movlps %xmm0,-0x10(%rdx)
  47b420:	41 80 7d fa 00       	cmpb   $0x0,-0x6(%r13)
  47b425:	0f 84 a5 fe ff ff    	je     47b2d0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1350>
  47b42b:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  47b432:	00 
  47b433:	0f b6 9c 24 db 00 00 	movzbl 0xdb(%rsp),%ebx
  47b43a:	00 
  47b43b:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  47b442:	00 
  47b443:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
  47b44a:	00 
  47b44b:	45 85 e4             	test   %r12d,%r12d
  47b44e:	0f 84 dc 03 00 00    	je     47b830 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x18b0>
  47b454:	4c 89 8c 24 b8 00 00 	mov    %r9,0xb8(%rsp)
  47b45b:	00 
  47b45c:	e9 f4 ef ff ff       	jmp    47a455 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4d5>
  47b461:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47b468:	48 85 f6             	test   %rsi,%rsi
  47b46b:	0f 84 73 ff ff ff    	je     47b3e4 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1464>
  47b471:	48 89 f0             	mov    %rsi,%rax
  47b474:	e9 47 ff ff ff       	jmp    47b3c0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1440>
  47b479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47b480:	31 f6                	xor    %esi,%esi
  47b482:	48 39 d1             	cmp    %rdx,%rcx
  47b485:	75 86                	jne    47b40d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x148d>
  47b487:	48 bf ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rdi
  47b48e:	ff ff 03 
  47b491:	48 89 ca             	mov    %rcx,%rdx
  47b494:	4c 29 ca             	sub    %r9,%rdx
  47b497:	48 89 d0             	mov    %rdx,%rax
  47b49a:	48 c1 f8 05          	sar    $0x5,%rax
  47b49e:	48 39 f8             	cmp    %rdi,%rax
  47b4a1:	0f 84 86 c4 bb ff    	je     3792d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]+0x5>
  47b4a7:	48 85 c0             	test   %rax,%rax
  47b4aa:	bd 01 00 00 00       	mov    $0x1,%ebp
  47b4af:	4c 89 4c 24 68       	mov    %r9,0x68(%rsp)
  47b4b4:	48 0f 45 e8          	cmovne %rax,%rbp
  47b4b8:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  47b4bf:	00 
  47b4c0:	40 88 74 24 50       	mov    %sil,0x50(%rsp)
  47b4c5:	48 01 c5             	add    %rax,%rbp
  47b4c8:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  47b4cd:	48 b8 ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rax
  47b4d4:	ff ff 03 
  47b4d7:	48 39 c5             	cmp    %rax,%rbp
  47b4da:	f3 0f 11 5c 24 70    	movss  %xmm3,0x70(%rsp)
  47b4e0:	48 0f 47 e8          	cmova  %rax,%rbp
  47b4e4:	f3 0f 11 54 24 60    	movss  %xmm2,0x60(%rsp)
  47b4ea:	0f 13 44 24 58       	movlps %xmm0,0x58(%rsp)
  47b4ef:	48 c1 e5 05          	shl    $0x5,%rbp
  47b4f3:	48 89 ef             	mov    %rbp,%rdi
  47b4f6:	e8 35 2d bb ff       	call   2e230 <operator new(unsigned long)@plt>
  47b4fb:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  47b500:	0f b6 74 24 50       	movzbl 0x50(%rsp),%esi
  47b505:	41 ba 05 00 00 00    	mov    $0x5,%r10d
  47b50b:	f3 0f 7e 44 24 58    	movq   0x58(%rsp),%xmm0
  47b511:	f3 0f 10 54 24 60    	movss  0x60(%rsp),%xmm2
  47b517:	49 89 c0             	mov    %rax,%r8
  47b51a:	48 85 d2             	test   %rdx,%rdx
  47b51d:	4c 89 2c 10          	mov    %r13,(%rax,%rdx,1)
  47b521:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
  47b526:	48 89 5c 10 08       	mov    %rbx,0x8(%rax,%rdx,1)
  47b52b:	f3 0f 10 5c 24 70    	movss  0x70(%rsp),%xmm3
  47b531:	40 88 74 10 18       	mov    %sil,0x18(%rax,%rdx,1)
  47b536:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  47b53d:	00 
  47b53e:	0f 13 44 10 10       	movlps %xmm0,0x10(%rax,%rdx,1)
  47b543:	74 4a                	je     47b58f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x160f>
  47b545:	4c 89 ce             	mov    %r9,%rsi
  47b548:	48 89 c7             	mov    %rax,%rdi
  47b54b:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  47b550:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  47b555:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  47b55a:	f3 0f 11 5c 24 60    	movss  %xmm3,0x60(%rsp)
  47b560:	f3 0f 11 54 24 58    	movss  %xmm2,0x58(%rsp)
  47b566:	e8 95 2b bb ff       	call   2e100 <memcpy@plt>
  47b56b:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  47b570:	f3 0f 10 5c 24 60    	movss  0x60(%rsp),%xmm3
  47b576:	41 ba 05 00 00 00    	mov    $0x5,%r10d
  47b57c:	f3 0f 10 54 24 58    	movss  0x58(%rsp),%xmm2
  47b582:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  47b587:	49 89 c0             	mov    %rax,%r8
  47b58a:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  47b58f:	49 8d 54 10 20       	lea    0x20(%r8,%rdx,1),%rdx
  47b594:	4d 85 c9             	test   %r9,%r9
  47b597:	74 40                	je     47b5d9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1659>
  47b599:	4c 29 c9             	sub    %r9,%rcx
  47b59c:	4c 89 cf             	mov    %r9,%rdi
  47b59f:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  47b5a4:	48 89 ce             	mov    %rcx,%rsi
  47b5a7:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  47b5ac:	f3 0f 11 5c 24 58    	movss  %xmm3,0x58(%rsp)
  47b5b2:	f3 0f 11 54 24 50    	movss  %xmm2,0x50(%rsp)
  47b5b8:	e8 e3 2b bb ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  47b5bd:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  47b5c2:	f3 0f 10 5c 24 58    	movss  0x58(%rsp),%xmm3
  47b5c8:	41 ba 05 00 00 00    	mov    $0x5,%r10d
  47b5ce:	f3 0f 10 54 24 50    	movss  0x50(%rsp),%xmm2
  47b5d4:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  47b5d9:	49 8d 0c 28          	lea    (%r8,%rbp,1),%rcx
  47b5dd:	4d 89 c1             	mov    %r8,%r9
  47b5e0:	e9 3b fe ff ff       	jmp    47b420 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x14a0>
  47b5e5:	0f 1f 00             	nopl   (%rax)
  47b5e8:	f3 0f 11 44 24 18    	movss  %xmm0,0x18(%rsp)
  47b5ee:	d9 44 24 18          	flds   0x18(%rsp)
  47b5f2:	d9 e1                	fabs
  47b5f4:	db ac 24 a0 00 00 00 	fldt   0xa0(%rsp)
  47b5fb:	de c1                	faddp  %st,%st(1)
  47b5fd:	d9 05 2d bf 02 00    	flds   0x2bf2d(%rip)        # 4a7530 <_IO_stdin_used+0x530>
  47b603:	d9 c9                	fxch   %st(1)
  47b605:	df e9                	fucomip %st(1),%st
  47b607:	dd d8                	fstp   %st(0)
  47b609:	45 0f 47 e2          	cmova  %r10d,%r12d
  47b60d:	e9 6c fd ff ff       	jmp    47b37e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x13fe>
  47b612:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  47b618:	4d 39 ee             	cmp    %r13,%r14
  47b61b:	0f 83 21 01 00 00    	jae    47b742 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x17c2>
  47b621:	41 bc 05 00 00 00    	mov    $0x5,%r12d
  47b627:	e9 ef fc ff ff       	jmp    47b31b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x139b>
  47b62c:	0f 1f 40 00          	nopl   0x0(%rax)
  47b630:	0f 28 c3             	movaps %xmm3,%xmm0
  47b633:	4c 89 eb             	mov    %r13,%rbx
  47b636:	41 bc 05 00 00 00    	mov    $0x5,%r12d
  47b63c:	4d 39 ee             	cmp    %r13,%r14
  47b63f:	72 e0                	jb     47b621 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x16a1>
  47b641:	e9 38 fd ff ff       	jmp    47b37e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x13fe>
  47b646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  47b64d:	00 00 00 
  47b650:	f3 44 0f 10 88 60 04 	movss  0x460(%rax),%xmm9
  47b657:	00 00 
  47b659:	44 0f 28 e2          	movaps %xmm2,%xmm12
  47b65d:	0f 28 f2             	movaps %xmm2,%xmm6
  47b660:	f3 44 0f 10 15 9b b9 	movss  0x2b99b(%rip),%xmm10        # 4a7004 <_IO_stdin_used+0x4>
  47b667:	02 00 
  47b669:	44 0f 15 e2          	unpckhps %xmm2,%xmm12
  47b66d:	f3 0f 10 98 58 04 00 	movss  0x458(%rax),%xmm3
  47b674:	00 
  47b675:	0f c6 d2 55          	shufps $0x55,%xmm2,%xmm2
  47b679:	f3 44 0f 10 80 5c 04 	movss  0x45c(%rax),%xmm8
  47b680:	00 00 
  47b682:	f3 45 0f 59 ca       	mulss  %xmm10,%xmm9
  47b687:	f3 45 0f 59 e2       	mulss  %xmm10,%xmm12
  47b68c:	f3 45 0f 58 c1       	addss  %xmm9,%xmm8
  47b691:	f3 41 0f 5c d9       	subss  %xmm9,%xmm3
  47b696:	f3 41 0f 58 d4       	addss  %xmm12,%xmm2
  47b69b:	f3 41 0f 5c f4       	subss  %xmm12,%xmm6
  47b6a0:	f3 41 0f 5d b7 38 01 	minss  0x138(%r15),%xmm6
  47b6a7:	00 00 
  47b6a9:	f3 41 0f c2 c0 01    	cmpltss %xmm8,%xmm0
  47b6af:	f3 0f 5d dc          	minss  %xmm4,%xmm3
  47b6b3:	f3 0f 5f d5          	maxss  %xmm5,%xmm2
  47b6b7:	44 0f 54 c0          	andps  %xmm0,%xmm8
  47b6bb:	0f 55 c7             	andnps %xmm7,%xmm0
  47b6be:	41 0f 56 c0          	orps   %xmm8,%xmm0
  47b6c2:	0f 14 f2             	unpcklps %xmm2,%xmm6
  47b6c5:	0f 14 d8             	unpcklps %xmm0,%xmm3
  47b6c8:	41 0f 13 b7 38 01 00 	movlps %xmm6,0x138(%r15)
  47b6cf:	00 
  47b6d0:	41 0f 13 9f 44 01 00 	movlps %xmm3,0x144(%r15)
  47b6d7:	00 
  47b6d8:	e9 f2 f1 ff ff       	jmp    47a8cf <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x94f>
  47b6dd:	f3 0f 58 d0          	addss  %xmm0,%xmm2
  47b6e1:	4c 89 ef             	mov    %r13,%rdi
  47b6e4:	f3 0f 11 5c 24 10    	movss  %xmm3,0x10(%rsp)
  47b6ea:	f3 0f 11 54 24 08    	movss  %xmm2,0x8(%rsp)
  47b6f0:	e8 0b a2 fe ff       	call   465900 <skia::textlayout::Cluster::isSoftBreak() const>
  47b6f5:	f3 0f 10 54 24 08    	movss  0x8(%rsp),%xmm2
  47b6fb:	f3 0f 10 5c 24 10    	movss  0x10(%rsp),%xmm3
  47b701:	84 c0                	test   %al,%al
  47b703:	0f 84 02 f7 ff ff    	je     47ae0b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe8b>
  47b709:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  47b710:	00 
  47b711:	4c 89 ee             	mov    %r13,%rsi
  47b714:	e8 d7 b9 ff ff       	call   4770f0 <skia::textlayout::(anonymous namespace)::softHyphenWidth(SkString const*, skia::textlayout::Cluster const*)>
  47b719:	f3 0f 10 54 24 08    	movss  0x8(%rsp),%xmm2
  47b71f:	f3 0f 10 5c 24 10    	movss  0x10(%rsp),%xmm3
  47b725:	f3 0f 58 d0          	addss  %xmm0,%xmm2
  47b729:	f3 0f 5f 95 70 01 00 	maxss  0x170(%rbp),%xmm2
  47b730:	00 
  47b731:	f3 0f 11 95 70 01 00 	movss  %xmm2,0x170(%rbp)
  47b738:	00 
  47b739:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47b73d:	e9 c9 f6 ff ff       	jmp    47ae0b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe8b>
  47b742:	0f 28 cb             	movaps %xmm3,%xmm1
  47b745:	0f 28 c3             	movaps %xmm3,%xmm0
  47b748:	0f 54 0d 01 73 03 00 	andps  0x37301(%rip),%xmm1        # 4b2a50 <C.119.3+0x200>
  47b74f:	4c 89 eb             	mov    %r13,%rbx
  47b752:	41 bc 05 00 00 00    	mov    $0x5,%r12d
  47b758:	e9 12 fc ff ff       	jmp    47b36f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x13ef>
  47b75d:	c6 85 6a 01 00 00 00 	movb   $0x0,0x16a(%rbp)
  47b764:	4c 8b ad 18 01 00 00 	mov    0x118(%rbp),%r13
  47b76b:	8b 5c 24 48          	mov    0x48(%rsp),%ebx
  47b76f:	83 e3 01             	and    $0x1,%ebx
  47b772:	4d 85 ed             	test   %r13,%r13
  47b775:	0f 85 55 f6 ff ff    	jne    47add0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe50>
  47b77b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  47b780:	80 bd 6a 01 00 00 00 	cmpb   $0x0,0x16a(%rbp)
  47b787:	0f 85 03 02 00 00    	jne    47b990 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1a10>
  47b78d:	49 63 97 10 04 00 00 	movslq 0x410(%r15),%rdx
  47b794:	48 85 d2             	test   %rdx,%rdx
  47b797:	74 22                	je     47b7bb <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x183b>
  47b799:	49 8b 8f 08 04 00 00 	mov    0x408(%r15),%rcx
  47b7a0:	85 db                	test   %ebx,%ebx
  47b7a2:	74 07                	je     47b7ab <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x182b>
  47b7a4:	c6 81 e3 00 00 00 00 	movb   $0x0,0xe3(%rcx)
  47b7ab:	f6 44 24 48 02       	testb  $0x2,0x48(%rsp)
  47b7b0:	74 09                	je     47b7bb <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x183b>
  47b7b2:	48 c1 e2 08          	shl    $0x8,%rdx
  47b7b6:	c6 44 0a e4 00       	movb   $0x0,-0x1c(%rdx,%rcx,1)
  47b7bb:	48 83 bc 24 b8 00 00 	cmpq   $0x0,0xb8(%rsp)
  47b7c2:	00 00 
  47b7c4:	0f 84 1e 05 00 00    	je     47bce8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1d68>
  47b7ca:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  47b7d1:	00 
  47b7d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
  47b7d9:	00 00 
  47b7db:	0f 85 dc 06 00 00    	jne    47bebd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1f3d>
  47b7e1:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
  47b7e8:	00 
  47b7e9:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
  47b7f0:	00 
  47b7f1:	48 8b 9c 24 28 02 00 	mov    0x228(%rsp),%rbx
  47b7f8:	00 
  47b7f9:	48 8b ac 24 30 02 00 	mov    0x230(%rsp),%rbp
  47b800:	00 
  47b801:	4c 8b a4 24 38 02 00 	mov    0x238(%rsp),%r12
  47b808:	00 
  47b809:	4c 8b b4 24 48 02 00 	mov    0x248(%rsp),%r14
  47b810:	00 
  47b811:	48 29 fe             	sub    %rdi,%rsi
  47b814:	4c 8b bc 24 50 02 00 	mov    0x250(%rsp),%r15
  47b81b:	00 
  47b81c:	4c 8b ac 24 40 02 00 	mov    0x240(%rsp),%r13
  47b823:	00 
  47b824:	48 81 c4 58 02 00 00 	add    $0x258,%rsp
  47b82b:	e9 70 29 bb ff       	jmp    2e1a0 <operator delete(void*, unsigned long)@plt>
  47b830:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  47b837:	00 
  47b838:	4c 29 c9             	sub    %r9,%rcx
  47b83b:	49 89 c8             	mov    %rcx,%r8
  47b83e:	49 c1 f8 05          	sar    $0x5,%r8
  47b842:	74 4d                	je     47b891 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1911>
  47b844:	49 8d 04 09          	lea    (%r9,%rcx,1),%rax
  47b848:	4c 89 c2             	mov    %r8,%rdx
  47b84b:	eb 2c                	jmp    47b879 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x18f9>
  47b84d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  47b854:	00 
  47b855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47b85c:	00 00 00 00 
  47b860:	f3 0f 10 40 14       	movss  0x14(%rax),%xmm0
  47b865:	f3 0f 5d 40 f0       	minss  -0x10(%rax),%xmm0
  47b86a:	f3 0f 11 40 f4       	movss  %xmm0,-0xc(%rax)
  47b86f:	48 83 ea 01          	sub    $0x1,%rdx
  47b873:	74 1c                	je     47b891 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1911>
  47b875:	48 83 e8 20          	sub    $0x20,%rax
  47b879:	49 39 d0             	cmp    %rdx,%r8
  47b87c:	75 e2                	jne    47b860 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x18e0>
  47b87e:	f3 0f 10 40 f0       	movss  -0x10(%rax),%xmm0
  47b883:	4c 89 c2             	mov    %r8,%rdx
  47b886:	f3 0f 11 40 f4       	movss  %xmm0,-0xc(%rax)
  47b88b:	48 83 ea 01          	sub    $0x1,%rdx
  47b88f:	75 e4                	jne    47b875 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x18f5>
  47b891:	48 85 c9             	test   %rcx,%rcx
  47b894:	0f 84 ee 05 00 00    	je     47be88 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1f08>
  47b89a:	88 5c 24 68          	mov    %bl,0x68(%rsp)
  47b89e:	45 31 e4             	xor    %r12d,%r12d
  47b8a1:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  47b8a6:	4d 89 cd             	mov    %r9,%r13
  47b8a9:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  47b8ae:	4c 89 c5             	mov    %r8,%rbp
  47b8b1:	45 31 ff             	xor    %r15d,%r15d
  47b8b4:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  47b8bb:	00 00 
  47b8bd:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
  47b8c2:	f3 0f 11 54 24 50    	movss  %xmm2,0x50(%rsp)
  47b8c8:	eb 17                	jmp    47b8e1 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1961>
  47b8ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  47b8d0:	49 83 c7 01          	add    $0x1,%r15
  47b8d4:	49 83 c5 20          	add    $0x20,%r13
  47b8d8:	49 39 ef             	cmp    %rbp,%r15
  47b8db:	0f 83 34 04 00 00    	jae    47bd15 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1d95>
  47b8e1:	f3 41 0f 10 45 14    	movss  0x14(%r13),%xmm0
  47b8e7:	0f 2f 44 24 4c       	comiss 0x4c(%rsp),%xmm0
  47b8ec:	0f 87 23 04 00 00    	ja     47bd15 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1d95>
  47b8f2:	49 8b 56 10          	mov    0x10(%r14),%rdx
  47b8f6:	49 8b 75 08          	mov    0x8(%r13),%rsi
  47b8fa:	48 89 d0             	mov    %rdx,%rax
  47b8fd:	49 39 f6             	cmp    %rsi,%r14
  47b900:	73 04                	jae    47b906 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1986>
  47b902:	48 8b 46 d8          	mov    -0x28(%rsi),%rax
  47b906:	f3 41 0f 10 65 10    	movss  0x10(%r13),%xmm4
  47b90c:	48 92                	xchg   %rax,%rdx
  47b90e:	48 89 df             	mov    %rbx,%rdi
  47b911:	48 89 c6             	mov    %rax,%rsi
  47b914:	f3 0f 11 64 24 18    	movss  %xmm4,0x18(%rsp)
  47b91a:	e8 01 f9 fd ff       	call   45b220 <skia::textlayout::ParagraphImpl::experimentalPadding(skia::textlayout::SkRange<unsigned long>) const>
  47b91f:	f3 0f 58 44 24 18    	addss  0x18(%rsp),%xmm0
  47b925:	f3 0f 10 74 24 50    	movss  0x50(%rsp),%xmm6
  47b92b:	0f 28 c8             	movaps %xmm0,%xmm1
  47b92e:	0f 54 0d 1b 71 03 00 	andps  0x3711b(%rip),%xmm1        # 4b2a50 <C.119.3+0x200>
  47b935:	0f 2e f1             	ucomiss %xmm1,%xmm6
  47b938:	0f 82 6c 04 00 00    	jb     47bdaa <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1e2a>
  47b93e:	f3 0f 10 7c 24 4c    	movss  0x4c(%rsp),%xmm7
  47b944:	0f 2f f8             	comiss %xmm0,%xmm7
  47b947:	72 87                	jb     47b8d0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1950>
  47b949:	41 80 7d 18 00       	cmpb   $0x0,0x18(%r13)
  47b94e:	74 80                	je     47b8d0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1950>
  47b950:	4d 8b 65 00          	mov    0x0(%r13),%r12
  47b954:	49 8d 7c 24 c0       	lea    -0x40(%r12),%rdi
  47b959:	e8 a2 9f fe ff       	call   465900 <skia::textlayout::Cluster::isSoftBreak() const>
  47b95e:	84 c0                	test   %al,%al
  47b960:	75 13                	jne    47b975 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x19f5>
  47b962:	41 80 7c 24 fa 00    	cmpb   $0x0,-0x6(%r12)
  47b968:	75 0b                	jne    47b975 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x19f5>
  47b96a:	4c 39 64 24 10       	cmp    %r12,0x10(%rsp)
  47b96f:	0f 85 5b ff ff ff    	jne    47b8d0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1950>
  47b975:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  47b97a:	e9 51 ff ff ff       	jmp    47b8d0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1950>
  47b97f:	88 44 24 34          	mov    %al,0x34(%rsp)
  47b983:	89 c7                	mov    %eax,%edi
  47b985:	89 d1                	mov    %edx,%ecx
  47b987:	66 0f ef db          	pxor   %xmm3,%xmm3
  47b98b:	e9 73 ea ff ff       	jmp    47a403 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x483>
  47b990:	f3 0f 10 9d 6c 01 00 	movss  0x16c(%rbp),%xmm3
  47b997:	00 
  47b998:	f6 44 24 48 02       	testb  $0x2,0x48(%rsp)
  47b99d:	74 10                	je     47b9af <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1a2f>
  47b99f:	f3 0f 10 85 48 01 00 	movss  0x148(%rbp),%xmm0
  47b9a6:	00 
  47b9a7:	f3 0f 11 85 3c 01 00 	movss  %xmm0,0x13c(%rbp)
  47b9ae:	00 
  47b9af:	41 80 7f 39 00       	cmpb   $0x0,0x39(%r15)
  47b9b4:	0f 85 b2 03 00 00    	jne    47bd6c <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1dec>
  47b9ba:	f3 0f 10 85 3c 01 00 	movss  0x13c(%rbp),%xmm0
  47b9c1:	00 
  47b9c2:	f3 0f 10 8d 38 01 00 	movss  0x138(%rbp),%xmm1
  47b9c9:	00 
  47b9ca:	f3 0f 10 95 40 01 00 	movss  0x140(%rbp),%xmm2
  47b9d1:	00 
  47b9d2:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  47b9d6:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  47b9da:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
  47b9de:	4c 8b ad 28 01 00 00 	mov    0x128(%rbp),%r13
  47b9e5:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  47b9ea:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  47b9ee:	4c 8b b5 18 01 00 00 	mov    0x118(%rbp),%r14
  47b9f5:	f3 0f 11 5c 24 10    	movss  %xmm3,0x10(%rsp)
  47b9fb:	4c 89 e8             	mov    %r13,%rax
  47b9fe:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
  47ba02:	48 29 c8             	sub    %rcx,%rax
  47ba05:	4d 89 f4             	mov    %r14,%r12
  47ba08:	48 c1 f8 06          	sar    $0x6,%rax
  47ba0c:	49 29 cc             	sub    %rcx,%r12
  47ba0f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  47ba14:	49 c1 fc 06          	sar    $0x6,%r12
  47ba18:	e8 73 33 bb ff       	call   2ed90 <round@plt>
  47ba1d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  47ba22:	66 49 0f 6e f4       	movq   %r12,%xmm6
  47ba27:	f3 41 0f 6f 55 10    	movdqu 0x10(%r13),%xmm2
  47ba2d:	66 0f 28 c8          	movapd %xmm0,%xmm1
  47ba31:	f3 41 0f 6f 46 10    	movdqu 0x10(%r14),%xmm0
  47ba37:	f3 41 0f 6f 65 10    	movdqu 0x10(%r13),%xmm4
  47ba3d:	4c 89 a4 24 b8 01 00 	mov    %r12,0x1b8(%rsp)
  47ba44:	00 
  47ba45:	f3 0f 10 5c 24 10    	movss  0x10(%rsp),%xmm3
  47ba4b:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  47ba52:	00 
  47ba53:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  47ba57:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  47ba5e:	00 
  47ba5f:	66 48 0f 6e c0       	movq   %rax,%xmm0
  47ba64:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  47ba69:	0f b6 44 24 18       	movzbl 0x18(%rsp),%eax
  47ba6e:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
  47ba72:	c7 84 24 ec 00 00 00 	movl   $0x0,0xec(%rsp)
  47ba79:	00 00 00 00 
  47ba7d:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  47ba84:	00 
  47ba85:	f3 0f 6f 85 38 01 00 	movdqu 0x138(%rbp),%xmm0
  47ba8c:	00 
  47ba8d:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
  47ba94:	00 00 00 00 00 
  47ba99:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
  47baa0:	00 
  47baa1:	f3 0f 6f 85 44 01 00 	movdqu 0x144(%rbp),%xmm0
  47baa8:	00 
  47baa9:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
  47bab0:	00 00 00 00 00 
  47bab5:	c7 84 24 20 01 00 00 	movl   $0x0,0x120(%rsp)
  47babc:	00 00 00 00 
  47bac0:	c7 84 24 28 01 00 00 	movl   $0x0,0x128(%rsp)
  47bac7:	00 00 00 00 
  47bacb:	88 84 24 e7 00 00 00 	mov    %al,0xe7(%rsp)
  47bad2:	0f 29 a4 24 80 01 00 	movaps %xmm4,0x180(%rsp)
  47bad9:	00 
  47bada:	0f 29 94 24 90 01 00 	movaps %xmm2,0x190(%rsp)
  47bae1:	00 
  47bae2:	f3 0f 11 9c 24 24 01 	movss  %xmm3,0x124(%rsp)
  47bae9:	00 00 
  47baeb:	f3 0f 11 8c 24 2c 01 	movss  %xmm1,0x12c(%rsp)
  47baf2:	00 00 
  47baf4:	0f 11 84 24 fc 01 00 	movups %xmm0,0x1fc(%rsp)
  47bafb:	00 
  47bafc:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
  47bb01:	0f 84 21 be bb ff    	je     37928 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]>
  47bb07:	48 8d 8c 24 a0 01 00 	lea    0x1a0(%rsp),%rcx
  47bb0e:	00 
  47bb0f:	48 8d 94 24 90 01 00 	lea    0x190(%rsp),%rdx
  47bb16:	00 
  47bb17:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
  47bb1e:	00 
  47bb1f:	48 83 ec 08          	sub    $0x8,%rsp
  47bb23:	48 8d 84 24 ef 00 00 	lea    0xef(%rsp),%rax
  47bb2a:	00 
  47bb2b:	50                   	push   %rax
  47bb2c:	48 8d 84 24 00 02 00 	lea    0x200(%rsp),%rax
  47bb33:	00 
  47bb34:	50                   	push   %rax
  47bb35:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  47bb3c:	00 
  47bb3d:	50                   	push   %rax
  47bb3e:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  47bb45:	00 
  47bb46:	50                   	push   %rax
  47bb47:	48 8d 84 24 38 01 00 	lea    0x138(%rsp),%rax
  47bb4e:	00 
  47bb4f:	50                   	push   %rax
  47bb50:	48 8d 84 24 38 01 00 	lea    0x138(%rsp),%rax
  47bb57:	00 
  47bb58:	50                   	push   %rax
  47bb59:	48 8d 84 24 24 01 00 	lea    0x124(%rsp),%rax
  47bb60:	00 
  47bb61:	50                   	push   %rax
  47bb62:	4c 8d 8c 24 00 02 00 	lea    0x200(%rsp),%r9
  47bb69:	00 
  47bb6a:	4c 8d 84 24 f0 01 00 	lea    0x1f0(%rsp),%r8
  47bb71:	00 
  47bb72:	ff 57 18             	call   *0x18(%rdi)
  47bb75:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47bb79:	66 0f ef c9          	pxor   %xmm1,%xmm1
  47bb7d:	48 83 c4 40          	add    $0x40,%rsp
  47bb81:	f3 0f 5a 8d 38 01 00 	cvtss2sd 0x138(%rbp),%xmm1
  47bb88:	00 
  47bb89:	f3 0f 5a 85 3c 01 00 	cvtss2sd 0x13c(%rbp),%xmm0
  47bb90:	00 
  47bb91:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
  47bb95:	66 0f ef c9          	pxor   %xmm1,%xmm1
  47bb99:	f3 0f 5a 8d 40 01 00 	cvtss2sd 0x140(%rbp),%xmm1
  47bba0:	00 
  47bba1:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
  47bba5:	e8 e6 31 bb ff       	call   2ed90 <round@plt>
  47bbaa:	49 63 97 10 04 00 00 	movslq 0x410(%r15),%rdx
  47bbb1:	49 8b 8f 08 04 00 00 	mov    0x408(%r15),%rcx
  47bbb8:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  47bbbc:	f3 0f 58 85 6c 01 00 	addss  0x16c(%rbp),%xmm0
  47bbc3:	00 
  47bbc4:	f3 0f 11 85 6c 01 00 	movss  %xmm0,0x16c(%rbp)
  47bbcb:	00 
  47bbcc:	48 85 d2             	test   %rdx,%rdx
  47bbcf:	0f 84 70 bd bb ff    	je     37945 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]+0x1d>
  47bbd5:	0f 28 a4 24 90 00 00 	movaps 0x90(%rsp),%xmm4
  47bbdc:	00 
  47bbdd:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  47bbe2:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  47bbe6:	48 c1 e0 08          	shl    $0x8,%rax
  47bbea:	48 89 bc 01 d4 00 00 	mov    %rdi,0xd4(%rcx,%rax,1)
  47bbf1:	00 
  47bbf2:	c6 84 01 dc 00 00 00 	movb   $0x0,0xdc(%rcx,%rax,1)
  47bbf9:	00 
  47bbfa:	0f 11 a4 01 c4 00 00 	movups %xmm4,0xc4(%rcx,%rax,1)
  47bc01:	00 
  47bc02:	e9 99 fb ff ff       	jmp    47b7a0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1820>
  47bc07:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  47bc0e:	00 00 00 00 00 
  47bc13:	c7 84 24 a8 00 00 00 	movl   $0x0,0xa8(%rsp)
  47bc1a:	00 00 00 00 
  47bc1e:	8b 8c 24 b4 00 00 00 	mov    0xb4(%rsp),%ecx
  47bc25:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  47bc2c:	00 00 00 00 00 
  47bc31:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  47bc38:	00 00 00 00 00 
  47bc3d:	85 c9                	test   %ecx,%ecx
  47bc3f:	0f 85 25 e7 ff ff    	jne    47a36a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3ea>
  47bc45:	4c 89 e8             	mov    %r13,%rax
  47bc48:	48 c1 e8 3a          	shr    $0x3a,%rax
  47bc4c:	0f 85 e7 bc bb ff    	jne    37939 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]+0x11>
  47bc52:	4d 89 ec             	mov    %r13,%r12
  47bc55:	49 c1 e4 05          	shl    $0x5,%r12
  47bc59:	4c 89 e7             	mov    %r12,%rdi
  47bc5c:	e8 cf 25 bb ff       	call   2e230 <operator new(unsigned long)@plt>
  47bc61:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  47bc68:	00 
  47bc69:	4c 01 e0             	add    %r12,%rax
  47bc6c:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  47bc73:	00 
  47bc74:	e9 f1 e6 ff ff       	jmp    47a36a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3ea>
  47bc79:	d8 05 ad b8 02 00    	fadds  0x2b8ad(%rip)        # 4a752c <_IO_stdin_used+0x52c>
  47bc7f:	e9 2d e6 ff ff       	jmp    47a2b1 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x331>
  47bc84:	f3 0f 10 8d 44 01 00 	movss  0x144(%rbp),%xmm1
  47bc8b:	00 
  47bc8c:	f3 0f 11 8d 38 01 00 	movss  %xmm1,0x138(%rbp)
  47bc93:	00 
  47bc94:	e9 6a f2 ff ff       	jmp    47af03 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xf83>
  47bc99:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47bc9d:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  47bca1:	f3 0f 5a 85 3c 01 00 	cvtss2sd 0x13c(%rbp),%xmm0
  47bca8:	00 
  47bca9:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
  47bcad:	66 0f ef c9          	pxor   %xmm1,%xmm1
  47bcb1:	f3 0f 5a 8d 40 01 00 	cvtss2sd 0x140(%rbp),%xmm1
  47bcb8:	00 
  47bcb9:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
  47bcbd:	e8 ce 30 bb ff       	call   2ed90 <round@plt>
  47bcc2:	66 0f ef db          	pxor   %xmm3,%xmm3
  47bcc6:	f2 0f 5a d8          	cvtsd2ss %xmm0,%xmm3
  47bcca:	f3 0f 5f 9d 6c 01 00 	maxss  0x16c(%rbp),%xmm3
  47bcd1:	00 
  47bcd2:	f3 0f 11 9d 6c 01 00 	movss  %xmm3,0x16c(%rbp)
  47bcd9:	00 
  47bcda:	45 84 e4             	test   %r12b,%r12b
  47bcdd:	0f 85 b5 fc ff ff    	jne    47b998 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1a18>
  47bce3:	e9 d3 fa ff ff       	jmp    47b7bb <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x183b>
  47bce8:	48 8b 9c 24 28 02 00 	mov    0x228(%rsp),%rbx
  47bcef:	00 
  47bcf0:	48 8b ac 24 30 02 00 	mov    0x230(%rsp),%rbp
  47bcf7:	00 
  47bcf8:	4c 8b a4 24 38 02 00 	mov    0x238(%rsp),%r12
  47bcff:	00 
  47bd00:	4c 8b b4 24 48 02 00 	mov    0x248(%rsp),%r14
  47bd07:	00 
  47bd08:	4c 8b bc 24 50 02 00 	mov    0x250(%rsp),%r15
  47bd0f:	00 
  47bd10:	e9 bd e2 ff ff       	jmp    479fd2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x52>
  47bd15:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
  47bd1a:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
  47bd1f:	0f b6 5c 24 68       	movzbl 0x68(%rsp),%ebx
  47bd24:	f3 0f 10 54 24 50    	movss  0x50(%rsp),%xmm2
  47bd2a:	4c 89 8c 24 b8 00 00 	mov    %r9,0xb8(%rsp)
  47bd31:	00 
  47bd32:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  47bd37:	e9 bf e8 ff ff       	jmp    47a5fb <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x67b>
  47bd3c:	4c 89 fd             	mov    %r15,%rbp
  47bd3f:	f3 0f 10 5c 24 30    	movss  0x30(%rsp),%xmm3
  47bd45:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  47bd4a:	4c 8b ad 18 01 00 00 	mov    0x118(%rbp),%r13
  47bd51:	e9 15 fa ff ff       	jmp    47b76b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x17eb>
  47bd56:	4c 89 fd             	mov    %r15,%rbp
  47bd59:	f3 0f 10 5c 24 30    	movss  0x30(%rsp),%xmm3
  47bd5f:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  47bd64:	4d 89 f5             	mov    %r14,%r13
  47bd67:	e9 5d f0 ff ff       	jmp    47adc9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe49>
  47bd6c:	41 0f 10 a7 4c 04 00 	movups 0x44c(%r15),%xmm4
  47bd73:	00 
  47bd74:	f3 41 0f 10 97 54 04 	movss  0x454(%r15),%xmm2
  47bd7b:	00 00 
  47bd7d:	80 bd 50 01 00 00 00 	cmpb   $0x0,0x150(%rbp)
  47bd84:	74 3b                	je     47bdc1 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1e41>
  47bd86:	49 8b 87 5c 04 00 00 	mov    0x45c(%r15),%rax
  47bd8d:	0f 28 c4             	movaps %xmm4,%xmm0
  47bd90:	0f 28 cc             	movaps %xmm4,%xmm1
  47bd93:	0f 11 a5 38 01 00 00 	movups %xmm4,0x138(%rbp)
  47bd9a:	0f c6 c4 55          	shufps $0x55,%xmm4,%xmm0
  47bd9e:	48 89 85 48 01 00 00 	mov    %rax,0x148(%rbp)
  47bda5:	e9 28 fc ff ff       	jmp    47b9d2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1a52>
  47bdaa:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
  47bdaf:	0f b6 5c 24 68       	movzbl 0x68(%rsp),%ebx
  47bdb4:	0f 28 d6             	movaps %xmm6,%xmm2
  47bdb7:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  47bdbc:	e9 93 f6 ff ff       	jmp    47b454 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x14d4>
  47bdc1:	f3 0f 10 35 3b b2 02 	movss  0x2b23b(%rip),%xmm6        # 4a7004 <_IO_stdin_used+0x4>
  47bdc8:	00 
  47bdc9:	f3 41 0f 10 87 4c 04 	movss  0x44c(%r15),%xmm0
  47bdd0:	00 00 
  47bdd2:	f3 41 0f 10 a7 60 04 	movss  0x460(%r15),%xmm4
  47bdd9:	00 00 
  47bddb:	f3 41 0f 10 af 58 04 	movss  0x458(%r15),%xmm5
  47bde2:	00 00 
  47bde4:	f3 41 0f 10 bf 5c 04 	movss  0x45c(%r15),%xmm7
  47bdeb:	00 00 
  47bded:	f3 0f 59 d6          	mulss  %xmm6,%xmm2
  47bdf1:	f3 0f 59 e6          	mulss  %xmm6,%xmm4
  47bdf5:	f3 0f 5c c2          	subss  %xmm2,%xmm0
  47bdf9:	f3 41 0f 58 97 50 04 	addss  0x450(%r15),%xmm2
  47be00:	00 00 
  47be02:	f3 0f 5f 95 3c 01 00 	maxss  0x13c(%rbp),%xmm2
  47be09:	00 
  47be0a:	0f 28 c8             	movaps %xmm0,%xmm1
  47be0d:	f3 0f 5d 8d 38 01 00 	minss  0x138(%rbp),%xmm1
  47be14:	00 
  47be15:	0f 28 c2             	movaps %xmm2,%xmm0
  47be18:	0f 28 d1             	movaps %xmm1,%xmm2
  47be1b:	0f 14 d0             	unpcklps %xmm0,%xmm2
  47be1e:	0f 13 95 38 01 00 00 	movlps %xmm2,0x138(%rbp)
  47be25:	0f 28 d4             	movaps %xmm4,%xmm2
  47be28:	0f 28 e5             	movaps %xmm5,%xmm4
  47be2b:	f3 0f 5c e2          	subss  %xmm2,%xmm4
  47be2f:	f3 0f 58 d7          	addss  %xmm7,%xmm2
  47be33:	f3 0f 5d a5 44 01 00 	minss  0x144(%rbp),%xmm4
  47be3a:	00 
  47be3b:	f3 0f 5f 95 48 01 00 	maxss  0x148(%rbp),%xmm2
  47be42:	00 
  47be43:	0f 14 e2             	unpcklps %xmm2,%xmm4
  47be46:	f3 0f 10 95 40 01 00 	movss  0x140(%rbp),%xmm2
  47be4d:	00 
  47be4e:	0f 13 a5 44 01 00 00 	movlps %xmm4,0x144(%rbp)
  47be55:	e9 78 fb ff ff       	jmp    47b9d2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1a52>
  47be5a:	8b 5c 24 48          	mov    0x48(%rsp),%ebx
  47be5e:	0f 28 35 eb 80 03 00 	movaps 0x380eb(%rip),%xmm6        # 4b3f50 <C.119.3+0x1700>
  47be65:	b8 ff ff 7f ff       	mov    $0xff7fffff,%eax
  47be6a:	c6 44 24 18 00       	movb   $0x0,0x18(%rsp)
  47be6f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  47be74:	66 0f ef db          	pxor   %xmm3,%xmm3
  47be78:	83 e3 01             	and    $0x1,%ebx
  47be7b:	0f 29 b4 24 90 00 00 	movaps %xmm6,0x90(%rsp)
  47be82:	00 
  47be83:	e9 48 ef ff ff       	jmp    47add0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe50>
  47be88:	4c 89 8c 24 b8 00 00 	mov    %r9,0xb8(%rsp)
  47be8f:	00 
  47be90:	e9 c3 ef ff ff       	jmp    47ae58 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xed8>
  47be95:	48 89 9c 24 28 02 00 	mov    %rbx,0x228(%rsp)
  47be9c:	00 
  47be9d:	48 89 ac 24 30 02 00 	mov    %rbp,0x230(%rsp)
  47bea4:	00 
  47bea5:	4c 89 a4 24 38 02 00 	mov    %r12,0x238(%rsp)
  47beac:	00 
  47bead:	4c 89 b4 24 48 02 00 	mov    %r14,0x248(%rsp)
  47beb4:	00 
  47beb5:	4c 89 bc 24 50 02 00 	mov    %r15,0x250(%rsp)
  47bebc:	00 
  47bebd:	e8 1e 25 bb ff       	call   2e3e0 <__stack_chk_fail@plt>
  47bec2:	b9 80 02 00 00       	mov    $0x280,%ecx
  47bec7:	48 8d 15 ea 5a 03 00 	lea    0x35aea(%rip),%rdx        # 4b19b8 <_IO_stdin_used+0xa9b8>
  47bece:	31 ff                	xor    %edi,%edi
  47bed0:	31 c0                	xor    %eax,%eax
  47bed2:	48 8d 35 0f 5b 03 00 	lea    0x35b0f(%rip),%rsi        # 4b19e8 <_IO_stdin_used+0xa9e8>
  47bed9:	e8 b2 02 c1 ff       	call   8c190 <SkLog(SkLogPriority, char const*, ...)>
  47bede:	e8 2b 7e bb ff       	call   33d0e <sk_abort_no_print()>
