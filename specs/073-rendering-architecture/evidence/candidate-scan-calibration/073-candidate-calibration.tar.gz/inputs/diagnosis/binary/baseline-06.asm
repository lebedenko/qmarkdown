
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/baseline-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000037866 <skia::textlayout::ParagraphImpl::layout(float) [clone .cold]>:
   37866:	48 8d 3d 00 fd 46 00 	lea    0x46fd00(%rip),%rdi        # 4a756d <_IO_stdin_used+0x56d>
   3786d:	e8 4e 70 ff ff       	call   2e8c0 <std::__throw_length_error(char const*)@plt>
   37872:	0f 0b                	ud2
