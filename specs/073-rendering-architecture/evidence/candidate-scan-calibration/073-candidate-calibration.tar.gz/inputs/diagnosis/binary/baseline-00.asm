
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/baseline-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000479f60 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)>:
  479f60:	48 81 ec 28 02 00 00 	sub    $0x228,%rsp
  479f67:	48 89 9c 24 f8 01 00 	mov    %rbx,0x1f8(%rsp)
  479f6e:	00 
  479f6f:	48 63 9e 70 03 00 00 	movslq 0x370(%rsi),%rbx
  479f76:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  479f7b:	f3 0f 11 44 24 3c    	movss  %xmm0,0x3c(%rsp)
  479f81:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  479f88:	00 00 
  479f8a:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  479f91:	00 
  479f92:	48 b8 00 00 00 00 00 	movabs $0x80000000000000,%rax
  479f99:	00 80 00 
  479f9c:	c7 87 74 01 00 00 00 	movl   $0x800000,0x174(%rdi)
  479fa3:	00 80 00 
  479fa6:	48 89 87 6c 01 00 00 	mov    %rax,0x16c(%rdi)
  479fad:	48 85 db             	test   %rbx,%rbx
  479fb0:	75 27                	jne    479fd9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x79>
  479fb2:	48 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%rax
  479fb9:	00 
  479fba:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
  479fc1:	00 00 
  479fc3:	0f 85 03 17 00 00    	jne    47b6cc <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x176c>
  479fc9:	48 8b 9c 24 f8 01 00 	mov    0x1f8(%rsp),%rbx
  479fd0:	00 
  479fd1:	48 81 c4 28 02 00 00 	add    $0x228,%rsp
  479fd8:	c3                   	ret
  479fd9:	48 8b 86 68 03 00 00 	mov    0x368(%rsi),%rax
  479fe0:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
  479fe7:	00 
  479fe8:	49 89 fd             	mov    %rdi,%r13
  479feb:	48 8d 7e 10          	lea    0x10(%rsi),%rdi
  479fef:	48 89 ac 24 00 02 00 	mov    %rbp,0x200(%rsp)
  479ff6:	00 
  479ff7:	bd 01 00 00 00       	mov    $0x1,%ebp
  479ffc:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  47a001:	48 8b 86 f8 01 00 00 	mov    0x1f8(%rsi),%rax
  47a008:	4c 89 bc 24 20 02 00 	mov    %r15,0x220(%rsp)
  47a00f:	00 
  47a010:	49 89 f7             	mov    %rsi,%r15
  47a013:	4c 89 a4 24 08 02 00 	mov    %r12,0x208(%rsp)
  47a01a:	00 
  47a01b:	4c 89 b4 24 18 02 00 	mov    %r14,0x218(%rsp)
  47a022:	00 
  47a023:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  47a02a:	00 
  47a02b:	e8 20 9c fe ff       	call   463c50 <skia::textlayout::ParagraphStyle::effective_align() const>
  47a030:	89 84 24 a4 00 00 00 	mov    %eax,0xa4(%rsp)
  47a037:	49 8b 87 20 02 00 00 	mov    0x220(%r15),%rax
  47a03e:	8b 08                	mov    (%rax),%ecx
  47a040:	85 c9                	test   %ecx,%ecx
  47a042:	75 0c                	jne    47a050 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xf0>
  47a044:	49 83 bf 08 02 00 00 	cmpq   $0x0,0x208(%r15)
  47a04b:	00 
  47a04c:	40 0f 95 c5          	setne  %bpl
  47a050:	41 80 bf 35 02 00 00 	cmpb   $0x0,0x235(%r15)
  47a057:	00 
  47a058:	0f 84 80 0a 00 00    	je     47aade <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xb7e>
  47a05e:	49 8b 87 38 02 00 00 	mov    0x238(%r15),%rax
  47a065:	49 8d b7 38 02 00 00 	lea    0x238(%r15),%rsi
  47a06c:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  47a071:	8b 10                	mov    (%rax),%edx
  47a073:	85 d2                	test   %edx,%edx
  47a075:	0f 84 63 0a 00 00    	je     47aade <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xb7e>
  47a07b:	41 8b 87 2c 02 00 00 	mov    0x22c(%r15),%eax
  47a082:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  47a087:	45 0f b6 67 38       	movzbl 0x38(%r15),%r12d
  47a08c:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  47a093:	4c 8b 77 28          	mov    0x28(%rdi),%r14
  47a097:	e8 74 b7 fe ff       	call   465810 <skia::textlayout::Cluster::runOrNull() const>
  47a09c:	48 85 c0             	test   %rax,%rax
  47a09f:	0f 84 31 14 00 00    	je     47b4d6 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1576>
  47a0a5:	45 84 e4             	test   %r12b,%r12b
  47a0a8:	0f 85 28 14 00 00    	jne    47b4d6 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1576>
  47a0ae:	f3 0f 10 88 d8 00 00 	movss  0xd8(%rax),%xmm1
  47a0b5:	00 
  47a0b6:	f3 0f 10 a8 e0 00 00 	movss  0xe0(%rax),%xmm5
  47a0bd:	00 
  47a0be:	f3 0f 10 25 6e 9e 03 	movss  0x39e6e(%rip),%xmm4        # 4b3f34 <C.119.3+0x1704>
  47a0c5:	00 
  47a0c6:	f3 0f 10 80 dc 00 00 	movss  0xdc(%rax),%xmm0
  47a0cd:	00 
  47a0ce:	f3 0f 58 e9          	addss  %xmm1,%xmm5
  47a0d2:	f3 0f 10 3d 56 9e 03 	movss  0x39e56(%rip),%xmm7        # 4b3f30 <C.119.3+0x1700>
  47a0d9:	00 
  47a0da:	f3 0f 10 b0 98 00 00 	movss  0x98(%rax),%xmm6
  47a0e1:	00 
  47a0e2:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  47a0e6:	0f 28 d4             	movaps %xmm4,%xmm2
  47a0e9:	f3 0f 10 98 e4 00 00 	movss  0xe4(%rax),%xmm3
  47a0f0:	00 
  47a0f1:	f3 0f 58 f1          	addss  %xmm1,%xmm6
  47a0f5:	f3 0f 58 88 9c 00 00 	addss  0x9c(%rax),%xmm1
  47a0fc:	00 
  47a0fd:	f3 0f c2 d5 01       	cmpltss %xmm5,%xmm2
  47a102:	f3 0f 5d c7          	minss  %xmm7,%xmm0
  47a106:	f3 0f 5d f7          	minss  %xmm7,%xmm6
  47a10a:	0f 54 ea             	andps  %xmm2,%xmm5
  47a10d:	0f 55 d4             	andnps %xmm4,%xmm2
  47a110:	0f 56 d5             	orps   %xmm5,%xmm2
  47a113:	66 0f ef ed          	pxor   %xmm5,%xmm5
  47a117:	0f 14 c2             	unpcklps %xmm2,%xmm0
  47a11a:	0f 28 d4             	movaps %xmm4,%xmm2
  47a11d:	f3 0f 5f dd          	maxss  %xmm5,%xmm3
  47a121:	f3 0f c2 d1 01       	cmpltss %xmm1,%xmm2
  47a126:	0f 14 de             	unpcklps %xmm6,%xmm3
  47a129:	0f 54 ca             	andps  %xmm2,%xmm1
  47a12c:	0f 55 d4             	andnps %xmm4,%xmm2
  47a12f:	0f 16 c3             	movlhps %xmm3,%xmm0
  47a132:	0f 56 ca             	orps   %xmm2,%xmm1
  47a135:	f3 0f 10 90 a4 00 00 	movss  0xa4(%rax),%xmm2
  47a13c:	00 
  47a13d:	f3 0f 5f d5          	maxss  %xmm5,%xmm2
  47a141:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  47a146:	4c 8d 4b ff          	lea    -0x1(%rbx),%r9
  47a14a:	49 c7 85 10 01 00 00 	movq   $0x0,0x110(%r13)
  47a151:	00 00 00 00 
  47a155:	49 c1 e1 06          	shl    $0x6,%r9
  47a159:	4d 89 b5 20 01 00 00 	mov    %r14,0x120(%r13)
  47a160:	49 01 f1             	add    %rsi,%r9
  47a163:	49 89 b5 08 01 00 00 	mov    %rsi,0x108(%r13)
  47a16a:	49 89 b5 18 01 00 00 	mov    %rsi,0x118(%r13)
  47a171:	49 c7 85 28 01 00 00 	movq   $0x0,0x128(%r13)
  47a178:	00 00 00 00 
  47a17c:	49 c7 85 30 01 00 00 	movq   $0xffffffffffffffff,0x130(%r13)
  47a183:	ff ff ff ff 
  47a187:	45 88 a5 50 01 00 00 	mov    %r12b,0x150(%r13)
  47a18e:	49 c7 85 54 01 00 00 	movq   $0x0,0x154(%r13)
  47a195:	00 00 00 00 
  47a199:	41 0f 11 85 38 01 00 	movups %xmm0,0x138(%r13)
  47a1a0:	00 
  47a1a1:	f3 41 0f 11 8d 48 01 	movss  %xmm1,0x148(%r13)
  47a1a8:	00 00 
  47a1aa:	f3 41 0f 11 95 4c 01 	movss  %xmm2,0x14c(%r13)
  47a1b1:	00 00 
  47a1b3:	49 39 f1             	cmp    %rsi,%r9
  47a1b6:	0f 84 e6 14 00 00    	je     47b6a2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1742>
  47a1bc:	f3 0f 10 7c 24 3c    	movss  0x3c(%rsp),%xmm7
  47a1c2:	49 8d 85 38 01 00 00 	lea    0x138(%r13),%rax
  47a1c9:	49 8d 49 c0          	lea    -0x40(%r9),%rcx
  47a1cd:	48 83 bc 24 a8 00 00 	cmpq   $0xffffffffffffffff,0xa8(%rsp)
  47a1d4:	00 ff 
  47a1d6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  47a1db:	0f 94 c0             	sete   %al
  47a1de:	0f 28 c7             	movaps %xmm7,%xmm0
  47a1e1:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  47a1e8:	00 
  47a1e9:	f3 0f 5c c7          	subss  %xmm7,%xmm0
  47a1ed:	0f 2e c0             	ucomiss %xmm0,%xmm0
  47a1f0:	0f 9b c2             	setnp  %dl
  47a1f3:	21 ea                	and    %ebp,%edx
  47a1f5:	40 20 e8             	and    %bpl,%al
  47a1f8:	48 89 f5             	mov    %rsi,%rbp
  47a1fb:	88 94 24 97 00 00 00 	mov    %dl,0x97(%rsp)
  47a202:	88 84 24 96 00 00 00 	mov    %al,0x96(%rsp)
  47a209:	0f 85 f0 12 00 00    	jne    47b4ff <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x159f>
  47a20f:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47a213:	bf 01 00 00 00       	mov    $0x1,%edi
  47a218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  47a21f:	00 
  47a220:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  47a227:	00 
  47a228:	0f b6 9c 24 97 00 00 	movzbl 0x97(%rsp),%ebx
  47a22f:	00 
  47a230:	40 88 7c 24 38       	mov    %dil,0x38(%rsp)
  47a235:	49 39 85 60 01 00 00 	cmp    %rax,0x160(%r13)
  47a23c:	0f 93 c0             	setae  %al
  47a23f:	21 c3                	and    %eax,%ebx
  47a241:	89 c7                	mov    %eax,%edi
  47a243:	40 88 bc 24 95 00 00 	mov    %dil,0x95(%rsp)
  47a24a:	00 
  47a24b:	4c 89 ff             	mov    %r15,%rdi
  47a24e:	49 89 ee             	mov    %rbp,%r14
  47a251:	4d 89 ec             	mov    %r13,%r12
  47a254:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
  47a259:	f3 0f 11 54 24 24    	movss  %xmm2,0x24(%rsp)
  47a25f:	e8 3c 07 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a264:	84 c0                	test   %al,%al
  47a266:	0f 85 c5 06 00 00    	jne    47a931 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x9d1>
  47a26c:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  47a271:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  47a276:	0f b6 eb             	movzbl %bl,%ebp
  47a279:	4c 89 e7             	mov    %r12,%rdi
  47a27c:	41 0f b6 97 33 02 00 	movzbl 0x233(%r15),%edx
  47a283:	00 
  47a284:	f3 0f 10 44 24 3c    	movss  0x3c(%rsp),%xmm0
  47a28a:	41 89 e8             	mov    %ebp,%r8d
  47a28d:	e8 2e d2 ff ff       	call   4774c0 <skia::textlayout::TextWrapper::lookAhead(float, skia::textlayout::Cluster*, bool, SkString const*, bool)>
  47a292:	4c 89 ff             	mov    %r15,%rdi
  47a295:	e8 06 07 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a29a:	89 ee                	mov    %ebp,%esi
  47a29c:	4c 89 e7             	mov    %r12,%rdi
  47a29f:	e8 ac f6 ff ff       	call   479950 <skia::textlayout::TextWrapper::moveForward(bool)>
  47a2a4:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  47a2ab:	00 
  47a2ac:	49 39 84 24 18 01 00 	cmp    %rax,0x118(%r12)
  47a2b3:	00 
  47a2b4:	0f 92 c0             	setb   %al
  47a2b7:	8b b4 24 a4 00 00 00 	mov    0xa4(%rsp),%esi
  47a2be:	21 d8                	and    %ebx,%eax
  47a2c0:	88 44 24 30          	mov    %al,0x30(%rsp)
  47a2c4:	e8 67 f9 ff ff       	call   479c30 <skia::textlayout::TextWrapper::trimEndSpaces(skia::textlayout::TextAlign)>
  47a2c9:	49 8b 94 24 28 01 00 	mov    0x128(%r12),%rdx
  47a2d0:	00 
  47a2d1:	48 8d 42 40          	lea    0x40(%rdx),%rax
  47a2d5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  47a2da:	41 80 bc 24 6a 01 00 	cmpb   $0x0,0x16a(%r12)
  47a2e1:	00 00 
  47a2e3:	0f 84 07 08 00 00    	je     47aaf0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xb90>
  47a2e9:	4d 8b ac 24 18 01 00 	mov    0x118(%r12),%r13
  47a2f0:	00 
  47a2f1:	f3 41 0f 10 8c 24 54 	movss  0x154(%r12),%xmm1
  47a2f8:	01 00 00 
  47a2fb:	49 8d 45 40          	lea    0x40(%r13),%rax
  47a2ff:	48 39 d0             	cmp    %rdx,%rax
  47a302:	72 2a                	jb     47a32e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3ce>
  47a304:	eb 2e                	jmp    47a334 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3d4>
  47a306:	0f 1f 40 00          	nopl   0x0(%rax)
  47a30a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47a311:	00 00 00 00 
  47a315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47a31c:	00 00 00 00 
  47a320:	f3 0f 58 48 30       	addss  0x30(%rax),%xmm1
  47a325:	48 83 c0 40          	add    $0x40,%rax
  47a329:	48 39 d0             	cmp    %rdx,%rax
  47a32c:	73 06                	jae    47a334 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3d4>
  47a32e:	80 78 38 00          	cmpb   $0x0,0x38(%rax)
  47a332:	75 ec                	jne    47a320 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3c0>
  47a334:	f3 41 0f 10 84 24 38 	movss  0x138(%r12),%xmm0
  47a33b:	01 00 00 
  47a33e:	0f 2e 05 eb 9b 03 00 	ucomiss 0x39beb(%rip),%xmm0        # 4b3f30 <C.119.3+0x1700>
  47a345:	0f 8a c5 00 00 00    	jp     47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a34b:	0f 85 bf 00 00 00    	jne    47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a351:	f3 41 0f 10 84 24 3c 	movss  0x13c(%r12),%xmm0
  47a358:	01 00 00 
  47a35b:	0f 2e 05 d2 9b 03 00 	ucomiss 0x39bd2(%rip),%xmm0        # 4b3f34 <C.119.3+0x1704>
  47a362:	0f 8a a8 00 00 00    	jp     47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a368:	0f 85 a2 00 00 00    	jne    47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a36e:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47a372:	41 0f 2e 84 24 40 01 	ucomiss 0x140(%r12),%xmm0
  47a379:	00 00 
  47a37b:	0f 8a 8f 00 00 00    	jp     47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a381:	0f 85 89 00 00 00    	jne    47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a387:	f3 41 0f 10 84 24 44 	movss  0x144(%r12),%xmm0
  47a38e:	01 00 00 
  47a391:	0f 2e 05 98 9b 03 00 	ucomiss 0x39b98(%rip),%xmm0        # 4b3f30 <C.119.3+0x1700>
  47a398:	7a 76                	jp     47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a39a:	75 74                	jne    47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a39c:	f3 41 0f 10 84 24 48 	movss  0x148(%r12),%xmm0
  47a3a3:	01 00 00 
  47a3a6:	0f 2e 05 87 9b 03 00 	ucomiss 0x39b87(%rip),%xmm0        # 4b3f34 <C.119.3+0x1704>
  47a3ad:	7a 61                	jp     47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a3af:	75 5f                	jne    47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a3b1:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47a3b5:	41 0f 2e 84 24 4c 01 	ucomiss 0x14c(%r12),%xmm0
  47a3bc:	00 00 
  47a3be:	7a 50                	jp     47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a3c0:	75 4e                	jne    47a410 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4b0>
  47a3c2:	f3 41 0f 6f 87 30 04 	movdqu 0x430(%r15),%xmm0
  47a3c9:	00 00 
  47a3cb:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  47a3d2:	00 
  47a3d3:	f3 41 0f 6f 87 3c 04 	movdqu 0x43c(%r15),%xmm0
  47a3da:	00 00 
  47a3dc:	0f 11 84 24 cc 01 00 	movups %xmm0,0x1cc(%rsp)
  47a3e3:	00 
  47a3e4:	66 0f 6f 84 24 c0 01 	movdqa 0x1c0(%rsp),%xmm0
  47a3eb:	00 00 
  47a3ed:	41 0f 11 84 24 38 01 	movups %xmm0,0x138(%r12)
  47a3f4:	00 00 
  47a3f6:	f3 0f 6f 84 24 c9 01 	movdqu 0x1c9(%rsp),%xmm0
  47a3fd:	00 00 
  47a3ff:	41 0f 11 84 24 41 01 	movups %xmm0,0x141(%r12)
  47a406:	00 00 
  47a408:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  47a40f:	00 
  47a410:	49 8b 9c 24 08 01 00 	mov    0x108(%r12),%rbx
  47a417:	00 
  47a418:	49 39 dd             	cmp    %rbx,%r13
  47a41b:	72 5f                	jb     47a47c <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x51c>
  47a41d:	31 ed                	xor    %ebp,%ebp
  47a41f:	f3 0f 11 4c 24 18    	movss  %xmm1,0x18(%rsp)
  47a425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47a42c:	00 00 00 00 
  47a430:	48 89 df             	mov    %rbx,%rdi
  47a433:	49 89 ed             	mov    %rbp,%r13
  47a436:	e8 d5 b3 fe ff       	call   465810 <skia::textlayout::Cluster::runOrNull() const>
  47a43b:	48 89 c5             	mov    %rax,%rbp
  47a43e:	4c 39 e8             	cmp    %r13,%rax
  47a441:	74 1a                	je     47a45d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4fd>
  47a443:	48 89 c7             	mov    %rax,%rdi
  47a446:	e8 35 b3 fe ff       	call   465780 <skia::textlayout::Run::placeholderStyle() const>
  47a44b:	48 85 c0             	test   %rax,%rax
  47a44e:	74 0d                	je     47a45d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4fd>
  47a450:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  47a455:	48 89 ef             	mov    %rbp,%rdi
  47a458:	e8 d3 a8 fe ff       	call   464d30 <skia::textlayout::Run::updateMetrics(skia::textlayout::InternalLineMetrics*)>
  47a45d:	4d 8b ac 24 18 01 00 	mov    0x118(%r12),%r13
  47a464:	00 
  47a465:	48 83 c3 40          	add    $0x40,%rbx
  47a469:	49 39 dd             	cmp    %rbx,%r13
  47a46c:	73 c2                	jae    47a430 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x4d0>
  47a46e:	f3 0f 10 4c 24 18    	movss  0x18(%rsp),%xmm1
  47a474:	49 8b 9c 24 08 01 00 	mov    0x108(%r12),%rbx
  47a47b:	00 
  47a47c:	49 8b 84 24 48 01 00 	mov    0x148(%r12),%rax
  47a483:	00 
  47a484:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
  47a488:	41 0f 10 a4 24 38 01 	movups 0x138(%r12),%xmm4
  47a48f:	00 00 
  47a491:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  47a496:	f3 41 0f 10 b4 24 3c 	movss  0x13c(%r12),%xmm6
  47a49d:	01 00 00 
  47a4a0:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  47a4a5:	49 8b 45 18          	mov    0x18(%r13),%rax
  47a4a9:	0f 29 a4 24 80 00 00 	movaps %xmm4,0x80(%rsp)
  47a4b0:	00 
  47a4b1:	f3 0f 10 44 24 58    	movss  0x58(%rsp),%xmm0
  47a4b7:	f3 41 0f 10 a4 24 44 	movss  0x144(%r12),%xmm4
  47a4be:	01 00 00 
  47a4c1:	f3 41 0f 10 94 24 48 	movss  0x148(%r12),%xmm2
  47a4c8:	01 00 00 
  47a4cb:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  47a4d0:	48 39 74 24 10       	cmp    %rsi,0x10(%rsp)
  47a4d5:	0f 84 65 09 00 00    	je     47ae40 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xee0>
  47a4db:	49 8b 84 24 28 01 00 	mov    0x128(%r12),%rax
  47a4e2:	00 
  47a4e3:	48 8b 40 10          	mov    0x10(%rax),%rax
  47a4e7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  47a4ec:	48 8b 46 10          	mov    0x10(%rsi),%rax
  47a4f0:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  47a4f5:	48 89 f0             	mov    %rsi,%rax
  47a4f8:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  47a4fd:	48 29 cb             	sub    %rcx,%rbx
  47a500:	48 29 c8             	sub    %rcx,%rax
  47a503:	48 89 da             	mov    %rbx,%rdx
  47a506:	48 c1 f8 06          	sar    $0x6,%rax
  47a50a:	48 c1 fa 06          	sar    $0x6,%rdx
  47a50e:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  47a513:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  47a518:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
  47a51d:	74 14                	je     47a533 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x5d3>
  47a51f:	f6 84 24 90 00 00 00 	testb  $0x1,0x90(%rsp)
  47a526:	01 
  47a527:	74 0a                	je     47a533 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x5d3>
  47a529:	f3 41 0f 11 a4 24 38 	movss  %xmm4,0x138(%r12)
  47a530:	01 00 00 
  47a533:	f6 84 24 90 00 00 00 	testb  $0x2,0x90(%rsp)
  47a53a:	02 
  47a53b:	74 23                	je     47a560 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x600>
  47a53d:	80 bc 24 95 00 00 00 	cmpb   $0x0,0x95(%rsp)
  47a544:	00 
  47a545:	0f 85 d5 09 00 00    	jne    47af20 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xfc0>
  47a54b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  47a550:	48 39 74 24 10       	cmp    %rsi,0x10(%rsp)
  47a555:	0f 84 a8 09 00 00    	je     47af03 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xfa3>
  47a55b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  47a560:	41 80 7f 39 00       	cmpb   $0x0,0x39(%r15)
  47a565:	0f 85 9d 08 00 00    	jne    47ae08 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xea8>
  47a56b:	4c 89 ff             	mov    %r15,%rdi
  47a56e:	f3 0f 11 4c 24 38    	movss  %xmm1,0x38(%rsp)
  47a574:	e8 27 04 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a579:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  47a57f:	84 c0                	test   %al,%al
  47a581:	0f 85 79 07 00 00    	jne    47ad00 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xda0>
  47a587:	f3 41 0f 10 84 24 3c 	movss  0x13c(%r12),%xmm0
  47a58e:	01 00 00 
  47a591:	66 0f ef e4          	pxor   %xmm4,%xmm4
  47a595:	f3 41 0f 10 9c 24 38 	movss  0x138(%r12),%xmm3
  47a59c:	01 00 00 
  47a59f:	f3 41 0f 5a a4 24 40 	cvtss2sd 0x140(%r12),%xmm4
  47a5a6:	01 00 00 
  47a5a9:	f3 0f 5a db          	cvtss2sd %xmm3,%xmm3
  47a5ad:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  47a5b1:	f2 0f 5c c3          	subsd  %xmm3,%xmm0
  47a5b5:	f3 0f 11 4c 24 38    	movss  %xmm1,0x38(%rsp)
  47a5bb:	f2 0f 58 c4          	addsd  %xmm4,%xmm0
  47a5bf:	e8 cc 47 bb ff       	call   2ed90 <round@plt>
  47a5c4:	66 0f ef ff          	pxor   %xmm7,%xmm7
  47a5c8:	49 8b 84 24 08 01 00 	mov    0x108(%r12),%rax
  47a5cf:	00 
  47a5d0:	49 39 84 24 18 01 00 	cmp    %rax,0x118(%r12)
  47a5d7:	00 
  47a5d8:	f2 0f 5a f8          	cvtsd2ss %xmm0,%xmm7
  47a5dc:	49 8b b4 24 20 01 00 	mov    0x120(%r12),%rsi
  47a5e3:	00 
  47a5e4:	f3 41 0f 10 84 24 54 	movss  0x154(%r12),%xmm0
  47a5eb:	01 00 00 
  47a5ee:	f3 0f 11 bc 24 a0 00 	movss  %xmm7,0xa0(%rsp)
  47a5f5:	00 00 
  47a5f7:	f3 41 0f 10 94 24 6c 	movss  0x16c(%r12),%xmm2
  47a5fe:	01 00 00 
  47a601:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  47a607:	0f 14 c7             	unpcklps %xmm7,%xmm0
  47a60a:	0f 84 50 08 00 00    	je     47ae60 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xf00>
  47a610:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  47a615:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  47a61a:	48 39 f8             	cmp    %rdi,%rax
  47a61d:	48 0f 43 f8          	cmovae %rax,%rdi
  47a621:	31 d2                	xor    %edx,%edx
  47a623:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
  47a628:	74 0c                	je     47a636 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x6d6>
  47a62a:	41 0f b6 94 24 6a 01 	movzbl 0x16a(%r12),%edx
  47a631:	00 00 
  47a633:	83 f2 01             	xor    $0x1,%edx
  47a636:	4c 89 e9             	mov    %r13,%rcx
  47a639:	48 2b 4c 24 48       	sub    0x48(%rsp),%rcx
  47a63e:	48 c1 f9 06          	sar    $0x6,%rcx
  47a642:	48 8d 41 01          	lea    0x1(%rcx),%rax
  47a646:	49 8b 8c 24 10 01 00 	mov    0x110(%r12),%rcx
  47a64d:	00 
  47a64e:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  47a653:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  47a65a:	00 
  47a65b:	0f 13 84 24 d0 00 00 	movlps %xmm0,0xd0(%rsp)
  47a662:	00 
  47a663:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  47a668:	f3 41 0f 6f 84 24 38 	movdqu 0x138(%r12),%xmm0
  47a66f:	01 00 00 
  47a672:	48 89 9c 24 08 01 00 	mov    %rbx,0x108(%rsp)
  47a679:	00 
  47a67a:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  47a67f:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  47a686:	00 
  47a687:	f3 41 0f 6f 84 24 44 	movdqu 0x144(%r12),%xmm0
  47a68e:	01 00 00 
  47a691:	48 89 bc 24 18 01 00 	mov    %rdi,0x118(%rsp)
  47a698:	00 
  47a699:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  47a69e:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
  47a6a5:	00 
  47a6a6:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  47a6ab:	48 89 ac 24 00 01 00 	mov    %rbp,0x100(%rsp)
  47a6b2:	00 
  47a6b3:	48 89 ac 24 10 01 00 	mov    %rbp,0x110(%rsp)
  47a6ba:	00 
  47a6bb:	48 89 ac 24 20 01 00 	mov    %rbp,0x120(%rsp)
  47a6c2:	00 
  47a6c3:	48 89 bc 24 28 01 00 	mov    %rdi,0x128(%rsp)
  47a6ca:	00 
  47a6cb:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
  47a6d2:	00 
  47a6d3:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
  47a6da:	00 
  47a6db:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  47a6e2:	00 
  47a6e3:	48 89 b4 24 c8 00 00 	mov    %rsi,0xc8(%rsp)
  47a6ea:	00 
  47a6eb:	c7 84 24 e8 00 00 00 	movl   $0x0,0xe8(%rsp)
  47a6f2:	00 00 00 00 
  47a6f6:	88 94 24 b6 00 00 00 	mov    %dl,0xb6(%rsp)
  47a6fd:	f3 0f 11 8c 24 b8 00 	movss  %xmm1,0xb8(%rsp)
  47a704:	00 00 
  47a706:	f3 0f 11 94 24 ec 00 	movss  %xmm2,0xec(%rsp)
  47a70d:	00 00 
  47a70f:	0f 11 84 24 ac 01 00 	movups %xmm0,0x1ac(%rsp)
  47a716:	00 
  47a717:	48 83 78 10 00       	cmpq   $0x0,0x10(%rax)
  47a71c:	0f 84 08 d2 bb ff    	je     3792a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]+0x2>
  47a722:	f3 0f 11 4c 24 18    	movss  %xmm1,0x18(%rsp)
  47a728:	48 8d 8c 24 20 01 00 	lea    0x120(%rsp),%rcx
  47a72f:	00 
  47a730:	48 8d 94 24 10 01 00 	lea    0x110(%rsp),%rdx
  47a737:	00 
  47a738:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
  47a73f:	00 
  47a740:	48 83 ec 08          	sub    $0x8,%rsp
  47a744:	48 8d 84 24 be 00 00 	lea    0xbe(%rsp),%rax
  47a74b:	00 
  47a74c:	50                   	push   %rax
  47a74d:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
  47a754:	00 
  47a755:	50                   	push   %rax
  47a756:	48 8d 84 24 e8 00 00 	lea    0xe8(%rsp),%rax
  47a75d:	00 
  47a75e:	50                   	push   %rax
  47a75f:	48 8d 84 24 08 01 00 	lea    0x108(%rsp),%rax
  47a766:	00 
  47a767:	50                   	push   %rax
  47a768:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
  47a76f:	00 
  47a770:	50                   	push   %rax
  47a771:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
  47a778:	00 
  47a779:	50                   	push   %rax
  47a77a:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
  47a781:	00 
  47a782:	50                   	push   %rax
  47a783:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  47a78a:	00 
  47a78b:	48 89 c7             	mov    %rax,%rdi
  47a78e:	4c 8d 8c 24 80 01 00 	lea    0x180(%rsp),%r9
  47a795:	00 
  47a796:	4c 8d 84 24 70 01 00 	lea    0x170(%rsp),%r8
  47a79d:	00 
  47a79e:	ff 50 18             	call   *0x18(%rax)
  47a7a1:	f3 0f 10 74 24 64    	movss  0x64(%rsp),%xmm6
  47a7a7:	f3 0f 10 4c 24 58    	movss  0x58(%rsp),%xmm1
  47a7ad:	f3 0f 58 f1          	addss  %xmm1,%xmm6
  47a7b1:	0f 28 c6             	movaps %xmm6,%xmm0
  47a7b4:	f3 0f 11 74 24 64    	movss  %xmm6,0x64(%rsp)
  47a7ba:	48 83 c4 40          	add    $0x40,%rsp
  47a7be:	f3 41 0f 5f 84 24 74 	maxss  0x174(%r12),%xmm0
  47a7c5:	01 00 00 
  47a7c8:	f3 41 0f 11 84 24 74 	movss  %xmm0,0x174(%r12)
  47a7cf:	01 00 00 
  47a7d2:	41 80 bc 24 6a 01 00 	cmpb   $0x0,0x16a(%r12)
  47a7d9:	00 00 
  47a7db:	74 08                	je     47a7e5 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x885>
  47a7dd:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
  47a7e4:	00 
  47a7e5:	4c 89 ff             	mov    %r15,%rdi
  47a7e8:	f3 0f 11 4c 24 18    	movss  %xmm1,0x18(%rsp)
  47a7ee:	e8 ad 01 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a7f3:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  47a7f8:	49 39 de             	cmp    %rbx,%r14
  47a7fb:	0f 93 c2             	setae  %dl
  47a7fe:	20 c2                	and    %al,%dl
  47a800:	88 54 24 38          	mov    %dl,0x38(%rsp)
  47a804:	0f 85 ef 0e 00 00    	jne    47b6f9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1799>
  47a80a:	f3 0f 10 84 24 a0 00 	movss  0xa0(%rsp),%xmm0
  47a811:	00 00 
  47a813:	f3 0f 10 4c 24 18    	movss  0x18(%rsp),%xmm1
  47a819:	f3 41 0f 58 84 24 6c 	addss  0x16c(%r12),%xmm0
  47a820:	01 00 00 
  47a823:	41 80 bc 24 6a 01 00 	cmpb   $0x1,0x16a(%r12)
  47a82a:	00 01 
  47a82c:	f3 41 0f 11 84 24 6c 	movss  %xmm0,0x16c(%r12)
  47a833:	01 00 00 
  47a836:	75 07                	jne    47a83f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x8df>
  47a838:	48 39 5c 24 10       	cmp    %rbx,0x10(%rsp)
  47a83d:	74 29                	je     47a868 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x908>
  47a83f:	b8 ff ff 7f ff       	mov    $0xff7fffff,%eax
  47a844:	0f 28 35 e5 96 03 00 	movaps 0x396e5(%rip),%xmm6        # 4b3f30 <C.119.3+0x1700>
  47a84b:	41 c7 84 24 54 01 00 	movl   $0x0,0x154(%r12)
  47a852:	00 00 00 00 00 
  47a857:	49 89 84 24 48 01 00 	mov    %rax,0x148(%r12)
  47a85e:	00 
  47a85f:	41 0f 11 b4 24 38 01 	movups %xmm6,0x138(%r12)
  47a866:	00 00 
  47a868:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  47a86d:	f3 0f 11 4c 24 18    	movss  %xmm1,0x18(%rsp)
  47a873:	49 c7 84 24 10 01 00 	movq   $0x0,0x110(%r12)
  47a87a:	00 00 00 00 00 
  47a87f:	49 89 84 24 08 01 00 	mov    %rax,0x108(%r12)
  47a886:	00 
  47a887:	48 89 c7             	mov    %rax,%rdi
  47a88a:	49 89 84 24 18 01 00 	mov    %rax,0x118(%r12)
  47a891:	00 
  47a892:	49 c7 84 24 20 01 00 	movq   $0xffffffffffffffff,0x120(%r12)
  47a899:	00 ff ff ff ff 
  47a89e:	e8 6d af fe ff       	call   465810 <skia::textlayout::Cluster::runOrNull() const>
  47a8a3:	f3 0f 10 4c 24 18    	movss  0x18(%rsp),%xmm1
  47a8a9:	48 85 c0             	test   %rax,%rax
  47a8ac:	74 0b                	je     47a8b9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x959>
  47a8ae:	48 83 78 40 ff       	cmpq   $0xffffffffffffffff,0x40(%rax)
  47a8b3:	0f 84 27 07 00 00    	je     47afe0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1080>
  47a8b9:	41 c7 84 24 54 01 00 	movl   $0x0,0x154(%r12)
  47a8c0:	00 00 00 00 00 
  47a8c5:	f3 41 0f 5f 8f 70 04 	maxss  0x470(%r15),%xmm1
  47a8cc:	00 00 
  47a8ce:	f3 41 0f 11 8f 70 04 	movss  %xmm1,0x470(%r15)
  47a8d5:	00 00 
  47a8d7:	80 bc 24 96 00 00 00 	cmpb   $0x0,0x96(%rsp)
  47a8de:	00 
  47a8df:	0f 84 9b 02 00 00    	je     47ab80 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc20>
  47a8e5:	41 0f b6 84 24 6a 01 	movzbl 0x16a(%r12),%eax
  47a8ec:	00 00 
  47a8ee:	88 84 24 95 00 00 00 	mov    %al,0x95(%rsp)
  47a8f5:	84 c0                	test   %al,%al
  47a8f7:	0f 84 e1 08 00 00    	je     47b1de <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x127e>
  47a8fd:	49 83 84 24 60 01 00 	addq   $0x1,0x160(%r12)
  47a904:	00 01 
  47a906:	4d 8b b4 24 18 01 00 	mov    0x118(%r12),%r14
  47a90d:	00 
  47a90e:	4c 39 74 24 10       	cmp    %r14,0x10(%rsp)
  47a913:	0f 84 96 0c 00 00    	je     47b5af <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x164f>
  47a919:	4c 89 ff             	mov    %r15,%rdi
  47a91c:	0f b6 9c 24 97 00 00 	movzbl 0x97(%rsp),%ebx
  47a923:	00 
  47a924:	e8 77 00 fe ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47a929:	84 c0                	test   %al,%al
  47a92b:	0f 84 3b f9 ff ff    	je     47a26c <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x30c>
  47a931:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  47a936:	49 39 c6             	cmp    %rax,%r14
  47a939:	0f 83 b8 0b 00 00    	jae    47b4f7 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1597>
  47a93f:	88 5c 24 58          	mov    %bl,0x58(%rsp)
  47a943:	49 89 c5             	mov    %rax,%r13
  47a946:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47a94a:	31 ed                	xor    %ebp,%ebp
  47a94c:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  47a953:	00 00 
  47a955:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  47a95c:	00 00 
  47a95e:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
  47a963:	4d 89 fc             	mov    %r15,%r12
  47a966:	4d 89 f7             	mov    %r14,%r15
  47a969:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47a970:	f3 41 0f 58 57 30    	addss  0x30(%r15),%xmm2
  47a976:	4c 89 fb             	mov    %r15,%rbx
  47a979:	49 83 c7 40          	add    $0x40,%r15
  47a97d:	0f 28 ca             	movaps %xmm2,%xmm1
  47a980:	4d 39 fe             	cmp    %r15,%r14
  47a983:	0f 83 c7 05 00 00    	jae    47af50 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xff0>
  47a989:	4c 89 f8             	mov    %r15,%rax
  47a98c:	eb 24                	jmp    47a9b2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xa52>
  47a98e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47a995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47a99c:	00 00 00 00 
  47a9a0:	48 83 e8 40          	sub    $0x40,%rax
  47a9a4:	f3 0f 5c 48 30       	subss  0x30(%rax),%xmm1
  47a9a9:	49 39 c6             	cmp    %rax,%r14
  47a9ac:	0f 83 9e 05 00 00    	jae    47af50 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xff0>
  47a9b2:	80 78 f8 00          	cmpb   $0x0,-0x8(%rax)
  47a9b6:	75 e8                	jne    47a9a0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xa40>
  47a9b8:	49 39 c6             	cmp    %rax,%r14
  47a9bb:	0f 83 8f 05 00 00    	jae    47af50 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xff0>
  47a9c1:	49 8b 56 10          	mov    0x10(%r14),%rdx
  47a9c5:	48 8b 40 d8          	mov    -0x28(%rax),%rax
  47a9c9:	48 92                	xchg   %rax,%rdx
  47a9cb:	4c 89 e7             	mov    %r12,%rdi
  47a9ce:	f3 0f 11 54 24 18    	movss  %xmm2,0x18(%rsp)
  47a9d4:	48 89 c6             	mov    %rax,%rsi
  47a9d7:	f3 0f 11 4c 24 08    	movss  %xmm1,0x8(%rsp)
  47a9dd:	e8 3e 08 fe ff       	call   45b220 <skia::textlayout::ParagraphImpl::experimentalPadding(skia::textlayout::SkRange<unsigned long>) const>
  47a9e2:	49 8b 7f d8          	mov    -0x28(%r15),%rdi
  47a9e6:	4d 8b 94 24 68 02 00 	mov    0x268(%r12),%r10
  47a9ed:	00 
  47a9ee:	49 8b b4 24 60 02 00 	mov    0x260(%r12),%rsi
  47a9f5:	00 
  47a9f6:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  47a9fc:	4c 89 d2             	mov    %r10,%rdx
  47a9ff:	f3 0f 10 54 24 18    	movss  0x18(%rsp),%xmm2
  47aa05:	48 29 f2             	sub    %rsi,%rdx
  47aa08:	48 85 d2             	test   %rdx,%rdx
  47aa0b:	7e 38                	jle    47aa45 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xae5>
  47aa0d:	48 c1 fa 03          	sar    $0x3,%rdx
  47aa11:	eb 21                	jmp    47aa34 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xad4>
  47aa13:	66 90                	xchg   %ax,%ax
  47aa15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47aa1c:	00 00 00 00 
  47aa20:	48 29 c2             	sub    %rax,%rdx
  47aa23:	48 8d 74 c6 08       	lea    0x8(%rsi,%rax,8),%rsi
  47aa28:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  47aa2c:	48 85 c0             	test   %rax,%rax
  47aa2f:	7e 14                	jle    47aa45 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xae5>
  47aa31:	48 89 c2             	mov    %rax,%rdx
  47aa34:	48 89 d0             	mov    %rdx,%rax
  47aa37:	48 d1 f8             	sar    $1,%rax
  47aa3a:	48 39 3c c6          	cmp    %rdi,(%rsi,%rax,8)
  47aa3e:	72 e0                	jb     47aa20 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xac0>
  47aa40:	48 85 c0             	test   %rax,%rax
  47aa43:	75 ec                	jne    47aa31 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xad1>
  47aa45:	4c 39 d6             	cmp    %r10,%rsi
  47aa48:	0f 84 f2 04 00 00    	je     47af40 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xfe0>
  47aa4e:	48 3b 3e             	cmp    (%rsi),%rdi
  47aa51:	0f 82 e9 04 00 00    	jb     47af40 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xfe0>
  47aa57:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  47aa5b:	48 85 ed             	test   %rbp,%rbp
  47aa5e:	0f 85 ce 04 00 00    	jne    47af32 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xfd2>
  47aa64:	f3 0f 10 6c 24 3c    	movss  0x3c(%rsp),%xmm5
  47aa6a:	0f 2f e8             	comiss %xmm0,%xmm5
  47aa6d:	0f 83 ed 04 00 00    	jae    47af60 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1000>
  47aa73:	41 0f b6 47 fa       	movzbl -0x6(%r15),%eax
  47aa78:	4c 89 fd             	mov    %r15,%rbp
  47aa7b:	84 c0                	test   %al,%al
  47aa7d:	75 09                	jne    47aa88 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xb28>
  47aa7f:	4d 39 ef             	cmp    %r13,%r15
  47aa82:	0f 82 e8 fe ff ff    	jb     47a970 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xa10>
  47aa88:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  47aa8d:	4d 89 e7             	mov    %r12,%r15
  47aa90:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
  47aa95:	48 89 e8             	mov    %rbp,%rax
  47aa98:	0f b6 5c 24 58       	movzbl 0x58(%rsp),%ebx
  47aa9d:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
  47aaa2:	4d 85 c9             	test   %r9,%r9
  47aaa5:	0f 84 82 06 00 00    	je     47b12d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x11cd>
  47aaab:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  47aab0:	0f b6 eb             	movzbl %bl,%ebp
  47aab3:	4c 89 e7             	mov    %r12,%rdi
  47aab6:	4c 89 ce             	mov    %r9,%rsi
  47aab9:	41 0f b6 97 33 02 00 	movzbl 0x233(%r15),%edx
  47aac0:	00 
  47aac1:	f3 0f 10 05 67 94 03 	movss  0x39467(%rip),%xmm0        # 4b3f30 <C.119.3+0x1700>
  47aac8:	00 
  47aac9:	41 89 e8             	mov    %ebp,%r8d
  47aacc:	e8 ef c9 ff ff       	call   4774c0 <skia::textlayout::TextWrapper::lookAhead(float, skia::textlayout::Cluster*, bool, SkString const*, bool)>
  47aad1:	4c 89 ff             	mov    %r15,%rdi
  47aad4:	e8 c7 fe fd ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47aad9:	e9 bc f7 ff ff       	jmp    47a29a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x33a>
  47aade:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
  47aae5:	00 00 
  47aae7:	e9 8f f5 ff ff       	jmp    47a07b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x11b>
  47aaec:	0f 1f 40 00          	nopl   0x0(%rax)
  47aaf0:	f3 41 0f 10 84 24 58 	movss  0x158(%r12),%xmm0
  47aaf7:	01 00 00 
  47aafa:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  47aaff:	0f 28 c8             	movaps %xmm0,%xmm1
  47ab02:	48 39 c8             	cmp    %rcx,%rax
  47ab05:	72 27                	jb     47ab2e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xbce>
  47ab07:	eb 2b                	jmp    47ab34 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xbd4>
  47ab09:	90                   	nop
  47ab0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47ab11:	00 00 00 00 
  47ab15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47ab1c:	00 00 00 00 
  47ab20:	f3 0f 58 48 30       	addss  0x30(%rax),%xmm1
  47ab25:	48 83 c0 40          	add    $0x40,%rax
  47ab29:	48 39 c8             	cmp    %rcx,%rax
  47ab2c:	73 06                	jae    47ab34 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xbd4>
  47ab2e:	80 78 38 00          	cmpb   $0x0,0x38(%rax)
  47ab32:	75 ec                	jne    47ab20 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xbc0>
  47ab34:	80 7a 38 00          	cmpb   $0x0,0x38(%rdx)
  47ab38:	74 20                	je     47ab5a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xbfa>
  47ab3a:	48 3b 54 24 10       	cmp    0x10(%rsp),%rdx
  47ab3f:	73 19                	jae    47ab5a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xbfa>
  47ab41:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  47ab46:	49 c7 84 24 30 01 00 	movq   $0x0,0x130(%r12)
  47ab4d:	00 00 00 00 00 
  47ab52:	49 89 bc 24 28 01 00 	mov    %rdi,0x128(%r12)
  47ab59:	00 
  47ab5a:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
  47ab5f:	0f 85 4b 04 00 00    	jne    47afb0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1050>
  47ab65:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  47ab6a:	4d 8b ac 24 18 01 00 	mov    0x118(%r12),%r13
  47ab71:	00 
  47ab72:	e9 bd f7 ff ff       	jmp    47a334 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3d4>
  47ab77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  47ab7e:	00 00 
  47ab80:	0f b6 bc 24 95 00 00 	movzbl 0x95(%rsp),%edi
  47ab87:	00 
  47ab88:	f3 0f 10 54 24 24    	movss  0x24(%rsp),%xmm2
  47ab8e:	4d 89 e5             	mov    %r12,%r13
  47ab91:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  47ab96:	40 84 ff             	test   %dil,%dil
  47ab99:	0f 85 71 09 00 00    	jne    47b510 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x15b0>
  47ab9f:	49 8b ac 24 18 01 00 	mov    0x118(%r12),%rbp
  47aba6:	00 
  47aba7:	49 83 84 24 60 01 00 	addq   $0x1,0x160(%r12)
  47abae:	00 01 
  47abb0:	49 39 e9             	cmp    %rbp,%r9
  47abb3:	0f 85 67 f6 ff ff    	jne    47a220 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x2c0>
  47abb9:	66 0f ef db          	pxor   %xmm3,%xmm3
  47abbd:	4c 89 cb             	mov    %r9,%rbx
  47abc0:	eb 37                	jmp    47abf9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc99>
  47abc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  47abc8:	f3 41 0f 7e 95 70 01 	movq   0x170(%r13),%xmm2
  47abcf:	00 00 
  47abd1:	f3 0f 7e d9          	movq   %xmm1,%xmm3
  47abd5:	f3 0f 7e c2          	movq   %xmm2,%xmm0
  47abd9:	0f c2 c3 01          	cmpltps %xmm3,%xmm0
  47abdd:	66 0f ef db          	pxor   %xmm3,%xmm3
  47abe1:	0f 54 c8             	andps  %xmm0,%xmm1
  47abe4:	0f 55 c2             	andnps %xmm2,%xmm0
  47abe7:	0f 28 d3             	movaps %xmm3,%xmm2
  47abea:	0f 56 c1             	orps   %xmm1,%xmm0
  47abed:	41 0f 13 85 70 01 00 	movlps %xmm0,0x170(%r13)
  47abf4:	00 
  47abf5:	48 83 c5 40          	add    $0x40,%rbp
  47abf9:	0f 28 cb             	movaps %xmm3,%xmm1
  47abfc:	0f 14 ca             	unpcklps %xmm2,%xmm1
  47abff:	48 39 dd             	cmp    %rbx,%rbp
  47ac02:	74 3c                	je     47ac40 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xce0>
  47ac04:	41 c6 85 6b 01 00 00 	movb   $0x1,0x16b(%r13)
  47ac0b:	01 
  47ac0c:	80 7d 3a 00          	cmpb   $0x0,0x3a(%rbp)
  47ac10:	75 b6                	jne    47abc8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc68>
  47ac12:	80 7d 38 00          	cmpb   $0x0,0x38(%rbp)
  47ac16:	0f 84 94 02 00 00    	je     47aeb0 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xf50>
  47ac1c:	f3 41 0f 5f 9d 70 01 	maxss  0x170(%r13),%xmm3
  47ac23:	00 00 
  47ac25:	f3 0f 58 55 30       	addss  0x30(%rbp),%xmm2
  47ac2a:	f3 41 0f 11 9d 70 01 	movss  %xmm3,0x170(%r13)
  47ac31:	00 00 
  47ac33:	66 0f ef db          	pxor   %xmm3,%xmm3
  47ac37:	eb bc                	jmp    47abf5 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc95>
  47ac39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  47ac40:	f3 41 0f 7e 95 70 01 	movq   0x170(%r13),%xmm2
  47ac47:	00 00 
  47ac49:	f3 0f 7e d9          	movq   %xmm1,%xmm3
  47ac4d:	41 8b 87 10 04 00 00 	mov    0x410(%r15),%eax
  47ac54:	f3 0f 7e c2          	movq   %xmm2,%xmm0
  47ac58:	0f c2 c3 01          	cmpltps %xmm3,%xmm0
  47ac5c:	0f 54 c8             	andps  %xmm0,%xmm1
  47ac5f:	0f 55 c2             	andnps %xmm2,%xmm0
  47ac62:	0f 56 c1             	orps   %xmm1,%xmm0
  47ac65:	41 0f 13 85 70 01 00 	movlps %xmm0,0x170(%r13)
  47ac6c:	00 
  47ac6d:	85 c0                	test   %eax,%eax
  47ac6f:	0f 85 88 05 00 00    	jne    47b1fd <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x129d>
  47ac75:	f6 84 24 90 00 00 00 	testb  $0x1,0x90(%rsp)
  47ac7c:	01 
  47ac7d:	0f 85 c3 08 00 00    	jne    47b546 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x15e6>
  47ac83:	f3 41 0f 10 85 38 01 	movss  0x138(%r13),%xmm0
  47ac8a:	00 00 
  47ac8c:	41 0f b6 9d 6a 01 00 	movzbl 0x16a(%r13),%ebx
  47ac93:	00 
  47ac94:	f6 84 24 90 00 00 00 	testb  $0x2,0x90(%rsp)
  47ac9b:	02 
  47ac9c:	0f 84 bb 08 00 00    	je     47b55d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x15fd>
  47aca2:	84 db                	test   %bl,%bl
  47aca4:	0f 85 b3 08 00 00    	jne    47b55d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x15fd>
  47acaa:	f3 41 0f 10 8d 48 01 	movss  0x148(%r13),%xmm1
  47acb1:	00 00 
  47acb3:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  47acb7:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47acbb:	f3 41 0f 5a 95 40 01 	cvtss2sd 0x140(%r13),%xmm2
  47acc2:	00 00 
  47acc4:	f3 41 0f 11 8d 3c 01 	movss  %xmm1,0x13c(%r13)
  47accb:	00 00 
  47accd:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  47acd1:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
  47acd5:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
  47acd9:	66 0f 28 c2          	movapd %xmm2,%xmm0
  47acdd:	e8 ae 40 bb ff       	call   2ed90 <round@plt>
  47ace2:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  47ace6:	f3 41 0f 5f 85 6c 01 	maxss  0x16c(%r13),%xmm0
  47aced:	00 00 
  47acef:	f3 41 0f 11 85 6c 01 	movss  %xmm0,0x16c(%r13)
  47acf6:	00 00 
  47acf8:	e9 ac 07 00 00       	jmp    47b4a9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1549>
  47acfd:	0f 1f 00             	nopl   (%rax)
  47ad00:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  47ad05:	48 89 ee             	mov    %rbp,%rsi
  47ad08:	4c 89 ff             	mov    %r15,%rdi
  47ad0b:	f3 0f 11 4c 24 38    	movss  %xmm1,0x38(%rsp)
  47ad11:	e8 aa 05 fe ff       	call   45b2c0 <skia::textlayout::ParagraphImpl::experimentalVerticalPadding(skia::textlayout::SkRange<unsigned long>) const>
  47ad16:	f3 0f 10 3d 26 c3 02 	movss  0x2c326(%rip),%xmm7        # 4a7044 <_IO_stdin_used+0x44>
  47ad1d:	00 
  47ad1e:	f3 0f 10 25 0a 7d 03 	movss  0x37d0a(%rip),%xmm4        # 4b2a30 <C.119.3+0x200>
  47ad25:	00 
  47ad26:	0f 28 d4             	movaps %xmm4,%xmm2
  47ad29:	44 0f 28 c0          	movaps %xmm0,%xmm8
  47ad2d:	f3 0f 10 05 cf c2 02 	movss  0x2c2cf(%rip),%xmm0        # 4a7004 <_IO_stdin_used+0x4>
  47ad34:	00 
  47ad35:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  47ad3b:	f3 41 0f 59 84 24 40 	mulss  0x140(%r12),%xmm0
  47ad42:	01 00 00 
  47ad45:	0f 28 d8             	movaps %xmm0,%xmm3
  47ad48:	f3 41 0f 5c 9c 24 38 	subss  0x138(%r12),%xmm3
  47ad4f:	01 00 00 
  47ad52:	f3 41 0f 58 d8       	addss  %xmm8,%xmm3
  47ad57:	0f 28 eb             	movaps %xmm3,%xmm5
  47ad5a:	0f 54 ec             	andps  %xmm4,%xmm5
  47ad5d:	0f 2e fd             	ucomiss %xmm5,%xmm7
  47ad60:	76 31                	jbe    47ad93 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe33>
  47ad62:	f3 0f 2c c3          	cvttss2si %xmm3,%eax
  47ad66:	66 0f ef ed          	pxor   %xmm5,%xmm5
  47ad6a:	44 0f 28 cb          	movaps %xmm3,%xmm9
  47ad6e:	f3 44 0f 10 15 a5 c2 	movss  0x2c2a5(%rip),%xmm10        # 4a701c <_IO_stdin_used+0x1c>
  47ad75:	02 00 
  47ad77:	0f 55 d3             	andnps %xmm3,%xmm2
  47ad7a:	f3 0f 2a e8          	cvtsi2ss %eax,%xmm5
  47ad7e:	f3 44 0f c2 cd 06    	cmpnless %xmm5,%xmm9
  47ad84:	45 0f 54 ca          	andps  %xmm10,%xmm9
  47ad88:	f3 41 0f 58 e9       	addss  %xmm9,%xmm5
  47ad8d:	0f 56 ea             	orps   %xmm2,%xmm5
  47ad90:	0f 28 dd             	movaps %xmm5,%xmm3
  47ad93:	f3 41 0f 58 84 24 3c 	addss  0x13c(%r12),%xmm0
  47ad9a:	01 00 00 
  47ad9d:	f3 41 0f 58 c0       	addss  %xmm8,%xmm0
  47ada2:	0f 28 e8             	movaps %xmm0,%xmm5
  47ada5:	0f 54 ec             	andps  %xmm4,%xmm5
  47ada8:	0f 2e fd             	ucomiss %xmm5,%xmm7
  47adab:	76 2c                	jbe    47add9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xe79>
  47adad:	f3 0f 2c c0          	cvttss2si %xmm0,%eax
  47adb1:	66 0f ef ed          	pxor   %xmm5,%xmm5
  47adb5:	0f 28 f0             	movaps %xmm0,%xmm6
  47adb8:	f3 0f 10 3d 5c c2 02 	movss  0x2c25c(%rip),%xmm7        # 4a701c <_IO_stdin_used+0x1c>
  47adbf:	00 
  47adc0:	0f 55 e0             	andnps %xmm0,%xmm4
  47adc3:	f3 0f 2a e8          	cvtsi2ss %eax,%xmm5
  47adc7:	f3 0f c2 f5 06       	cmpnless %xmm5,%xmm6
  47adcc:	0f 54 f7             	andps  %xmm7,%xmm6
  47adcf:	f3 0f 58 ee          	addss  %xmm6,%xmm5
  47add3:	0f 56 ec             	orps   %xmm4,%xmm5
  47add6:	0f 28 c5             	movaps %xmm5,%xmm0
  47add9:	0f 57 1d 90 7b 03 00 	xorps  0x37b90(%rip),%xmm3        # 4b2970 <C.119.3+0x140>
  47ade0:	66 0f ef e4          	pxor   %xmm4,%xmm4
  47ade4:	41 c7 84 24 40 01 00 	movl   $0x0,0x140(%r12)
  47adeb:	00 00 00 00 00 
  47adf0:	0f 28 d3             	movaps %xmm3,%xmm2
  47adf3:	0f 14 d0             	unpcklps %xmm0,%xmm2
  47adf6:	41 0f 13 94 24 38 01 	movlps %xmm2,0x138(%r12)
  47adfd:	00 00 
  47adff:	e9 a5 f7 ff ff       	jmp    47a5a9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x649>
  47ae04:	0f 1f 40 00          	nopl   0x0(%rax)
  47ae08:	41 0f 10 9f 4c 04 00 	movups 0x44c(%r15),%xmm3
  47ae0f:	00 
  47ae10:	41 80 bc 24 50 01 00 	cmpb   $0x0,0x150(%r12)
  47ae17:	00 00 
  47ae19:	0f 84 7e 02 00 00    	je     47b09d <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x113d>
  47ae1f:	49 8b 87 5c 04 00 00 	mov    0x45c(%r15),%rax
  47ae26:	41 0f 11 9c 24 38 01 	movups %xmm3,0x138(%r12)
  47ae2d:	00 00 
  47ae2f:	49 89 84 24 48 01 00 	mov    %rax,0x148(%r12)
  47ae36:	00 
  47ae37:	e9 2f f7 ff ff       	jmp    47a56b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x60b>
  47ae3c:	0f 1f 40 00          	nopl   0x0(%rax)
  47ae40:	49 8b 87 48 03 00 00 	mov    0x348(%r15),%rax
  47ae47:	8b 00                	mov    (%rax),%eax
  47ae49:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  47ae4e:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  47ae53:	48 89 f0             	mov    %rsi,%rax
  47ae56:	e9 9d f6 ff ff       	jmp    47a4f8 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x598>
  47ae5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  47ae60:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  47ae64:	0f 85 a6 f7 ff ff    	jne    47a610 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x6b0>
  47ae6a:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  47ae6f:	48 39 e8             	cmp    %rbp,%rax
  47ae72:	48 89 c7             	mov    %rax,%rdi
  47ae75:	48 0f 42 fd          	cmovb  %rbp,%rdi
  47ae79:	31 d2                	xor    %edx,%edx
  47ae7b:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
  47ae80:	74 0c                	je     47ae8e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xf2e>
  47ae82:	41 0f b6 94 24 6a 01 	movzbl 0x16a(%r12),%edx
  47ae89:	00 00 
  47ae8b:	83 f2 01             	xor    $0x1,%edx
  47ae8e:	49 8b b4 24 10 01 00 	mov    0x110(%r12),%rsi
  47ae95:	00 
  47ae96:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  47ae9b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  47aea0:	48 89 f1             	mov    %rsi,%rcx
  47aea3:	e9 a6 f7 ff ff       	jmp    47a64e <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x6ee>
  47aea8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  47aeaf:	00 
  47aeb0:	48 89 ef             	mov    %rbp,%rdi
  47aeb3:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
  47aeb9:	f3 0f 11 5c 24 08    	movss  %xmm3,0x8(%rsp)
  47aebf:	e8 9c a9 fe ff       	call   465860 <skia::textlayout::Cluster::run() const>
  47aec4:	f3 0f 10 45 30       	movss  0x30(%rbp),%xmm0
  47aec9:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  47aecf:	48 83 78 40 ff       	cmpq   $0xffffffffffffffff,0x40(%rax)
  47aed4:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  47aeda:	f3 0f 58 d0          	addss  %xmm0,%xmm2
  47aede:	0f 84 96 02 00 00    	je     47b17a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x121a>
  47aee4:	f3 41 0f 5f 9d 70 01 	maxss  0x170(%r13),%xmm3
  47aeeb:	00 00 
  47aeed:	f3 0f 5f c3          	maxss  %xmm3,%xmm0
  47aef1:	66 0f ef db          	pxor   %xmm3,%xmm3
  47aef5:	f3 41 0f 11 85 70 01 	movss  %xmm0,0x170(%r13)
  47aefc:	00 00 
  47aefe:	e9 f2 fc ff ff       	jmp    47abf5 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc95>
  47af03:	41 80 bc 24 6a 01 00 	cmpb   $0x0,0x16a(%r12)
  47af0a:	00 00 
  47af0c:	0f 85 4e f6 ff ff    	jne    47a560 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x600>
  47af12:	0f 1f 00             	nopl   (%rax)
  47af15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  47af1c:	00 00 00 00 
  47af20:	f3 41 0f 11 84 24 3c 	movss  %xmm0,0x13c(%r12)
  47af27:	01 00 00 
  47af2a:	0f 28 f0             	movaps %xmm0,%xmm6
  47af2d:	e9 2e f6 ff ff       	jmp    47a560 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x600>
  47af32:	f3 0f 10 64 24 3c    	movss  0x3c(%rsp),%xmm4
  47af38:	0f 2f e0             	comiss %xmm0,%xmm4
  47af3b:	73 26                	jae    47af63 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1003>
  47af3d:	0f 1f 00             	nopl   (%rax)
  47af40:	41 0f b6 47 fa       	movzbl -0x6(%r15),%eax
  47af45:	e9 31 fb ff ff       	jmp    47aa7b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xb1b>
  47af4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  47af50:	49 8b 46 10          	mov    0x10(%r14),%rax
  47af54:	48 89 c2             	mov    %rax,%rdx
  47af57:	e9 6d fa ff ff       	jmp    47a9c9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xa69>
  47af5c:	0f 1f 40 00          	nopl   0x0(%rax)
  47af60:	4c 89 fd             	mov    %r15,%rbp
  47af63:	48 89 df             	mov    %rbx,%rdi
  47af66:	f3 0f 11 54 24 08    	movss  %xmm2,0x8(%rsp)
  47af6c:	e8 8f a9 fe ff       	call   465900 <skia::textlayout::Cluster::isSoftBreak() const>
  47af71:	f3 0f 10 54 24 08    	movss  0x8(%rsp),%xmm2
  47af77:	84 c0                	test   %al,%al
  47af79:	41 0f b6 47 fa       	movzbl -0x6(%r15),%eax
  47af7e:	75 18                	jne    47af98 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1038>
  47af80:	4d 39 fd             	cmp    %r15,%r13
  47af83:	74 13                	je     47af98 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1038>
  47af85:	84 c0                	test   %al,%al
  47af87:	75 0f                	jne    47af98 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1038>
  47af89:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
  47af8e:	e9 ec fa ff ff       	jmp    47aa7f <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xb1f>
  47af93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  47af98:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
  47af9d:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
  47afa2:	e9 d4 fa ff ff       	jmp    47aa7b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xb1b>
  47afa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  47afae:	00 00 
  47afb0:	f3 41 0f 6f 8c 24 28 	movdqu 0x128(%r12),%xmm1
  47afb7:	01 00 00 
  47afba:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  47afbf:	f3 41 0f 11 84 24 54 	movss  %xmm0,0x154(%r12)
  47afc6:	01 00 00 
  47afc9:	41 0f 11 8c 24 18 01 	movups %xmm1,0x118(%r12)
  47afd0:	00 00 
  47afd2:	66 49 0f 7e cd       	movq   %xmm1,%r13
  47afd7:	0f 28 c8             	movaps %xmm0,%xmm1
  47afda:	e9 55 f3 ff ff       	jmp    47a334 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x3d4>
  47afdf:	90                   	nop
  47afe0:	41 80 bc 24 50 01 00 	cmpb   $0x0,0x150(%r12)
  47afe7:	00 00 
  47afe9:	0f 85 ca f8 ff ff    	jne    47a8b9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x959>
  47afef:	f3 0f 10 80 d8 00 00 	movss  0xd8(%rax),%xmm0
  47aff6:	00 
  47aff7:	f3 0f 10 98 dc 00 00 	movss  0xdc(%rax),%xmm3
  47affe:	00 
  47afff:	f3 0f 10 90 e0 00 00 	movss  0xe0(%rax),%xmm2
  47b006:	00 
  47b007:	f3 0f 10 a8 98 00 00 	movss  0x98(%rax),%xmm5
  47b00e:	00 
  47b00f:	f3 0f 10 a0 e4 00 00 	movss  0xe4(%rax),%xmm4
  47b016:	00 
  47b017:	f3 0f 58 d8          	addss  %xmm0,%xmm3
  47b01b:	f3 41 0f 5f a4 24 40 	maxss  0x140(%r12),%xmm4
  47b022:	01 00 00 
  47b025:	f3 0f 58 d0          	addss  %xmm0,%xmm2
  47b029:	f3 0f 58 e8          	addss  %xmm0,%xmm5
  47b02d:	f3 41 0f 5f 94 24 3c 	maxss  0x13c(%r12),%xmm2
  47b034:	01 00 00 
  47b037:	f3 41 0f 5d ac 24 44 	minss  0x144(%r12),%xmm5
  47b03e:	01 00 00 
  47b041:	f3 41 0f 5d 9c 24 38 	minss  0x138(%r12),%xmm3
  47b048:	01 00 00 
  47b04b:	0f 14 e5             	unpcklps %xmm5,%xmm4
  47b04e:	0f 14 da             	unpcklps %xmm2,%xmm3
  47b051:	0f 16 dc             	movlhps %xmm4,%xmm3
  47b054:	41 0f 11 9c 24 38 01 	movups %xmm3,0x138(%r12)
  47b05b:	00 00 
  47b05d:	f3 0f 58 80 9c 00 00 	addss  0x9c(%rax),%xmm0
  47b064:	00 
  47b065:	f3 0f 10 90 a4 00 00 	movss  0xa4(%rax),%xmm2
  47b06c:	00 
  47b06d:	f3 41 0f 7e a4 24 48 	movq   0x148(%r12),%xmm4
  47b074:	01 00 00 
  47b077:	0f 14 c2             	unpcklps %xmm2,%xmm0
  47b07a:	f3 0f 7e dc          	movq   %xmm4,%xmm3
  47b07e:	f3 0f 7e e8          	movq   %xmm0,%xmm5
  47b082:	0f c2 dd 01          	cmpltps %xmm5,%xmm3
  47b086:	0f 54 c3             	andps  %xmm3,%xmm0
  47b089:	0f 55 dc             	andnps %xmm4,%xmm3
  47b08c:	0f 56 d8             	orps   %xmm0,%xmm3
  47b08f:	41 0f 13 9c 24 48 01 	movlps %xmm3,0x148(%r12)
  47b096:	00 00 
  47b098:	e9 1c f8 ff ff       	jmp    47a8b9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x959>
  47b09d:	f3 45 0f 10 8f 60 04 	movss  0x460(%r15),%xmm9
  47b0a4:	00 00 
  47b0a6:	44 0f 28 e3          	movaps %xmm3,%xmm12
  47b0aa:	0f 28 fb             	movaps %xmm3,%xmm7
  47b0ad:	f3 44 0f 10 15 4e bf 	movss  0x2bf4e(%rip),%xmm10        # 4a7004 <_IO_stdin_used+0x4>
  47b0b4:	02 00 
  47b0b6:	f3 45 0f 10 87 5c 04 	movss  0x45c(%r15),%xmm8
  47b0bd:	00 00 
  47b0bf:	44 0f 15 e3          	unpckhps %xmm3,%xmm12
  47b0c3:	f3 41 0f 10 af 58 04 	movss  0x458(%r15),%xmm5
  47b0ca:	00 00 
  47b0cc:	0f c6 db 55          	shufps $0x55,%xmm3,%xmm3
  47b0d0:	f3 45 0f 59 ca       	mulss  %xmm10,%xmm9
  47b0d5:	f3 45 0f 59 e2       	mulss  %xmm10,%xmm12
  47b0da:	f3 45 0f 58 c1       	addss  %xmm9,%xmm8
  47b0df:	f3 41 0f 5c e9       	subss  %xmm9,%xmm5
  47b0e4:	f3 41 0f 58 dc       	addss  %xmm12,%xmm3
  47b0e9:	f3 41 0f 5c fc       	subss  %xmm12,%xmm7
  47b0ee:	f3 41 0f 5d bc 24 38 	minss  0x138(%r12),%xmm7
  47b0f5:	01 00 00 
  47b0f8:	f3 41 0f c2 c0 05    	cmpnltss %xmm8,%xmm0
  47b0fe:	f3 0f 5d ec          	minss  %xmm4,%xmm5
  47b102:	f3 0f 5f de          	maxss  %xmm6,%xmm3
  47b106:	0f 54 d0             	andps  %xmm0,%xmm2
  47b109:	41 0f 55 c0          	andnps %xmm8,%xmm0
  47b10d:	0f 56 c2             	orps   %xmm2,%xmm0
  47b110:	0f 14 fb             	unpcklps %xmm3,%xmm7
  47b113:	41 0f 13 bc 24 38 01 	movlps %xmm7,0x138(%r12)
  47b11a:	00 00 
  47b11c:	0f 14 e8             	unpcklps %xmm0,%xmm5
  47b11f:	41 0f 13 ac 24 44 01 	movlps %xmm5,0x144(%r12)
  47b126:	00 00 
  47b128:	e9 3e f4 ff ff       	jmp    47a56b <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x60b>
  47b12d:	4d 85 d2             	test   %r10,%r10
  47b130:	0f 84 b8 03 00 00    	je     47b4ee <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x158e>
  47b136:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  47b13b:	0f b6 eb             	movzbl %bl,%ebp
  47b13e:	4c 89 e7             	mov    %r12,%rdi
  47b141:	4c 89 d6             	mov    %r10,%rsi
  47b144:	41 0f b6 97 33 02 00 	movzbl 0x233(%r15),%edx
  47b14b:	00 
  47b14c:	f3 0f 10 05 dc 8d 03 	movss  0x38ddc(%rip),%xmm0        # 4b3f30 <C.119.3+0x1700>
  47b153:	00 
  47b154:	41 89 e8             	mov    %ebp,%r8d
  47b157:	e8 64 c3 ff ff       	call   4774c0 <skia::textlayout::TextWrapper::lookAhead(float, skia::textlayout::Cluster*, bool, SkString const*, bool)>
  47b15c:	4c 89 ff             	mov    %r15,%rdi
  47b15f:	e8 3c f8 fd ff       	call   45a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>
  47b164:	84 c0                	test   %al,%al
  47b166:	0f 84 2e f1 ff ff    	je     47a29a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x33a>
  47b16c:	41 c6 84 24 68 01 00 	movb   $0x1,0x168(%r12)
  47b173:	00 01 
  47b175:	e9 20 f1 ff ff       	jmp    47a29a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x33a>
  47b17a:	f3 0f 58 d8          	addss  %xmm0,%xmm3
  47b17e:	48 89 ef             	mov    %rbp,%rdi
  47b181:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
  47b187:	f3 0f 11 5c 24 08    	movss  %xmm3,0x8(%rsp)
  47b18d:	e8 6e a7 fe ff       	call   465900 <skia::textlayout::Cluster::isSoftBreak() const>
  47b192:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  47b198:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  47b19e:	84 c0                	test   %al,%al
  47b1a0:	0f 84 4f fa ff ff    	je     47abf5 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc95>
  47b1a6:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  47b1ab:	48 89 ee             	mov    %rbp,%rsi
  47b1ae:	e8 3d bf ff ff       	call   4770f0 <skia::textlayout::(anonymous namespace)::softHyphenWidth(SkString const*, skia::textlayout::Cluster const*)>
  47b1b3:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  47b1b9:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  47b1bf:	f3 0f 58 d8          	addss  %xmm0,%xmm3
  47b1c3:	f3 41 0f 5f 9d 70 01 	maxss  0x170(%r13),%xmm3
  47b1ca:	00 00 
  47b1cc:	f3 41 0f 11 9d 70 01 	movss  %xmm3,0x170(%r13)
  47b1d3:	00 00 
  47b1d5:	66 0f ef db          	pxor   %xmm3,%xmm3
  47b1d9:	e9 17 fa ff ff       	jmp    47abf5 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc95>
  47b1de:	49 8b ac 24 18 01 00 	mov    0x118(%r12),%rbp
  47b1e5:	00 
  47b1e6:	f3 0f 10 54 24 24    	movss  0x24(%rsp),%xmm2
  47b1ec:	4d 89 e5             	mov    %r12,%r13
  47b1ef:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  47b1f4:	48 85 ed             	test   %rbp,%rbp
  47b1f7:	0f 85 bc f9 ff ff    	jne    47abb9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc59>
  47b1fd:	41 80 bd 6a 01 00 00 	cmpb   $0x0,0x16a(%r13)
  47b204:	00 
  47b205:	0f 84 1f 03 00 00    	je     47b52a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x15ca>
  47b20b:	f3 41 0f 10 9d 6c 01 	movss  0x16c(%r13),%xmm3
  47b212:	00 00 
  47b214:	f6 84 24 90 00 00 00 	testb  $0x2,0x90(%rsp)
  47b21b:	02 
  47b21c:	74 12                	je     47b230 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x12d0>
  47b21e:	f3 41 0f 10 85 48 01 	movss  0x148(%r13),%xmm0
  47b225:	00 00 
  47b227:	f3 41 0f 11 85 3c 01 	movss  %xmm0,0x13c(%r13)
  47b22e:	00 00 
  47b230:	41 80 7f 39 00       	cmpb   $0x0,0x39(%r15)
  47b235:	0f 85 8a 03 00 00    	jne    47b5c5 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1665>
  47b23b:	f3 41 0f 10 85 3c 01 	movss  0x13c(%r13),%xmm0
  47b242:	00 00 
  47b244:	f3 41 0f 10 8d 38 01 	movss  0x138(%r13),%xmm1
  47b24b:	00 00 
  47b24d:	f3 41 0f 10 95 40 01 	movss  0x140(%r13),%xmm2
  47b254:	00 00 
  47b256:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  47b25a:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  47b25e:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
  47b262:	4d 8b a5 28 01 00 00 	mov    0x128(%r13),%r12
  47b269:	f3 0f 5a d2          	cvtss2sd %xmm2,%xmm2
  47b26d:	4d 8b b5 18 01 00 00 	mov    0x118(%r13),%r14
  47b274:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  47b279:	f3 0f 11 5c 24 08    	movss  %xmm3,0x8(%rsp)
  47b27f:	4c 89 e5             	mov    %r12,%rbp
  47b282:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
  47b286:	4c 89 f3             	mov    %r14,%rbx
  47b289:	48 29 c5             	sub    %rax,%rbp
  47b28c:	48 29 c3             	sub    %rax,%rbx
  47b28f:	48 c1 fd 06          	sar    $0x6,%rbp
  47b293:	48 c1 fb 06          	sar    $0x6,%rbx
  47b297:	e8 f4 3a bb ff       	call   2ed90 <round@plt>
  47b29c:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  47b2a2:	0f b6 44 24 30       	movzbl 0x30(%rsp),%eax
  47b2a7:	48 89 ac 24 80 01 00 	mov    %rbp,0x180(%rsp)
  47b2ae:	00 
  47b2af:	f3 41 0f 6f 64 24 10 	movdqu 0x10(%r12),%xmm4
  47b2b6:	66 0f 28 c8          	movapd %xmm0,%xmm1
  47b2ba:	f3 41 0f 6f 46 10    	movdqu 0x10(%r14),%xmm0
  47b2c0:	48 89 9c 24 88 01 00 	mov    %rbx,0x188(%rsp)
  47b2c7:	00 
  47b2c8:	f3 41 0f 6f 54 24 10 	movdqu 0x10(%r12),%xmm2
  47b2cf:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  47b2d4:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  47b2d8:	c7 84 24 bc 00 00 00 	movl   $0x0,0xbc(%rsp)
  47b2df:	00 00 00 00 
  47b2e3:	0f 29 a4 24 50 01 00 	movaps %xmm4,0x150(%rsp)
  47b2ea:	00 
  47b2eb:	66 48 0f 6e e3       	movq   %rbx,%xmm4
  47b2f0:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
  47b2f7:	00 
  47b2f8:	66 48 0f 6e c5       	movq   %rbp,%xmm0
  47b2fd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
  47b301:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  47b308:	00 00 00 00 00 
  47b30d:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  47b314:	00 
  47b315:	f3 41 0f 6f 85 38 01 	movdqu 0x138(%r13),%xmm0
  47b31c:	00 00 
  47b31e:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  47b325:	00 00 00 00 00 
  47b32a:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  47b331:	00 
  47b332:	f3 41 0f 6f 85 44 01 	movdqu 0x144(%r13),%xmm0
  47b339:	00 00 
  47b33b:	c7 84 24 f0 00 00 00 	movl   $0x0,0xf0(%rsp)
  47b342:	00 00 00 00 
  47b346:	c7 84 24 f8 00 00 00 	movl   $0x0,0xf8(%rsp)
  47b34d:	00 00 00 00 
  47b351:	88 84 24 b7 00 00 00 	mov    %al,0xb7(%rsp)
  47b358:	0f 29 94 24 60 01 00 	movaps %xmm2,0x160(%rsp)
  47b35f:	00 
  47b360:	f3 0f 11 9c 24 f4 00 	movss  %xmm3,0xf4(%rsp)
  47b367:	00 00 
  47b369:	f3 0f 11 8c 24 fc 00 	movss  %xmm1,0xfc(%rsp)
  47b370:	00 00 
  47b372:	0f 11 84 24 cc 01 00 	movups %xmm0,0x1cc(%rsp)
  47b379:	00 
  47b37a:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
  47b37f:	0f 84 a5 c5 bb ff    	je     3792a <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]+0x2>
  47b385:	48 8d 8c 24 70 01 00 	lea    0x170(%rsp),%rcx
  47b38c:	00 
  47b38d:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  47b394:	00 
  47b395:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
  47b39c:	00 
  47b39d:	48 83 ec 08          	sub    $0x8,%rsp
  47b3a1:	48 8d 84 24 bf 00 00 	lea    0xbf(%rsp),%rax
  47b3a8:	00 
  47b3a9:	50                   	push   %rax
  47b3aa:	48 8d 84 24 d0 01 00 	lea    0x1d0(%rsp),%rax
  47b3b1:	00 
  47b3b2:	50                   	push   %rax
  47b3b3:	48 8d 84 24 10 01 00 	lea    0x110(%rsp),%rax
  47b3ba:	00 
  47b3bb:	50                   	push   %rax
  47b3bc:	48 8d 84 24 10 01 00 	lea    0x110(%rsp),%rax
  47b3c3:	00 
  47b3c4:	50                   	push   %rax
  47b3c5:	48 8d 84 24 08 01 00 	lea    0x108(%rsp),%rax
  47b3cc:	00 
  47b3cd:	50                   	push   %rax
  47b3ce:	48 8d 84 24 08 01 00 	lea    0x108(%rsp),%rax
  47b3d5:	00 
  47b3d6:	50                   	push   %rax
  47b3d7:	48 8d 84 24 f4 00 00 	lea    0xf4(%rsp),%rax
  47b3de:	00 
  47b3df:	50                   	push   %rax
  47b3e0:	4c 8d 8c 24 d0 01 00 	lea    0x1d0(%rsp),%r9
  47b3e7:	00 
  47b3e8:	4c 8d 84 24 c0 01 00 	lea    0x1c0(%rsp),%r8
  47b3ef:	00 
  47b3f0:	ff 57 18             	call   *0x18(%rdi)
  47b3f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47b3f7:	66 0f ef c9          	pxor   %xmm1,%xmm1
  47b3fb:	48 83 c4 40          	add    $0x40,%rsp
  47b3ff:	f3 41 0f 5a 8d 38 01 	cvtss2sd 0x138(%r13),%xmm1
  47b406:	00 00 
  47b408:	f3 41 0f 5a 85 3c 01 	cvtss2sd 0x13c(%r13),%xmm0
  47b40f:	00 00 
  47b411:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
  47b415:	66 0f ef c9          	pxor   %xmm1,%xmm1
  47b419:	f3 41 0f 5a 8d 40 01 	cvtss2sd 0x140(%r13),%xmm1
  47b420:	00 00 
  47b422:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
  47b426:	e8 65 39 bb ff       	call   2ed90 <round@plt>
  47b42b:	49 63 87 10 04 00 00 	movslq 0x410(%r15),%rax
  47b432:	49 8b 8f 08 04 00 00 	mov    0x408(%r15),%rcx
  47b439:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  47b43d:	f3 41 0f 58 85 6c 01 	addss  0x16c(%r13),%xmm0
  47b444:	00 00 
  47b446:	f3 41 0f 11 85 6c 01 	movss  %xmm0,0x16c(%r13)
  47b44d:	00 00 
  47b44f:	48 85 c0             	test   %rax,%rax
  47b452:	0f 84 d0 c4 bb ff    	je     37928 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&) [clone .cold]>
  47b458:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  47b45d:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
  47b461:	0f 28 bc 24 80 00 00 	movaps 0x80(%rsp),%xmm7
  47b468:	00 
  47b469:	48 c1 e2 08          	shl    $0x8,%rdx
  47b46d:	48 89 b4 11 d4 00 00 	mov    %rsi,0xd4(%rcx,%rdx,1)
  47b474:	00 
  47b475:	c6 84 11 dc 00 00 00 	movb   $0x0,0xdc(%rcx,%rdx,1)
  47b47c:	00 
  47b47d:	0f 11 bc 11 c4 00 00 	movups %xmm7,0xc4(%rcx,%rdx,1)
  47b484:	00 
  47b485:	f6 84 24 90 00 00 00 	testb  $0x1,0x90(%rsp)
  47b48c:	01 
  47b48d:	74 07                	je     47b496 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1536>
  47b48f:	c6 81 e3 00 00 00 00 	movb   $0x0,0xe3(%rcx)
  47b496:	f6 84 24 90 00 00 00 	testb  $0x2,0x90(%rsp)
  47b49d:	02 
  47b49e:	74 09                	je     47b4a9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1549>
  47b4a0:	48 c1 e0 08          	shl    $0x8,%rax
  47b4a4:	c6 44 08 e4 00       	movb   $0x0,-0x1c(%rax,%rcx,1)
  47b4a9:	48 8b ac 24 00 02 00 	mov    0x200(%rsp),%rbp
  47b4b0:	00 
  47b4b1:	4c 8b a4 24 08 02 00 	mov    0x208(%rsp),%r12
  47b4b8:	00 
  47b4b9:	4c 8b ac 24 10 02 00 	mov    0x210(%rsp),%r13
  47b4c0:	00 
  47b4c1:	4c 8b b4 24 18 02 00 	mov    0x218(%rsp),%r14
  47b4c8:	00 
  47b4c9:	4c 8b bc 24 20 02 00 	mov    0x220(%rsp),%r15
  47b4d0:	00 
  47b4d1:	e9 dc ea ff ff       	jmp    479fb2 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x52>
  47b4d6:	0f 28 05 53 8a 03 00 	movaps 0x38a53(%rip),%xmm0        # 4b3f30 <C.119.3+0x1700>
  47b4dd:	f3 0f 10 0d 4f 8a 03 	movss  0x38a4f(%rip),%xmm1        # 4b3f34 <C.119.3+0x1704>
  47b4e4:	00 
  47b4e5:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47b4e9:	e9 53 ec ff ff       	jmp    47a141 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1e1>
  47b4ee:	48 85 ed             	test   %rbp,%rbp
  47b4f1:	48 0f 44 44 24 10    	cmove  0x10(%rsp),%rax
  47b4f7:	49 89 c2             	mov    %rax,%r10
  47b4fa:	e9 37 fc ff ff       	jmp    47b136 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x11d6>
  47b4ff:	88 44 24 38          	mov    %al,0x38(%rsp)
  47b503:	89 c7                	mov    %eax,%edi
  47b505:	89 d3                	mov    %edx,%ebx
  47b507:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47b50b:	e9 33 ed ff ff       	jmp    47a243 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x2e3>
  47b510:	49 8b ac 24 18 01 00 	mov    0x118(%r12),%rbp
  47b517:	00 
  47b518:	41 c6 84 24 6a 01 00 	movb   $0x0,0x16a(%r12)
  47b51f:	00 00 
  47b521:	48 85 ed             	test   %rbp,%rbp
  47b524:	0f 85 8f f6 ff ff    	jne    47abb9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc59>
  47b52a:	49 63 87 10 04 00 00 	movslq 0x410(%r15),%rax
  47b531:	48 85 c0             	test   %rax,%rax
  47b534:	0f 84 6f ff ff ff    	je     47b4a9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1549>
  47b53a:	49 8b 8f 08 04 00 00 	mov    0x408(%r15),%rcx
  47b541:	e9 3f ff ff ff       	jmp    47b485 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1525>
  47b546:	f3 41 0f 10 85 44 01 	movss  0x144(%r13),%xmm0
  47b54d:	00 00 
  47b54f:	f3 41 0f 11 85 38 01 	movss  %xmm0,0x138(%r13)
  47b556:	00 00 
  47b558:	e9 2f f7 ff ff       	jmp    47ac8c <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xd2c>
  47b55d:	66 0f ef c9          	pxor   %xmm1,%xmm1
  47b561:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  47b565:	f3 41 0f 5a 8d 3c 01 	cvtss2sd 0x13c(%r13),%xmm1
  47b56c:	00 00 
  47b56e:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
  47b572:	66 0f ef c0          	pxor   %xmm0,%xmm0
  47b576:	f3 41 0f 5a 85 40 01 	cvtss2sd 0x140(%r13),%xmm0
  47b57d:	00 00 
  47b57f:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
  47b583:	e8 08 38 bb ff       	call   2ed90 <round@plt>
  47b588:	66 0f ef db          	pxor   %xmm3,%xmm3
  47b58c:	f2 0f 5a d8          	cvtsd2ss %xmm0,%xmm3
  47b590:	f3 41 0f 5f 9d 6c 01 	maxss  0x16c(%r13),%xmm3
  47b597:	00 00 
  47b599:	f3 41 0f 11 9d 6c 01 	movss  %xmm3,0x16c(%r13)
  47b5a0:	00 00 
  47b5a2:	84 db                	test   %bl,%bl
  47b5a4:	0f 85 6a fc ff ff    	jne    47b214 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x12b4>
  47b5aa:	e9 fa fe ff ff       	jmp    47b4a9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x1549>
  47b5af:	f3 0f 10 54 24 24    	movss  0x24(%rsp),%xmm2
  47b5b5:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  47b5ba:	4c 89 f5             	mov    %r14,%rbp
  47b5bd:	4d 89 e5             	mov    %r12,%r13
  47b5c0:	e9 f4 f5 ff ff       	jmp    47abb9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc59>
  47b5c5:	41 0f 10 a7 4c 04 00 	movups 0x44c(%r15),%xmm4
  47b5cc:	00 
  47b5cd:	f3 41 0f 10 97 54 04 	movss  0x454(%r15),%xmm2
  47b5d4:	00 00 
  47b5d6:	41 80 bd 50 01 00 00 	cmpb   $0x0,0x150(%r13)
  47b5dd:	00 
  47b5de:	74 25                	je     47b605 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x16a5>
  47b5e0:	49 8b 87 5c 04 00 00 	mov    0x45c(%r15),%rax
  47b5e7:	0f 28 c4             	movaps %xmm4,%xmm0
  47b5ea:	0f 28 cc             	movaps %xmm4,%xmm1
  47b5ed:	41 0f 11 a5 38 01 00 	movups %xmm4,0x138(%r13)
  47b5f4:	00 
  47b5f5:	0f c6 c4 55          	shufps $0x55,%xmm4,%xmm0
  47b5f9:	49 89 85 48 01 00 00 	mov    %rax,0x148(%r13)
  47b600:	e9 51 fc ff ff       	jmp    47b256 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x12f6>
  47b605:	f3 0f 10 3d f7 b9 02 	movss  0x2b9f7(%rip),%xmm7        # 4a7004 <_IO_stdin_used+0x4>
  47b60c:	00 
  47b60d:	f3 41 0f 10 b7 60 04 	movss  0x460(%r15),%xmm6
  47b614:	00 00 
  47b616:	f3 41 0f 10 87 4c 04 	movss  0x44c(%r15),%xmm0
  47b61d:	00 00 
  47b61f:	f3 41 0f 10 a7 58 04 	movss  0x458(%r15),%xmm4
  47b626:	00 00 
  47b628:	f3 41 0f 10 af 5c 04 	movss  0x45c(%r15),%xmm5
  47b62f:	00 00 
  47b631:	f3 0f 59 d7          	mulss  %xmm7,%xmm2
  47b635:	f3 0f 59 f7          	mulss  %xmm7,%xmm6
  47b639:	0f 28 c8             	movaps %xmm0,%xmm1
  47b63c:	f3 0f 5c ca          	subss  %xmm2,%xmm1
  47b640:	f3 41 0f 58 97 50 04 	addss  0x450(%r15),%xmm2
  47b647:	00 00 
  47b649:	f3 41 0f 5d 8d 38 01 	minss  0x138(%r13),%xmm1
  47b650:	00 00 
  47b652:	f3 0f 5c e6          	subss  %xmm6,%xmm4
  47b656:	f3 41 0f 5f 95 3c 01 	maxss  0x13c(%r13),%xmm2
  47b65d:	00 00 
  47b65f:	f3 0f 58 ee          	addss  %xmm6,%xmm5
  47b663:	f3 41 0f 5f ad 48 01 	maxss  0x148(%r13),%xmm5
  47b66a:	00 00 
  47b66c:	0f 28 c2             	movaps %xmm2,%xmm0
  47b66f:	0f 28 d1             	movaps %xmm1,%xmm2
  47b672:	0f 14 d0             	unpcklps %xmm0,%xmm2
  47b675:	41 0f 13 95 38 01 00 	movlps %xmm2,0x138(%r13)
  47b67c:	00 
  47b67d:	0f 28 d4             	movaps %xmm4,%xmm2
  47b680:	f3 41 0f 5d 95 44 01 	minss  0x144(%r13),%xmm2
  47b687:	00 00 
  47b689:	0f 14 d5             	unpcklps %xmm5,%xmm2
  47b68c:	41 0f 13 95 44 01 00 	movlps %xmm2,0x144(%r13)
  47b693:	00 
  47b694:	f3 41 0f 10 95 40 01 	movss  0x140(%r13),%xmm2
  47b69b:	00 00 
  47b69d:	e9 b4 fb ff ff       	jmp    47b256 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0x12f6>
  47b6a2:	0f 28 25 87 88 03 00 	movaps 0x38887(%rip),%xmm4        # 4b3f30 <C.119.3+0x1700>
  47b6a9:	b8 ff ff 7f ff       	mov    $0xff7fffff,%eax
  47b6ae:	c6 44 24 30 00       	movb   $0x0,0x30(%rsp)
  47b6b3:	48 89 f5             	mov    %rsi,%rbp
  47b6b6:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  47b6bb:	66 0f ef d2          	pxor   %xmm2,%xmm2
  47b6bf:	0f 29 a4 24 80 00 00 	movaps %xmm4,0x80(%rsp)
  47b6c6:	00 
  47b6c7:	e9 ed f4 ff ff       	jmp    47abb9 <skia::textlayout::TextWrapper::breakTextIntoLines(skia::textlayout::ParagraphImpl*, float, std::function<void (skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, skia::textlayout::SkRange<unsigned long>, float, unsigned long, unsigned long, SkPoint, SkPoint, skia::textlayout::InternalLineMetrics, bool)> const&)+0xc59>
  47b6cc:	48 89 ac 24 00 02 00 	mov    %rbp,0x200(%rsp)
  47b6d3:	00 
  47b6d4:	4c 89 a4 24 08 02 00 	mov    %r12,0x208(%rsp)
  47b6db:	00 
  47b6dc:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
  47b6e3:	00 
  47b6e4:	4c 89 b4 24 18 02 00 	mov    %r14,0x218(%rsp)
  47b6eb:	00 
  47b6ec:	4c 89 bc 24 20 02 00 	mov    %r15,0x220(%rsp)
  47b6f3:	00 
  47b6f4:	e8 e7 2c bb ff       	call   2e3e0 <__stack_chk_fail@plt>
  47b6f9:	b9 3c 02 00 00       	mov    $0x23c,%ecx
  47b6fe:	48 8d 15 ab 62 03 00 	lea    0x362ab(%rip),%rdx        # 4b19b0 <_IO_stdin_used+0xa9b0>
  47b705:	31 ff                	xor    %edi,%edi
  47b707:	31 c0                	xor    %eax,%eax
  47b709:	48 8d 35 d0 62 03 00 	lea    0x362d0(%rip),%rsi        # 4b19e0 <_IO_stdin_used+0xa9e0>
  47b710:	e8 7b 0a c1 ff       	call   8c190 <SkLog(SkLogPriority, char const*, ...)>
  47b715:	e8 f4 85 bb ff       	call   33d0e <sk_abort_no_print()>
