
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/retained-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

0000000000461c00 <skia::textlayout::ParagraphImpl::layout(float)>:
  461c00:	48 83 ec 78          	sub    $0x78,%rsp
  461c04:	0f b6 97 33 02 00 00 	movzbl 0x233(%rdi),%edx
  461c0b:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  461c10:	66 41 0f 7e c7       	movd   %xmm0,%r15d
  461c15:	48 89 6c 24 50       	mov    %rbp,0x50(%rsp)
  461c1a:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
  461c21:	00 00 
  461c23:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  461c28:	48 89 fd             	mov    %rdi,%rbp
  461c2b:	84 d2                	test   %dl,%dl
  461c2d:	74 27                	je     461c56 <skia::textlayout::ParagraphImpl::layout(float)+0x56>
  461c2f:	f3 0f 10 15 19 0e 05 	movss  0x50e19(%rip),%xmm2        # 4b2a50 <C.119.3+0x200>
  461c36:	00 
  461c37:	f3 0f 10 25 05 54 04 	movss  0x45405(%rip),%xmm4        # 4a7044 <_IO_stdin_used+0x44>
  461c3e:	00 
  461c3f:	0f 28 c8             	movaps %xmm0,%xmm1
  461c42:	0f 28 d8             	movaps %xmm0,%xmm3
  461c45:	0f 54 ca             	andps  %xmm2,%xmm1
  461c48:	0f 2e e1             	ucomiss %xmm1,%xmm4
  461c4b:	0f 87 b7 04 00 00    	ja     462108 <skia::textlayout::ParagraphImpl::layout(float)+0x508>
  461c51:	66 41 0f 7e df       	movd   %xmm3,%r15d
  461c56:	f3 0f 5c c0          	subss  %xmm0,%xmm0
  461c5a:	8b 85 50 03 00 00    	mov    0x350(%rbp),%eax
  461c60:	0f 2e c0             	ucomiss %xmm0,%xmm0
  461c63:	7a 12                	jp     461c77 <skia::textlayout::ParagraphImpl::layout(float)+0x77>
  461c65:	66 41 0f 6e ff       	movd   %r15d,%xmm7
  461c6a:	0f 2f bd 58 02 00 00 	comiss 0x258(%rbp),%xmm7
  461c71:	0f 82 59 03 00 00    	jb     461fd0 <skia::textlayout::ParagraphImpl::layout(float)+0x3d0>
  461c77:	83 f8 04             	cmp    $0x4,%eax
  461c7a:	0f 8f 40 02 00 00    	jg     461ec0 <skia::textlayout::ParagraphImpl::layout(float)+0x2c0>
  461c80:	83 f8 01             	cmp    $0x1,%eax
  461c83:	0f 8f 7f 0f 00 00    	jg     462c08 <skia::textlayout::ParagraphImpl::layout(float)+0x1008>
  461c89:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  461c8e:	48 8b b5 78 02 00 00 	mov    0x278(%rbp),%rsi
  461c95:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  461c9a:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
  461c9f:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  461ca4:	48 39 b5 80 02 00 00 	cmp    %rsi,0x280(%rbp)
  461cab:	0f 84 25 0b 00 00    	je     4627d6 <skia::textlayout::ParagraphImpl::layout(float)+0xbd6>
  461cb1:	83 f8 01             	cmp    $0x1,%eax
  461cb4:	0f 85 46 0b 00 00    	jne    462800 <skia::textlayout::ParagraphImpl::layout(float)+0xc00>
  461cba:	48 8b 8d 60 02 00 00 	mov    0x260(%rbp),%rcx
  461cc1:	48 89 c8             	mov    %rcx,%rax
  461cc4:	48 39 8d 68 02 00 00 	cmp    %rcx,0x268(%rbp)
  461ccb:	74 07                	je     461cd4 <skia::textlayout::ParagraphImpl::layout(float)+0xd4>
  461ccd:	48 89 8d 68 02 00 00 	mov    %rcx,0x268(%rbp)
  461cd4:	8b 95 80 03 00 00    	mov    0x380(%rbp),%edx
  461cda:	85 d2                	test   %edx,%edx
  461cdc:	0f 84 2c 11 00 00    	je     462e0e <skia::textlayout::ParagraphImpl::layout(float)+0x120e>
  461ce2:	31 db                	xor    %ebx,%ebx
  461ce4:	90                   	nop
  461ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  461cec:	00 00 00 00 
  461cf0:	48 8b 85 78 03 00 00 	mov    0x378(%rbp),%rax
  461cf7:	39 da                	cmp    %ebx,%edx
  461cf9:	0f 8e 73 5b bd ff    	jle    37872 <skia::textlayout::ParagraphImpl::layout(float) [clone .cold]+0xc>
  461cff:	85 db                	test   %ebx,%ebx
  461d01:	0f 88 6b 5b bd ff    	js     37872 <skia::textlayout::ParagraphImpl::layout(float) [clone .cold]+0xc>
  461d07:	89 d9                	mov    %ebx,%ecx
  461d09:	f6 04 88 02          	testb  $0x2,(%rax,%rcx,4)
  461d0d:	74 25                	je     461d34 <skia::textlayout::ParagraphImpl::layout(float)+0x134>
  461d0f:	48 8b 85 68 02 00 00 	mov    0x268(%rbp),%rax
  461d16:	4c 8b a5 70 02 00 00 	mov    0x270(%rbp),%r12
  461d1d:	4c 39 e0             	cmp    %r12,%rax
  461d20:	0f 84 e2 05 00 00    	je     462308 <skia::textlayout::ParagraphImpl::layout(float)+0x708>
  461d26:	48 89 18             	mov    %rbx,(%rax)
  461d29:	48 83 c0 08          	add    $0x8,%rax
  461d2d:	48 89 85 68 02 00 00 	mov    %rax,0x268(%rbp)
  461d34:	48 83 c3 01          	add    $0x1,%rbx
  461d38:	48 63 c2             	movslq %edx,%rax
  461d3b:	48 39 c3             	cmp    %rax,%rbx
  461d3e:	72 b0                	jb     461cf0 <skia::textlayout::ParagraphImpl::layout(float)+0xf0>
  461d40:	48 8b 95 48 03 00 00 	mov    0x348(%rbp),%rdx
  461d47:	48 8b 85 68 02 00 00 	mov    0x268(%rbp),%rax
  461d4e:	44 8b 2a             	mov    (%rdx),%r13d
  461d51:	48 39 85 70 02 00 00 	cmp    %rax,0x270(%rbp)
  461d58:	0f 84 c5 0f 00 00    	je     462d23 <skia::textlayout::ParagraphImpl::layout(float)+0x1123>
  461d5e:	4c 89 28             	mov    %r13,(%rax)
  461d61:	48 83 c0 08          	add    $0x8,%rax
  461d65:	48 89 85 68 02 00 00 	mov    %rax,0x268(%rbp)
  461d6c:	48 8b bd 98 02 00 00 	mov    0x298(%rbp),%rdi
  461d73:	66 0f ef c0          	pxor   %xmm0,%xmm0
  461d77:	48 8b b5 a8 02 00 00 	mov    0x2a8(%rbp),%rsi
  461d7e:	c6 85 c0 02 00 00 00 	movb   $0x0,0x2c0(%rbp)
  461d85:	48 83 85 b0 02 00 00 	addq   $0x1,0x2b0(%rbp)
  461d8c:	01 
  461d8d:	48 c7 85 a8 02 00 00 	movq   $0x0,0x2a8(%rbp)
  461d94:	00 00 00 00 
  461d98:	0f 11 85 98 02 00 00 	movups %xmm0,0x298(%rbp)
  461d9f:	48 85 ff             	test   %rdi,%rdi
  461da2:	74 08                	je     461dac <skia::textlayout::ParagraphImpl::layout(float)+0x1ac>
  461da4:	48 29 fe             	sub    %rdi,%rsi
  461da7:	e8 f4 c3 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  461dac:	8b 85 60 03 00 00    	mov    0x360(%rbp),%eax
  461db2:	85 c0                	test   %eax,%eax
  461db4:	74 64                	je     461e1a <skia::textlayout::ParagraphImpl::layout(float)+0x21a>
  461db6:	4c 63 e0             	movslq %eax,%r12
  461db9:	48 8b 9d 58 03 00 00 	mov    0x358(%rbp),%rbx
  461dc0:	4d 69 e4 f8 00 00 00 	imul   $0xf8,%r12,%r12
  461dc7:	49 01 dc             	add    %rbx,%r12
  461dca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  461dd0:	48 8d bb f0 00 00 00 	lea    0xf0(%rbx),%rdi
  461dd7:	e8 b4 e0 bf ff       	call   5fe90 <SkString::~SkString()>
  461ddc:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  461de3:	0f 85 b7 06 00 00    	jne    4624a0 <skia::textlayout::ParagraphImpl::layout(float)+0x8a0>
  461de9:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
  461ded:	48 85 ff             	test   %rdi,%rdi
  461df0:	74 0a                	je     461dfc <skia::textlayout::ParagraphImpl::layout(float)+0x1fc>
  461df2:	f0 83 2f 01          	lock subl $0x1,(%rdi)
  461df6:	0f 84 bc 06 00 00    	je     4624b8 <skia::textlayout::ParagraphImpl::layout(float)+0x8b8>
  461dfc:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
  461e00:	48 85 ff             	test   %rdi,%rdi
  461e03:	0f 84 7f 06 00 00    	je     462488 <skia::textlayout::ParagraphImpl::layout(float)+0x888>
  461e09:	e8 42 50 be ff       	call   46e50 <SkRefCntBase::unref() const>
  461e0e:	48 81 c3 f8 00 00 00 	add    $0xf8,%rbx
  461e15:	4c 39 e3             	cmp    %r12,%rbx
  461e18:	72 b6                	jb     461dd0 <skia::textlayout::ParagraphImpl::layout(float)+0x1d0>
  461e1a:	48 8b 85 48 03 00 00 	mov    0x348(%rbp),%rax
  461e21:	c7 85 60 03 00 00 00 	movl   $0x0,0x360(%rbp)
  461e28:	00 00 00 
  461e2b:	c7 85 70 03 00 00 00 	movl   $0x0,0x370(%rbp)
  461e32:	00 00 00 
  461e35:	c7 85 90 03 00 00 00 	movl   $0x0,0x390(%rbp)
  461e3c:	00 00 00 
  461e3f:	8b 18                	mov    (%rax),%ebx
  461e41:	8b 85 94 03 00 00    	mov    0x394(%rbp),%eax
  461e47:	83 c3 01             	add    $0x1,%ebx
  461e4a:	d1 e8                	shr    $1,%eax
  461e4c:	39 c3                	cmp    %eax,%ebx
  461e4e:	0f 8f fc 07 00 00    	jg     462650 <skia::textlayout::ParagraphImpl::layout(float)+0xa50>
  461e54:	89 9d 90 03 00 00    	mov    %ebx,0x390(%rbp)
  461e5a:	4c 8b ad 88 03 00 00 	mov    0x388(%rbp),%r13
  461e61:	31 c0                	xor    %eax,%eax
  461e63:	85 db                	test   %ebx,%ebx
  461e65:	7e 15                	jle    461e7c <skia::textlayout::ParagraphImpl::layout(float)+0x27c>
  461e67:	89 da                	mov    %ebx,%edx
  461e69:	49 8d 7c c5 00       	lea    0x0(%r13,%rax,8),%rdi
  461e6e:	be ff 00 00 00       	mov    $0xff,%esi
  461e73:	48 c1 e2 03          	shl    $0x3,%rdx
  461e77:	e8 b4 c5 bc ff       	call   2e430 <memset@plt>
  461e7c:	48 89 ef             	mov    %rbp,%rdi
  461e7f:	e8 0c ef ff ff       	call   460d90 <skia::textlayout::ParagraphImpl::shapeTextIntoEndlessLine()>
  461e84:	84 c0                	test   %al,%al
  461e86:	0f 84 be 09 00 00    	je     46284a <skia::textlayout::ParagraphImpl::layout(float)+0xc4a>
  461e8c:	48 8b 85 78 02 00 00 	mov    0x278(%rbp),%rax
  461e93:	48 39 85 80 02 00 00 	cmp    %rax,0x280(%rbp)
  461e9a:	0f 84 80 0d 00 00    	je     462c20 <skia::textlayout::ParagraphImpl::layout(float)+0x1020>
  461ea0:	c7 85 50 03 00 00 02 	movl   $0x2,0x350(%rbp)
  461ea7:	00 00 00 
  461eaa:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
  461eaf:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
  461eb4:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  461eb9:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
  461ebe:	eb 2b                	jmp    461eeb <skia::textlayout::ParagraphImpl::layout(float)+0x2eb>
  461ec0:	83 bd 10 04 00 00 01 	cmpl   $0x1,0x410(%rbp)
  461ec7:	0f 84 53 07 00 00    	je     462620 <skia::textlayout::ParagraphImpl::layout(float)+0xa20>
  461ecd:	66 41 0f 6e ff       	movd   %r15d,%xmm7
  461ed2:	0f 2e bd 68 04 00 00 	ucomiss 0x468(%rbp),%xmm7
  461ed9:	7a 06                	jp     461ee1 <skia::textlayout::ParagraphImpl::layout(float)+0x2e1>
  461edb:	0f 84 0b 01 00 00    	je     461fec <skia::textlayout::ParagraphImpl::layout(float)+0x3ec>
  461ee1:	c7 85 50 03 00 00 02 	movl   $0x2,0x350(%rbp)
  461ee8:	00 00 00 
  461eeb:	c6 85 5c 02 00 00 00 	movb   $0x0,0x25c(%rbp)
  461ef2:	66 0f ef c0          	pxor   %xmm0,%xmm0
  461ef6:	48 89 ef             	mov    %rbp,%rdi
  461ef9:	48 c7 85 50 02 00 00 	movq   $0x0,0x250(%rbp)
  461f00:	00 00 00 00 
  461f04:	c7 85 58 02 00 00 00 	movl   $0x0,0x258(%rbp)
  461f0b:	00 00 00 
  461f0e:	c7 85 70 04 00 00 00 	movl   $0x0,0x470(%rbp)
  461f15:	00 00 00 
  461f18:	0f 11 85 40 02 00 00 	movups %xmm0,0x240(%rbp)
  461f1f:	e8 ac b2 ff ff       	call   45d1d0 <skia::textlayout::ParagraphImpl::resolveStrut()>
  461f24:	48 89 ef             	mov    %rbp,%rdi
  461f27:	e8 84 ce ff ff       	call   45edb0 <skia::textlayout::ParagraphImpl::computeEmptyMetrics()>
  461f2c:	48 63 85 10 04 00 00 	movslq 0x410(%rbp),%rax
  461f33:	85 c0                	test   %eax,%eax
  461f35:	0f 84 1a 03 00 00    	je     462255 <skia::textlayout::ParagraphImpl::layout(float)+0x655>
  461f3b:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
  461f40:	4c 8b ad 08 04 00 00 	mov    0x408(%rbp),%r13
  461f47:	48 c1 e0 08          	shl    $0x8,%rax
  461f4b:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  461f50:	4c 01 e8             	add    %r13,%rax
  461f53:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  461f58:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  461f5d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  461f62:	0f 1f 00             	nopl   (%rax)
  461f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  461f6c:	00 00 00 00 
  461f70:	4d 8b b5 f0 00 00 00 	mov    0xf0(%r13),%r14
  461f77:	49 8b 9d e8 00 00 00 	mov    0xe8(%r13),%rbx
  461f7e:	49 39 de             	cmp    %rbx,%r14
  461f81:	75 31                	jne    461fb4 <skia::textlayout::ParagraphImpl::layout(float)+0x3b4>
  461f83:	e9 df 01 00 00       	jmp    462167 <skia::textlayout::ParagraphImpl::layout(float)+0x567>
  461f88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  461f8f:	00 
  461f90:	4c 8b 23             	mov    (%rbx),%r12
  461f93:	4d 85 e4             	test   %r12,%r12
  461f96:	74 0c                	je     461fa4 <skia::textlayout::ParagraphImpl::layout(float)+0x3a4>
  461f98:	f0 41 83 2c 24 01    	lock subl $0x1,(%r12)
  461f9e:	0f 84 cc 04 00 00    	je     462470 <skia::textlayout::ParagraphImpl::layout(float)+0x870>
  461fa4:	48 81 c3 a0 00 00 00 	add    $0xa0,%rbx
  461fab:	49 39 de             	cmp    %rbx,%r14
  461fae:	0f 84 ac 01 00 00    	je     462160 <skia::textlayout::ParagraphImpl::layout(float)+0x560>
  461fb4:	0f b6 43 60          	movzbl 0x60(%rbx),%eax
  461fb8:	3c ff                	cmp    $0xff,%al
  461fba:	74 d4                	je     461f90 <skia::textlayout::ParagraphImpl::layout(float)+0x390>
  461fbc:	84 c0                	test   %al,%al
  461fbe:	75 d0                	jne    461f90 <skia::textlayout::ParagraphImpl::layout(float)+0x390>
  461fc0:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  461fc4:	e8 57 b7 bf ff       	call   5d720 <SkPaint::~SkPaint()>
  461fc9:	eb c5                	jmp    461f90 <skia::textlayout::ParagraphImpl::layout(float)+0x390>
  461fcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  461fd0:	83 f8 04             	cmp    $0x4,%eax
  461fd3:	0f 8e a7 fc ff ff    	jle    461c80 <skia::textlayout::ParagraphImpl::layout(float)+0x80>
  461fd9:	0f 2e bd 68 04 00 00 	ucomiss 0x468(%rbp),%xmm7
  461fe0:	0f 8a fb fe ff ff    	jp     461ee1 <skia::textlayout::ParagraphImpl::layout(float)+0x2e1>
  461fe6:	0f 85 f5 fe ff ff    	jne    461ee1 <skia::textlayout::ParagraphImpl::layout(float)+0x2e1>
  461fec:	83 f8 05             	cmp    $0x5,%eax
  461fef:	0f 84 81 02 00 00    	je     462276 <skia::textlayout::ParagraphImpl::layout(float)+0x676>
  461ff5:	f3 0f 10 8d 48 02 00 	movss  0x248(%rbp),%xmm1
  461ffc:	00 
  461ffd:	66 41 0f 6e c7       	movd   %r15d,%xmm0
  462002:	0f 14 c1             	unpcklps %xmm1,%xmm0
  462005:	0f 13 85 68 04 00 00 	movlps %xmm0,0x468(%rbp)
  46200c:	f3 0f 10 85 50 02 00 	movss  0x250(%rbp),%xmm0
  462013:	00 
  462014:	84 d2                	test   %dl,%dl
  462016:	0f 84 99 00 00 00    	je     4620b5 <skia::textlayout::ParagraphImpl::layout(float)+0x4b5>
  46201c:	f3 0f 10 8d 54 02 00 	movss  0x254(%rbp),%xmm1
  462023:	00 
  462024:	f3 0f 10 1d 58 50 04 	movss  0x45058(%rip),%xmm3        # 4a7084 <_IO_stdin_used+0x84>
  46202b:	00 
  46202c:	f3 0f 10 15 1c 0a 05 	movss  0x50a1c(%rip),%xmm2        # 4b2a50 <C.119.3+0x200>
  462033:	00 
  462034:	0f 28 e1             	movaps %xmm1,%xmm4
  462037:	0f 54 e2             	andps  %xmm2,%xmm4
  46203a:	0f 2f dc             	comiss %xmm4,%xmm3
  46203d:	0f 87 2d 05 00 00    	ja     462570 <skia::textlayout::ParagraphImpl::layout(float)+0x970>
  462043:	f3 0f 10 2d 7d 54 04 	movss  0x4547d(%rip),%xmm5        # 4a74c8 <_IO_stdin_used+0x4c8>
  46204a:	00 
  46204b:	0f 2f ec             	comiss %xmm4,%xmm5
  46204e:	0f 87 0c 07 00 00    	ja     462760 <skia::textlayout::ParagraphImpl::layout(float)+0xb60>
  462054:	f3 0f 10 35 e8 4f 04 	movss  0x44fe8(%rip),%xmm6        # 4a7044 <_IO_stdin_used+0x44>
  46205b:	00 
  46205c:	0f 28 e1             	movaps %xmm1,%xmm4
  46205f:	0f 28 ea             	movaps %xmm2,%xmm5
  462062:	0f 54 e2             	andps  %xmm2,%xmm4
  462065:	0f 2e f4             	ucomiss %xmm4,%xmm6
  462068:	0f 87 aa 03 00 00    	ja     462418 <skia::textlayout::ParagraphImpl::layout(float)+0x818>
  46206e:	f3 0f 11 8d 54 02 00 	movss  %xmm1,0x254(%rbp)
  462075:	00 
  462076:	0f 28 c8             	movaps %xmm0,%xmm1
  462079:	0f 54 ca             	andps  %xmm2,%xmm1
  46207c:	0f 2f d9             	comiss %xmm1,%xmm3
  46207f:	0f 87 6b 04 00 00    	ja     4624f0 <skia::textlayout::ParagraphImpl::layout(float)+0x8f0>
  462085:	f3 0f 10 1d 3b 54 04 	movss  0x4543b(%rip),%xmm3        # 4a74c8 <_IO_stdin_used+0x4c8>
  46208c:	00 
  46208d:	0f 2f d9             	comiss %xmm1,%xmm3
  462090:	0f 87 4a 06 00 00    	ja     4626e0 <skia::textlayout::ParagraphImpl::layout(float)+0xae0>
  462096:	f3 0f 10 1d a6 4f 04 	movss  0x44fa6(%rip),%xmm3        # 4a7044 <_IO_stdin_used+0x44>
  46209d:	00 
  46209e:	0f 28 c8             	movaps %xmm0,%xmm1
  4620a1:	0f 54 ca             	andps  %xmm2,%xmm1
  4620a4:	0f 2e d9             	ucomiss %xmm1,%xmm3
  4620a7:	0f 87 33 03 00 00    	ja     4623e0 <skia::textlayout::ParagraphImpl::layout(float)+0x7e0>
  4620ad:	f3 0f 11 85 50 02 00 	movss  %xmm0,0x250(%rbp)
  4620b4:	00 
  4620b5:	48 8b 85 f8 01 00 00 	mov    0x1f8(%rbp),%rax
  4620bc:	48 83 f8 01          	cmp    $0x1,%rax
  4620c0:	0f 84 8b 00 00 00    	je     462151 <skia::textlayout::ParagraphImpl::layout(float)+0x551>
  4620c6:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  4620ca:	74 74                	je     462140 <skia::textlayout::ParagraphImpl::layout(float)+0x540>
  4620cc:	f3 0f 10 8d 54 02 00 	movss  0x254(%rbp),%xmm1
  4620d3:	00 
  4620d4:	0f 2f c8             	comiss %xmm0,%xmm1
  4620d7:	76 08                	jbe    4620e1 <skia::textlayout::ParagraphImpl::layout(float)+0x4e1>
  4620d9:	f3 0f 11 8d 50 02 00 	movss  %xmm1,0x250(%rbp)
  4620e0:	00 
  4620e1:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  4620e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
  4620ed:	00 00 
  4620ef:	0f 85 80 0d 00 00    	jne    462e75 <skia::textlayout::ParagraphImpl::layout(float)+0x1275>
  4620f5:	48 8b 6c 24 50       	mov    0x50(%rsp),%rbp
  4620fa:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  4620ff:	48 83 c4 78          	add    $0x78,%rsp
  462103:	c3                   	ret
  462104:	0f 1f 40 00          	nopl   0x0(%rax)
  462108:	f3 0f 2c c0          	cvttss2si %xmm0,%eax
  46210c:	66 0f ef c9          	pxor   %xmm1,%xmm1
  462110:	f3 0f 10 25 04 4f 04 	movss  0x44f04(%rip),%xmm4        # 4a701c <_IO_stdin_used+0x1c>
  462117:	00 
  462118:	0f 55 d0             	andnps %xmm0,%xmm2
  46211b:	f3 0f 2a c8          	cvtsi2ss %eax,%xmm1
  46211f:	0f 28 d9             	movaps %xmm1,%xmm3
  462122:	f3 0f c2 d8 06       	cmpnless %xmm0,%xmm3
  462127:	0f 54 dc             	andps  %xmm4,%xmm3
  46212a:	f3 0f 5c cb          	subss  %xmm3,%xmm1
  46212e:	0f 28 d9             	movaps %xmm1,%xmm3
  462131:	0f 56 da             	orps   %xmm2,%xmm3
  462134:	e9 18 fb ff ff       	jmp    461c51 <skia::textlayout::ParagraphImpl::layout(float)+0x51>
  462139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  462140:	48 8b 85 20 02 00 00 	mov    0x220(%rbp),%rax
  462147:	8b 00                	mov    (%rax),%eax
  462149:	85 c0                	test   %eax,%eax
  46214b:	0f 84 77 02 00 00    	je     4623c8 <skia::textlayout::ParagraphImpl::layout(float)+0x7c8>
  462151:	f3 0f 11 85 54 02 00 	movss  %xmm0,0x254(%rbp)
  462158:	00 
  462159:	eb 86                	jmp    4620e1 <skia::textlayout::ParagraphImpl::layout(float)+0x4e1>
  46215b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  462160:	49 8b 9d e8 00 00 00 	mov    0xe8(%r13),%rbx
  462167:	48 85 db             	test   %rbx,%rbx
  46216a:	74 12                	je     46217e <skia::textlayout::ParagraphImpl::layout(float)+0x57e>
  46216c:	49 8b b5 f8 00 00 00 	mov    0xf8(%r13),%rsi
  462173:	48 89 df             	mov    %rbx,%rdi
  462176:	48 29 de             	sub    %rbx,%rsi
  462179:	e8 22 c0 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  46217e:	49 8b 9d a0 00 00 00 	mov    0xa0(%r13),%rbx
  462185:	48 85 db             	test   %rbx,%rbx
  462188:	74 47                	je     4621d1 <skia::textlayout::ParagraphImpl::layout(float)+0x5d1>
  46218a:	48 8d bb f0 00 00 00 	lea    0xf0(%rbx),%rdi
  462191:	e8 fa dc bf ff       	call   5fe90 <SkString::~SkString()>
  462196:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  46219d:	0f 85 65 04 00 00    	jne    462608 <skia::textlayout::ParagraphImpl::layout(float)+0xa08>
  4621a3:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
  4621a7:	48 85 ff             	test   %rdi,%rdi
  4621aa:	74 0a                	je     4621b6 <skia::textlayout::ParagraphImpl::layout(float)+0x5b6>
  4621ac:	f0 83 2f 01          	lock subl $0x1,(%rdi)
  4621b0:	0f 84 8a 06 00 00    	je     462840 <skia::textlayout::ParagraphImpl::layout(float)+0xc40>
  4621b6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
  4621ba:	48 85 ff             	test   %rdi,%rdi
  4621bd:	74 05                	je     4621c4 <skia::textlayout::ParagraphImpl::layout(float)+0x5c4>
  4621bf:	e8 8c 4c be ff       	call   46e50 <SkRefCntBase::unref() const>
  4621c4:	be f8 00 00 00       	mov    $0xf8,%esi
  4621c9:	48 89 df             	mov    %rbx,%rdi
  4621cc:	e8 cf bf bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  4621d1:	49 8b 9d 98 00 00 00 	mov    0x98(%r13),%rbx
  4621d8:	48 85 db             	test   %rbx,%rbx
  4621db:	74 47                	je     462224 <skia::textlayout::ParagraphImpl::layout(float)+0x624>
  4621dd:	48 8d bb f0 00 00 00 	lea    0xf0(%rbx),%rdi
  4621e4:	e8 a7 dc bf ff       	call   5fe90 <SkString::~SkString()>
  4621e9:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  4621f0:	0f 85 fa 03 00 00    	jne    4625f0 <skia::textlayout::ParagraphImpl::layout(float)+0x9f0>
  4621f6:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
  4621fa:	48 85 ff             	test   %rdi,%rdi
  4621fd:	74 0a                	je     462209 <skia::textlayout::ParagraphImpl::layout(float)+0x609>
  4621ff:	f0 83 2f 01          	lock subl $0x1,(%rdi)
  462203:	0f 84 27 06 00 00    	je     462830 <skia::textlayout::ParagraphImpl::layout(float)+0xc30>
  462209:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
  46220d:	48 85 ff             	test   %rdi,%rdi
  462210:	74 05                	je     462217 <skia::textlayout::ParagraphImpl::layout(float)+0x617>
  462212:	e8 39 4c be ff       	call   46e50 <SkRefCntBase::unref() const>
  462217:	be f8 00 00 00       	mov    $0xf8,%esi
  46221c:	48 89 df             	mov    %rbx,%rdi
  46221f:	e8 7c bf bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  462224:	41 f6 45 7c 01       	testb  $0x1,0x7c(%r13)
  462229:	0f 85 99 02 00 00    	jne    4624c8 <skia::textlayout::ParagraphImpl::layout(float)+0x8c8>
  46222f:	49 81 c5 00 01 00 00 	add    $0x100,%r13
  462236:	4c 3b 6c 24 08       	cmp    0x8(%rsp),%r13
  46223b:	0f 82 2f fd ff ff    	jb     461f70 <skia::textlayout::ParagraphImpl::layout(float)+0x370>
  462241:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
  462246:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
  46224b:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  462250:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
  462255:	c7 85 10 04 00 00 00 	movl   $0x0,0x410(%rbp)
  46225c:	00 00 00 
  46225f:	66 41 0f 6e c7       	movd   %r15d,%xmm0
  462264:	48 89 ef             	mov    %rbp,%rdi
  462267:	e8 24 be ff ff       	call   45e090 <skia::textlayout::ParagraphImpl::breakShapedTextIntoLines(float)>
  46226c:	c7 85 50 03 00 00 05 	movl   $0x5,0x350(%rbp)
  462273:	00 00 00 
  462276:	48 63 95 60 03 00 00 	movslq 0x360(%rbp),%rdx
  46227d:	48 8b 85 58 03 00 00 	mov    0x358(%rbp),%rax
  462284:	48 69 d2 f8 00 00 00 	imul   $0xf8,%rdx,%rdx
  46228b:	48 01 c2             	add    %rax,%rdx
  46228e:	48 39 d0             	cmp    %rdx,%rax
  462291:	74 49                	je     4622dc <skia::textlayout::ParagraphImpl::layout(float)+0x6dc>
  462293:	48 89 d1             	mov    %rdx,%rcx
  462296:	48 29 c1             	sub    %rax,%rcx
  462299:	83 e1 08             	and    $0x8,%ecx
  46229c:	74 22                	je     4622c0 <skia::textlayout::ParagraphImpl::layout(float)+0x6c0>
  46229e:	c7 80 88 00 00 00 00 	movl   $0x0,0x88(%rax)
  4622a5:	00 00 00 
  4622a8:	48 05 f8 00 00 00    	add    $0xf8,%rax
  4622ae:	48 39 c2             	cmp    %rax,%rdx
  4622b1:	74 29                	je     4622dc <skia::textlayout::ParagraphImpl::layout(float)+0x6dc>
  4622b3:	66 90                	xchg   %ax,%ax
  4622b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4622bc:	00 00 00 00 
  4622c0:	c7 80 88 00 00 00 00 	movl   $0x0,0x88(%rax)
  4622c7:	00 00 00 
  4622ca:	48 05 f0 01 00 00    	add    $0x1f0,%rax
  4622d0:	c7 40 90 00 00 00 00 	movl   $0x0,-0x70(%rax)
  4622d7:	48 39 c2             	cmp    %rax,%rdx
  4622da:	75 e4                	jne    4622c0 <skia::textlayout::ParagraphImpl::layout(float)+0x6c0>
  4622dc:	f3 0f 10 85 4c 02 00 	movss  0x24c(%rbp),%xmm0
  4622e3:	00 
  4622e4:	48 89 ef             	mov    %rbp,%rdi
  4622e7:	e8 14 ac ff ff       	call   45cf00 <skia::textlayout::ParagraphImpl::formatLines(float)>
  4622ec:	0f b6 95 33 02 00 00 	movzbl 0x233(%rbp),%edx
  4622f3:	c7 85 50 03 00 00 06 	movl   $0x6,0x350(%rbp)
  4622fa:	00 00 00 
  4622fd:	e9 f3 fc ff ff       	jmp    461ff5 <skia::textlayout::ParagraphImpl::layout(float)+0x3f5>
  462302:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  462308:	4c 8b ad 60 02 00 00 	mov    0x260(%rbp),%r13
  46230f:	4d 89 e0             	mov    %r12,%r8
  462312:	48 b8 ff ff ff ff ff 	movabs $0xfffffffffffffff,%rax
  462319:	ff ff 0f 
  46231c:	4d 29 e8             	sub    %r13,%r8
  46231f:	4c 89 c2             	mov    %r8,%rdx
  462322:	48 c1 fa 03          	sar    $0x3,%rdx
  462326:	48 39 c2             	cmp    %rax,%rdx
  462329:	0f 84 37 55 bd ff    	je     37866 <skia::textlayout::ParagraphImpl::layout(float) [clone .cold]>
  46232f:	48 85 d2             	test   %rdx,%rdx
  462332:	b8 01 00 00 00       	mov    $0x1,%eax
  462337:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  46233c:	48 0f 45 c2          	cmovne %rdx,%rax
  462340:	48 01 d0             	add    %rdx,%rax
  462343:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffffff,%rdx
  46234a:	ff ff 0f 
  46234d:	48 39 d0             	cmp    %rdx,%rax
  462350:	48 0f 47 c2          	cmova  %rdx,%rax
  462354:	48 c1 e0 03          	shl    $0x3,%rax
  462358:	48 89 c7             	mov    %rax,%rdi
  46235b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  462360:	e8 cb be bc ff       	call   2e230 <operator new(unsigned long)@plt>
  462365:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  46236a:	49 89 c6             	mov    %rax,%r14
  46236d:	4a 89 1c 00          	mov    %rbx,(%rax,%r8,1)
  462371:	4d 85 c0             	test   %r8,%r8
  462374:	0f 85 d6 00 00 00    	jne    462450 <skia::textlayout::ParagraphImpl::layout(float)+0x850>
  46237a:	4b 8d 44 06 08       	lea    0x8(%r14,%r8,1),%rax
  46237f:	4d 85 ed             	test   %r13,%r13
  462382:	74 18                	je     46239c <skia::textlayout::ParagraphImpl::layout(float)+0x79c>
  462384:	4c 89 e6             	mov    %r12,%rsi
  462387:	4c 89 ef             	mov    %r13,%rdi
  46238a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  46238f:	4c 29 ee             	sub    %r13,%rsi
  462392:	e8 09 be bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  462397:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  46239c:	4c 89 b5 60 02 00 00 	mov    %r14,0x260(%rbp)
  4623a3:	4c 03 74 24 08       	add    0x8(%rsp),%r14
  4623a8:	48 89 85 68 02 00 00 	mov    %rax,0x268(%rbp)
  4623af:	8b 95 80 03 00 00    	mov    0x380(%rbp),%edx
  4623b5:	4c 89 b5 70 02 00 00 	mov    %r14,0x270(%rbp)
  4623bc:	e9 73 f9 ff ff       	jmp    461d34 <skia::textlayout::ParagraphImpl::layout(float)+0x134>
  4623c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  4623c8:	48 83 bd 08 02 00 00 	cmpq   $0x0,0x208(%rbp)
  4623cf:	00 
  4623d0:	0f 84 f6 fc ff ff    	je     4620cc <skia::textlayout::ParagraphImpl::layout(float)+0x4cc>
  4623d6:	e9 76 fd ff ff       	jmp    462151 <skia::textlayout::ParagraphImpl::layout(float)+0x551>
  4623db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  4623e0:	f3 0f 2c c0          	cvttss2si %xmm0,%eax
  4623e4:	66 0f ef c9          	pxor   %xmm1,%xmm1
  4623e8:	f3 0f 10 25 2c 4c 04 	movss  0x44c2c(%rip),%xmm4        # 4a701c <_IO_stdin_used+0x1c>
  4623ef:	00 
  4623f0:	0f 55 d0             	andnps %xmm0,%xmm2
  4623f3:	f3 0f 2a c8          	cvtsi2ss %eax,%xmm1
  4623f7:	0f 28 d9             	movaps %xmm1,%xmm3
  4623fa:	f3 0f c2 d8 06       	cmpnless %xmm0,%xmm3
  4623ff:	0f 54 dc             	andps  %xmm4,%xmm3
  462402:	f3 0f 5c cb          	subss  %xmm3,%xmm1
  462406:	0f 56 ca             	orps   %xmm2,%xmm1
  462409:	0f 28 c1             	movaps %xmm1,%xmm0
  46240c:	e9 9c fc ff ff       	jmp    4620ad <skia::textlayout::ParagraphImpl::layout(float)+0x4ad>
  462411:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  462418:	f3 0f 2c c1          	cvttss2si %xmm1,%eax
  46241c:	66 0f ef e4          	pxor   %xmm4,%xmm4
  462420:	f3 0f 10 3d f4 4b 04 	movss  0x44bf4(%rip),%xmm7        # 4a701c <_IO_stdin_used+0x1c>
  462427:	00 
  462428:	0f 55 e9             	andnps %xmm1,%xmm5
  46242b:	f3 0f 2a e0          	cvtsi2ss %eax,%xmm4
  46242f:	0f 28 f4             	movaps %xmm4,%xmm6
  462432:	f3 0f c2 f1 06       	cmpnless %xmm1,%xmm6
  462437:	0f 54 f7             	andps  %xmm7,%xmm6
  46243a:	f3 0f 5c e6          	subss  %xmm6,%xmm4
  46243e:	0f 56 e5             	orps   %xmm5,%xmm4
  462441:	0f 28 cc             	movaps %xmm4,%xmm1
  462444:	e9 25 fc ff ff       	jmp    46206e <skia::textlayout::ParagraphImpl::layout(float)+0x46e>
  462449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  462450:	4c 89 c2             	mov    %r8,%rdx
  462453:	4c 89 ee             	mov    %r13,%rsi
  462456:	48 89 c7             	mov    %rax,%rdi
  462459:	e8 a2 bc bc ff       	call   2e100 <memcpy@plt>
  46245e:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  462463:	e9 12 ff ff ff       	jmp    46237a <skia::textlayout::ParagraphImpl::layout(float)+0x77a>
  462468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  46246f:	00 
  462470:	4c 89 e7             	mov    %r12,%rdi
  462473:	e8 c8 69 ed ff       	call   338e40 <SkTextBlob::~SkTextBlob()>
  462478:	4c 89 e7             	mov    %r12,%rdi
  46247b:	e8 90 6b ed ff       	call   339010 <SkTextBlob::operator delete(void*)>
  462480:	e9 1f fb ff ff       	jmp    461fa4 <skia::textlayout::ParagraphImpl::layout(float)+0x3a4>
  462485:	0f 1f 00             	nopl   (%rax)
  462488:	48 81 c3 f8 00 00 00 	add    $0xf8,%rbx
  46248f:	4c 39 e3             	cmp    %r12,%rbx
  462492:	0f 82 38 f9 ff ff    	jb     461dd0 <skia::textlayout::ParagraphImpl::layout(float)+0x1d0>
  462498:	e9 7d f9 ff ff       	jmp    461e1a <skia::textlayout::ParagraphImpl::layout(float)+0x21a>
  46249d:	0f 1f 00             	nopl   (%rax)
  4624a0:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  4624a7:	e8 f4 2e c0 ff       	call   653a0 <sk_free(void*)>
  4624ac:	e9 38 f9 ff ff       	jmp    461de9 <skia::textlayout::ParagraphImpl::layout(float)+0x1e9>
  4624b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  4624b8:	e8 e3 2e c0 ff       	call   653a0 <sk_free(void*)>
  4624bd:	e9 3a f9 ff ff       	jmp    461dfc <skia::textlayout::ParagraphImpl::layout(float)+0x1fc>
  4624c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  4624c8:	49 8b 7d 70          	mov    0x70(%r13),%rdi
  4624cc:	49 81 c5 00 01 00 00 	add    $0x100,%r13
  4624d3:	e8 c8 2e c0 ff       	call   653a0 <sk_free(void*)>
  4624d8:	4c 3b 6c 24 08       	cmp    0x8(%rsp),%r13
  4624dd:	0f 82 8d fa ff ff    	jb     461f70 <skia::textlayout::ParagraphImpl::layout(float)+0x370>
  4624e3:	e9 59 fd ff ff       	jmp    462241 <skia::textlayout::ParagraphImpl::layout(float)+0x641>
  4624e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  4624ef:	00 
  4624f0:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  4624f4:	f2 0f 59 05 64 1e 05 	mulsd  0x51e64(%rip),%xmm0        # 4b4360 <C.117.2+0x370>
  4624fb:	00 
  4624fc:	f2 0f 10 15 14 1b 05 	movsd  0x51b14(%rip),%xmm2        # 4b4018 <C.117.2+0x28>
  462503:	00 
  462504:	f2 0f 58 05 fc 1a 05 	addsd  0x51afc(%rip),%xmm0        # 4b4008 <C.117.2+0x18>
  46250b:	00 
  46250c:	f2 0f 10 1d fc 1a 05 	movsd  0x51afc(%rip),%xmm3        # 4b4010 <C.117.2+0x20>
  462513:	00 
  462514:	66 0f 28 c8          	movapd %xmm0,%xmm1
  462518:	66 0f 54 ca          	andpd  %xmm2,%xmm1
  46251c:	66 0f 2e d9          	ucomisd %xmm1,%xmm3
  462520:	76 33                	jbe    462555 <skia::textlayout::ParagraphImpl::layout(float)+0x955>
  462522:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
  462527:	66 0f ef c9          	pxor   %xmm1,%xmm1
  46252b:	f2 0f 10 25 cd 1a 05 	movsd  0x51acd(%rip),%xmm4        # 4b4000 <C.117.2+0x10>
  462532:	00 
  462533:	66 0f 55 d0          	andnpd %xmm0,%xmm2
  462537:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
  46253c:	66 0f 28 d9          	movapd %xmm1,%xmm3
  462540:	f2 0f c2 d8 06       	cmpnlesd %xmm0,%xmm3
  462545:	66 0f 54 dc          	andpd  %xmm4,%xmm3
  462549:	f2 0f 5c cb          	subsd  %xmm3,%xmm1
  46254d:	66 0f 56 ca          	orpd   %xmm2,%xmm1
  462551:	66 0f 28 c1          	movapd %xmm1,%xmm0
  462555:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  462559:	f3 0f 5e 05 ab 4a 04 	divss  0x44aab(%rip),%xmm0        # 4a700c <_IO_stdin_used+0xc>
  462560:	00 
  462561:	e9 47 fb ff ff       	jmp    4620ad <skia::textlayout::ParagraphImpl::layout(float)+0x4ad>
  462566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  46256d:	00 00 00 
  462570:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  462574:	f2 0f 59 0d e4 1d 05 	mulsd  0x51de4(%rip),%xmm1        # 4b4360 <C.117.2+0x370>
  46257b:	00 
  46257c:	f2 0f 10 2d 94 1a 05 	movsd  0x51a94(%rip),%xmm5        # 4b4018 <C.117.2+0x28>
  462583:	00 
  462584:	f2 0f 58 0d 7c 1a 05 	addsd  0x51a7c(%rip),%xmm1        # 4b4008 <C.117.2+0x18>
  46258b:	00 
  46258c:	f2 0f 10 35 7c 1a 05 	movsd  0x51a7c(%rip),%xmm6        # 4b4010 <C.117.2+0x20>
  462593:	00 
  462594:	66 0f 28 e1          	movapd %xmm1,%xmm4
  462598:	66 0f 54 e5          	andpd  %xmm5,%xmm4
  46259c:	66 0f 2e f4          	ucomisd %xmm4,%xmm6
  4625a0:	76 33                	jbe    4625d5 <skia::textlayout::ParagraphImpl::layout(float)+0x9d5>
  4625a2:	f2 48 0f 2c c1       	cvttsd2si %xmm1,%rax
  4625a7:	66 0f ef e4          	pxor   %xmm4,%xmm4
  4625ab:	f2 0f 10 3d 4d 1a 05 	movsd  0x51a4d(%rip),%xmm7        # 4b4000 <C.117.2+0x10>
  4625b2:	00 
  4625b3:	66 0f 55 e9          	andnpd %xmm1,%xmm5
  4625b7:	f2 48 0f 2a e0       	cvtsi2sd %rax,%xmm4
  4625bc:	66 0f 28 f4          	movapd %xmm4,%xmm6
  4625c0:	f2 0f c2 f1 06       	cmpnlesd %xmm1,%xmm6
  4625c5:	66 0f 54 f7          	andpd  %xmm7,%xmm6
  4625c9:	f2 0f 5c e6          	subsd  %xmm6,%xmm4
  4625cd:	66 0f 56 e5          	orpd   %xmm5,%xmm4
  4625d1:	66 0f 28 cc          	movapd %xmm4,%xmm1
  4625d5:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  4625d9:	f3 0f 5e 0d 2b 4a 04 	divss  0x44a2b(%rip),%xmm1        # 4a700c <_IO_stdin_used+0xc>
  4625e0:	00 
  4625e1:	e9 88 fa ff ff       	jmp    46206e <skia::textlayout::ParagraphImpl::layout(float)+0x46e>
  4625e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  4625ed:	00 00 00 
  4625f0:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  4625f7:	e8 a4 2d c0 ff       	call   653a0 <sk_free(void*)>
  4625fc:	e9 f5 fb ff ff       	jmp    4621f6 <skia::textlayout::ParagraphImpl::layout(float)+0x5f6>
  462601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  462608:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  46260f:	e8 8c 2d c0 ff       	call   653a0 <sk_free(void*)>
  462614:	e9 8a fb ff ff       	jmp    4621a3 <skia::textlayout::ParagraphImpl::layout(float)+0x5a3>
  462619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  462620:	48 8b 8d 08 04 00 00 	mov    0x408(%rbp),%rcx
  462627:	48 83 b9 98 00 00 00 	cmpq   $0x0,0x98(%rcx)
  46262e:	00 
  46262f:	0f 84 c3 07 00 00    	je     462df8 <skia::textlayout::ParagraphImpl::layout(float)+0x11f8>
  462635:	66 41 0f 6e ef       	movd   %r15d,%xmm5
  46263a:	0f 2e ad 68 04 00 00 	ucomiss 0x468(%rbp),%xmm5
  462641:	0f 8b 94 f8 ff ff    	jnp    461edb <skia::textlayout::ParagraphImpl::layout(float)+0x2db>
  462647:	e9 95 f8 ff ff       	jmp    461ee1 <skia::textlayout::ParagraphImpl::layout(float)+0x2e1>
  46264c:	0f 1f 40 00          	nopl   0x0(%rax)
  462650:	f2 0f 10 05 c8 19 05 	movsd  0x519c8(%rip),%xmm0        # 4b4020 <C.117.2+0x30>
  462657:	00 
  462658:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  46265d:	89 de                	mov    %ebx,%esi
  46265f:	48 c7 44 24 20 08 00 	movq   $0x8,0x20(%rsp)
  462666:	00 00 
  462668:	48 c7 44 24 28 ff ff 	movq   $0x7fffffff,0x28(%rsp)
  46266f:	ff 7f 
  462671:	e8 7a 7a c0 ff       	call   6a0f0 <SkContainerAllocator::allocate(int, double)>
  462676:	49 89 d4             	mov    %rdx,%r12
  462679:	48 63 95 90 03 00 00 	movslq 0x390(%rbp),%rdx
  462680:	49 89 c6             	mov    %rax,%r14
  462683:	49 89 c5             	mov    %rax,%r13
  462686:	48 c1 e2 03          	shl    $0x3,%rdx
  46268a:	0f 85 54 07 00 00    	jne    462de4 <skia::textlayout::ParagraphImpl::layout(float)+0x11e4>
  462690:	f6 85 94 03 00 00 01 	testb  $0x1,0x394(%rbp)
  462697:	0f 85 36 07 00 00    	jne    462dd3 <skia::textlayout::ParagraphImpl::layout(float)+0x11d3>
  46269d:	4c 89 e0             	mov    %r12,%rax
  4626a0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
  4626a5:	4c 89 b5 88 03 00 00 	mov    %r14,0x388(%rbp)
  4626ac:	48 c1 e8 03          	shr    $0x3,%rax
  4626b0:	48 39 d0             	cmp    %rdx,%rax
  4626b3:	48 0f 47 c2          	cmova  %rdx,%rax
  4626b7:	8d 44 00 01          	lea    0x1(%rax,%rax,1),%eax
  4626bb:	89 85 94 03 00 00    	mov    %eax,0x394(%rbp)
  4626c1:	48 63 85 90 03 00 00 	movslq 0x390(%rbp),%rax
  4626c8:	48 89 c2             	mov    %rax,%rdx
  4626cb:	01 da                	add    %ebx,%edx
  4626cd:	89 95 90 03 00 00    	mov    %edx,0x390(%rbp)
  4626d3:	e9 8f f7 ff ff       	jmp    461e67 <skia::textlayout::ParagraphImpl::layout(float)+0x267>
  4626d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  4626df:	00 
  4626e0:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  4626e4:	f2 0f 59 05 7c 1c 05 	mulsd  0x51c7c(%rip),%xmm0        # 4b4368 <C.117.2+0x378>
  4626eb:	00 
  4626ec:	f2 0f 10 15 24 19 05 	movsd  0x51924(%rip),%xmm2        # 4b4018 <C.117.2+0x28>
  4626f3:	00 
  4626f4:	f2 0f 58 05 0c 19 05 	addsd  0x5190c(%rip),%xmm0        # 4b4008 <C.117.2+0x18>
  4626fb:	00 
  4626fc:	f2 0f 10 1d 0c 19 05 	movsd  0x5190c(%rip),%xmm3        # 4b4010 <C.117.2+0x20>
  462703:	00 
  462704:	66 0f 28 c8          	movapd %xmm0,%xmm1
  462708:	66 0f 54 ca          	andpd  %xmm2,%xmm1
  46270c:	66 0f 2e d9          	ucomisd %xmm1,%xmm3
  462710:	76 33                	jbe    462745 <skia::textlayout::ParagraphImpl::layout(float)+0xb45>
  462712:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
  462717:	66 0f ef c9          	pxor   %xmm1,%xmm1
  46271b:	f2 0f 10 25 dd 18 05 	movsd  0x518dd(%rip),%xmm4        # 4b4000 <C.117.2+0x10>
  462722:	00 
  462723:	66 0f 55 d0          	andnpd %xmm0,%xmm2
  462727:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
  46272c:	66 0f 28 d9          	movapd %xmm1,%xmm3
  462730:	f2 0f c2 d8 06       	cmpnlesd %xmm0,%xmm3
  462735:	66 0f 54 dc          	andpd  %xmm4,%xmm3
  462739:	f2 0f 5c cb          	subsd  %xmm3,%xmm1
  46273d:	66 0f 56 ca          	orpd   %xmm2,%xmm1
  462741:	66 0f 28 c1          	movapd %xmm1,%xmm0
  462745:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  462749:	f3 0f 5e 05 3b 4d 04 	divss  0x44d3b(%rip),%xmm0        # 4a748c <_IO_stdin_used+0x48c>
  462750:	00 
  462751:	e9 57 f9 ff ff       	jmp    4620ad <skia::textlayout::ParagraphImpl::layout(float)+0x4ad>
  462756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  46275d:	00 00 00 
  462760:	f3 0f 5a c9          	cvtss2sd %xmm1,%xmm1
  462764:	f2 0f 59 0d fc 1b 05 	mulsd  0x51bfc(%rip),%xmm1        # 4b4368 <C.117.2+0x378>
  46276b:	00 
  46276c:	f2 0f 10 2d a4 18 05 	movsd  0x518a4(%rip),%xmm5        # 4b4018 <C.117.2+0x28>
  462773:	00 
  462774:	f2 0f 58 0d 8c 18 05 	addsd  0x5188c(%rip),%xmm1        # 4b4008 <C.117.2+0x18>
  46277b:	00 
  46277c:	f2 0f 10 35 8c 18 05 	movsd  0x5188c(%rip),%xmm6        # 4b4010 <C.117.2+0x20>
  462783:	00 
  462784:	66 0f 28 e1          	movapd %xmm1,%xmm4
  462788:	66 0f 54 e5          	andpd  %xmm5,%xmm4
  46278c:	66 0f 2e f4          	ucomisd %xmm4,%xmm6
  462790:	76 33                	jbe    4627c5 <skia::textlayout::ParagraphImpl::layout(float)+0xbc5>
  462792:	f2 48 0f 2c c1       	cvttsd2si %xmm1,%rax
  462797:	66 0f ef e4          	pxor   %xmm4,%xmm4
  46279b:	f2 0f 10 3d 5d 18 05 	movsd  0x5185d(%rip),%xmm7        # 4b4000 <C.117.2+0x10>
  4627a2:	00 
  4627a3:	66 0f 55 e9          	andnpd %xmm1,%xmm5
  4627a7:	f2 48 0f 2a e0       	cvtsi2sd %rax,%xmm4
  4627ac:	66 0f 28 f4          	movapd %xmm4,%xmm6
  4627b0:	f2 0f c2 f1 06       	cmpnlesd %xmm1,%xmm6
  4627b5:	66 0f 54 f7          	andpd  %xmm7,%xmm6
  4627b9:	f2 0f 5c e6          	subsd  %xmm6,%xmm4
  4627bd:	66 0f 56 e5          	orpd   %xmm5,%xmm4
  4627c1:	66 0f 28 cc          	movapd %xmm4,%xmm1
  4627c5:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  4627c9:	f3 0f 5e 0d bb 4c 04 	divss  0x44cbb(%rip),%xmm1        # 4a748c <_IO_stdin_used+0x48c>
  4627d0:	00 
  4627d1:	e9 98 f8 ff ff       	jmp    46206e <skia::textlayout::ParagraphImpl::layout(float)+0x46e>
  4627d6:	48 8b 45 08          	mov    0x8(%rbp),%rax
  4627da:	48 89 ee             	mov    %rbp,%rsi
  4627dd:	48 8d 78 68          	lea    0x68(%rax),%rdi
  4627e1:	e8 6a 88 fe ff       	call   44b050 <skia::textlayout::ParagraphCache::findParagraph(skia::textlayout::ParagraphImpl*)>
  4627e6:	84 c0                	test   %al,%al
  4627e8:	0f 85 b2 f6 ff ff    	jne    461ea0 <skia::textlayout::ParagraphImpl::layout(float)+0x2a0>
  4627ee:	8b 95 50 03 00 00    	mov    0x350(%rbp),%edx
  4627f4:	85 d2                	test   %edx,%edx
  4627f6:	7f 1e                	jg     462816 <skia::textlayout::ParagraphImpl::layout(float)+0xc16>
  4627f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  4627ff:	00 
  462800:	48 89 ef             	mov    %rbp,%rdi
  462803:	e8 98 8d ff ff       	call   45b5a0 <skia::textlayout::ParagraphImpl::computeCodeUnitProperties()>
  462808:	84 c0                	test   %al,%al
  46280a:	74 0a                	je     462816 <skia::textlayout::ParagraphImpl::layout(float)+0xc16>
  46280c:	c7 85 50 03 00 00 01 	movl   $0x1,0x350(%rbp)
  462813:	00 00 00 
  462816:	48 8b 85 80 02 00 00 	mov    0x280(%rbp),%rax
  46281d:	48 39 85 78 02 00 00 	cmp    %rax,0x278(%rbp)
  462824:	0f 84 42 f5 ff ff    	je     461d6c <skia::textlayout::ParagraphImpl::layout(float)+0x16c>
  46282a:	e9 8b f4 ff ff       	jmp    461cba <skia::textlayout::ParagraphImpl::layout(float)+0xba>
  46282f:	90                   	nop
  462830:	e8 6b 2b c0 ff       	call   653a0 <sk_free(void*)>
  462835:	e9 cf f9 ff ff       	jmp    462209 <skia::textlayout::ParagraphImpl::layout(float)+0x609>
  46283a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  462840:	e8 5b 2b c0 ff       	call   653a0 <sk_free(void*)>
  462845:	e9 6c f9 ff ff       	jmp    4621b6 <skia::textlayout::ParagraphImpl::layout(float)+0x5b6>
  46284a:	c6 85 5c 02 00 00 00 	movb   $0x0,0x25c(%rbp)
  462851:	66 0f ef c0          	pxor   %xmm0,%xmm0
  462855:	48 89 ef             	mov    %rbp,%rdi
  462858:	48 c7 85 50 02 00 00 	movq   $0x0,0x250(%rbp)
  46285f:	00 00 00 00 
  462863:	c7 85 58 02 00 00 00 	movl   $0x0,0x258(%rbp)
  46286a:	00 00 00 
  46286d:	c7 85 70 04 00 00 00 	movl   $0x0,0x470(%rbp)
  462874:	00 00 00 
  462877:	0f 11 85 40 02 00 00 	movups %xmm0,0x240(%rbp)
  46287e:	e8 4d a9 ff ff       	call   45d1d0 <skia::textlayout::ParagraphImpl::resolveStrut()>
  462883:	48 89 ef             	mov    %rbp,%rdi
  462886:	e8 25 c5 ff ff       	call   45edb0 <skia::textlayout::ParagraphImpl::computeEmptyMetrics()>
  46288b:	48 63 85 10 04 00 00 	movslq 0x410(%rbp),%rax
  462892:	85 c0                	test   %eax,%eax
  462894:	0f 84 11 02 00 00    	je     462aab <skia::textlayout::ParagraphImpl::layout(float)+0xeab>
  46289a:	4c 8b a5 08 04 00 00 	mov    0x408(%rbp),%r12
  4628a1:	48 c1 e0 08          	shl    $0x8,%rax
  4628a5:	4c 01 e0             	add    %r12,%rax
  4628a8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  4628ad:	0f 1f 00             	nopl   (%rax)
  4628b0:	4d 8b b4 24 f0 00 00 	mov    0xf0(%r12),%r14
  4628b7:	00 
  4628b8:	49 8b 9c 24 e8 00 00 	mov    0xe8(%r12),%rbx
  4628bf:	00 
  4628c0:	49 39 de             	cmp    %rbx,%r14
  4628c3:	75 2b                	jne    4628f0 <skia::textlayout::ParagraphImpl::layout(float)+0xcf0>
  4628c5:	eb 51                	jmp    462918 <skia::textlayout::ParagraphImpl::layout(float)+0xd18>
  4628c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  4628ce:	00 00 
  4628d0:	4c 8b 2b             	mov    (%rbx),%r13
  4628d3:	4d 85 ed             	test   %r13,%r13
  4628d6:	74 0c                	je     4628e4 <skia::textlayout::ParagraphImpl::layout(float)+0xce4>
  4628d8:	f0 41 83 6d 00 01    	lock subl $0x1,0x0(%r13)
  4628de:	0f 84 54 03 00 00    	je     462c38 <skia::textlayout::ParagraphImpl::layout(float)+0x1038>
  4628e4:	48 81 c3 a0 00 00 00 	add    $0xa0,%rbx
  4628eb:	49 39 de             	cmp    %rbx,%r14
  4628ee:	74 20                	je     462910 <skia::textlayout::ParagraphImpl::layout(float)+0xd10>
  4628f0:	0f b6 43 60          	movzbl 0x60(%rbx),%eax
  4628f4:	3c ff                	cmp    $0xff,%al
  4628f6:	74 d8                	je     4628d0 <skia::textlayout::ParagraphImpl::layout(float)+0xcd0>
  4628f8:	84 c0                	test   %al,%al
  4628fa:	75 d4                	jne    4628d0 <skia::textlayout::ParagraphImpl::layout(float)+0xcd0>
  4628fc:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  462900:	e8 1b ae bf ff       	call   5d720 <SkPaint::~SkPaint()>
  462905:	eb c9                	jmp    4628d0 <skia::textlayout::ParagraphImpl::layout(float)+0xcd0>
  462907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  46290e:	00 00 
  462910:	49 8b 9c 24 e8 00 00 	mov    0xe8(%r12),%rbx
  462917:	00 
  462918:	48 85 db             	test   %rbx,%rbx
  46291b:	74 13                	je     462930 <skia::textlayout::ParagraphImpl::layout(float)+0xd30>
  46291d:	49 8b b4 24 f8 00 00 	mov    0xf8(%r12),%rsi
  462924:	00 
  462925:	48 89 df             	mov    %rbx,%rdi
  462928:	48 29 de             	sub    %rbx,%rsi
  46292b:	e8 70 b8 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  462930:	49 8b 9c 24 a0 00 00 	mov    0xa0(%r12),%rbx
  462937:	00 
  462938:	48 85 db             	test   %rbx,%rbx
  46293b:	0f 84 9c 00 00 00    	je     4629dd <skia::textlayout::ParagraphImpl::layout(float)+0xddd>
  462941:	48 8d bb f0 00 00 00 	lea    0xf0(%rbx),%rdi
  462948:	e8 43 d5 bf ff       	call   5fe90 <SkString::~SkString()>
  46294d:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  462954:	0f 85 b8 03 00 00    	jne    462d12 <skia::textlayout::ParagraphImpl::layout(float)+0x1112>
  46295a:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
  46295e:	48 85 ff             	test   %rdi,%rdi
  462961:	74 0a                	je     46296d <skia::textlayout::ParagraphImpl::layout(float)+0xd6d>
  462963:	f0 83 2f 01          	lock subl $0x1,(%rdi)
  462967:	0f 84 ce 04 00 00    	je     462e3b <skia::textlayout::ParagraphImpl::layout(float)+0x123b>
  46296d:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
  462971:	48 85 ff             	test   %rdi,%rdi
  462974:	74 5a                	je     4629d0 <skia::textlayout::ParagraphImpl::layout(float)+0xdd0>
  462976:	f0 83 6f 08 01       	lock subl $0x1,0x8(%rdi)
  46297b:	75 53                	jne    4629d0 <skia::textlayout::ParagraphImpl::layout(float)+0xdd0>
  46297d:	48 8b 17             	mov    (%rdi),%rdx
  462980:	48 8d 0d b9 3c be ff 	lea    -0x41c347(%rip),%rcx        # 46640 <SkWeakRefCnt::internal_dispose() const>
  462987:	48 8b 42 10          	mov    0x10(%rdx),%rax
  46298b:	48 39 c8             	cmp    %rcx,%rax
  46298e:	0f 84 fe 02 00 00    	je     462c92 <skia::textlayout::ParagraphImpl::layout(float)+0x1092>
  462994:	48 8d 0d 15 3d be ff 	lea    -0x41c2eb(%rip),%rcx        # 466b0 <SkRefCntBase::internal_dispose() const>
  46299b:	48 39 c8             	cmp    %rcx,%rax
  46299e:	0f 85 a8 04 00 00    	jne    462e4c <skia::textlayout::ParagraphImpl::layout(float)+0x124c>
  4629a4:	48 8b 42 08          	mov    0x8(%rdx),%rax
  4629a8:	48 8d 15 a1 39 be ff 	lea    -0x41c65f(%rip),%rdx        # 46350 <SkRefCntBase::~SkRefCntBase()>
  4629af:	48 39 d0             	cmp    %rdx,%rax
  4629b2:	0f 84 10 03 00 00    	je     462cc8 <skia::textlayout::ParagraphImpl::layout(float)+0x10c8>
  4629b8:	48 8d 15 81 39 be ff 	lea    -0x41c67f(%rip),%rdx        # 46340 <SkWeakRefCnt::~SkWeakRefCnt()>
  4629bf:	48 39 d0             	cmp    %rdx,%rax
  4629c2:	0f 84 00 03 00 00    	je     462cc8 <skia::textlayout::ParagraphImpl::layout(float)+0x10c8>
  4629c8:	ff d0                	call   *%rax
  4629ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  4629d0:	be f8 00 00 00       	mov    $0xf8,%esi
  4629d5:	48 89 df             	mov    %rbx,%rdi
  4629d8:	e8 c3 b7 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  4629dd:	49 8b 9c 24 98 00 00 	mov    0x98(%r12),%rbx
  4629e4:	00 
  4629e5:	48 85 db             	test   %rbx,%rbx
  4629e8:	0f 84 9f 00 00 00    	je     462a8d <skia::textlayout::ParagraphImpl::layout(float)+0xe8d>
  4629ee:	48 8d bb f0 00 00 00 	lea    0xf0(%rbx),%rdi
  4629f5:	e8 96 d4 bf ff       	call   5fe90 <SkString::~SkString()>
  4629fa:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  462a01:	0f 85 fa 02 00 00    	jne    462d01 <skia::textlayout::ParagraphImpl::layout(float)+0x1101>
  462a07:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
  462a0b:	48 85 ff             	test   %rdi,%rdi
  462a0e:	74 0a                	je     462a1a <skia::textlayout::ParagraphImpl::layout(float)+0xe1a>
  462a10:	f0 83 2f 01          	lock subl $0x1,(%rdi)
  462a14:	0f 84 17 04 00 00    	je     462e31 <skia::textlayout::ParagraphImpl::layout(float)+0x1231>
  462a1a:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
  462a1e:	48 85 ff             	test   %rdi,%rdi
  462a21:	74 5d                	je     462a80 <skia::textlayout::ParagraphImpl::layout(float)+0xe80>
  462a23:	f0 83 6f 08 01       	lock subl $0x1,0x8(%rdi)
  462a28:	75 56                	jne    462a80 <skia::textlayout::ParagraphImpl::layout(float)+0xe80>
  462a2a:	48 8b 17             	mov    (%rdi),%rdx
  462a2d:	48 8d 0d 0c 3c be ff 	lea    -0x41c3f4(%rip),%rcx        # 46640 <SkWeakRefCnt::internal_dispose() const>
  462a34:	48 8b 42 10          	mov    0x10(%rdx),%rax
  462a38:	48 39 c8             	cmp    %rcx,%rax
  462a3b:	0f 84 0c 02 00 00    	je     462c4d <skia::textlayout::ParagraphImpl::layout(float)+0x104d>
  462a41:	48 8d 0d 68 3c be ff 	lea    -0x41c398(%rip),%rcx        # 466b0 <SkRefCntBase::internal_dispose() const>
  462a48:	48 39 c8             	cmp    %rcx,%rax
  462a4b:	0f 85 f4 03 00 00    	jne    462e45 <skia::textlayout::ParagraphImpl::layout(float)+0x1245>
  462a51:	48 8b 42 08          	mov    0x8(%rdx),%rax
  462a55:	48 8d 15 f4 38 be ff 	lea    -0x41c70c(%rip),%rdx        # 46350 <SkRefCntBase::~SkRefCntBase()>
  462a5c:	48 39 d0             	cmp    %rdx,%rax
  462a5f:	0f 84 1e 02 00 00    	je     462c83 <skia::textlayout::ParagraphImpl::layout(float)+0x1083>
  462a65:	48 8d 15 d4 38 be ff 	lea    -0x41c72c(%rip),%rdx        # 46340 <SkWeakRefCnt::~SkWeakRefCnt()>
  462a6c:	48 39 d0             	cmp    %rdx,%rax
  462a6f:	0f 84 0e 02 00 00    	je     462c83 <skia::textlayout::ParagraphImpl::layout(float)+0x1083>
  462a75:	ff d0                	call   *%rax
  462a77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  462a7e:	00 00 
  462a80:	be f8 00 00 00       	mov    $0xf8,%esi
  462a85:	48 89 df             	mov    %rbx,%rdi
  462a88:	e8 13 b7 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  462a8d:	41 f6 44 24 7c 01    	testb  $0x1,0x7c(%r12)
  462a93:	0f 85 47 02 00 00    	jne    462ce0 <skia::textlayout::ParagraphImpl::layout(float)+0x10e0>
  462a99:	49 81 c4 00 01 00 00 	add    $0x100,%r12
  462aa0:	4c 3b 64 24 08       	cmp    0x8(%rsp),%r12
  462aa5:	0f 82 05 fe ff ff    	jb     4628b0 <skia::textlayout::ParagraphImpl::layout(float)+0xcb0>
  462aab:	f3 0f 10 9d 30 04 00 	movss  0x430(%rbp),%xmm3
  462ab2:	00 
  462ab3:	f3 0f 10 95 34 04 00 	movss  0x434(%rbp),%xmm2
  462aba:	00 
  462abb:	66 0f ef c0          	pxor   %xmm0,%xmm0
  462abf:	66 0f ef e4          	pxor   %xmm4,%xmm4
  462ac3:	f3 0f 10 8d 38 04 00 	movss  0x438(%rbp),%xmm1
  462aca:	00 
  462acb:	c7 85 10 04 00 00 00 	movl   $0x0,0x410(%rbp)
  462ad2:	00 00 00 
  462ad5:	f3 0f 5a e3          	cvtss2sd %xmm3,%xmm4
  462ad9:	f3 0f 5a c2          	cvtss2sd %xmm2,%xmm0
  462add:	f2 0f 5c c4          	subsd  %xmm4,%xmm0
  462ae1:	66 0f ef e4          	pxor   %xmm4,%xmm4
  462ae5:	f3 0f 5a e1          	cvtss2sd %xmm1,%xmm4
  462ae9:	0f 28 fb             	movaps %xmm3,%xmm7
  462aec:	f3 0f 11 54 24 1c    	movss  %xmm2,0x1c(%rsp)
  462af2:	0f 14 f9             	unpcklps %xmm1,%xmm7
  462af5:	f3 0f 11 5c 24 18    	movss  %xmm3,0x18(%rsp)
  462afb:	f2 0f 58 c4          	addsd  %xmm4,%xmm0
  462aff:	0f 13 7c 24 08       	movlps %xmm7,0x8(%rsp)
  462b04:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
  462b0a:	e8 81 c2 bc ff       	call   2ed90 <round@plt>
  462b0f:	66 41 0f 6e ff       	movd   %r15d,%xmm7
  462b14:	80 7d 39 00          	cmpb   $0x0,0x39(%rbp)
  462b18:	f3 0f 10 4c 24 10    	movss  0x10(%rsp),%xmm1
  462b1e:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  462b22:	0f 28 e0             	movaps %xmm0,%xmm4
  462b25:	f3 0f 10 5c 24 18    	movss  0x18(%rsp),%xmm3
  462b2b:	f3 0f 10 54 24 1c    	movss  0x1c(%rsp),%xmm2
  462b31:	0f 14 e7             	unpcklps %xmm7,%xmm4
  462b34:	0f 13 a5 48 02 00 00 	movlps %xmm4,0x248(%rbp)
  462b3b:	74 61                	je     462b9e <skia::textlayout::ParagraphImpl::layout(float)+0xf9e>
  462b3d:	80 7d 38 00          	cmpb   $0x0,0x38(%rbp)
  462b41:	74 5b                	je     462b9e <skia::textlayout::ParagraphImpl::layout(float)+0xf9e>
  462b43:	66 0f ef c0          	pxor   %xmm0,%xmm0
  462b47:	66 0f ef e4          	pxor   %xmm4,%xmm4
  462b4b:	f3 0f 11 4c 24 1c    	movss  %xmm1,0x1c(%rsp)
  462b51:	f3 0f 5a a5 4c 04 00 	cvtss2sd 0x44c(%rbp),%xmm4
  462b58:	00 
  462b59:	f3 0f 5a 85 50 04 00 	cvtss2sd 0x450(%rbp),%xmm0
  462b60:	00 
  462b61:	f2 0f 5c c4          	subsd  %xmm4,%xmm0
  462b65:	66 0f ef e4          	pxor   %xmm4,%xmm4
  462b69:	f3 0f 5a a5 54 04 00 	cvtss2sd 0x454(%rbp),%xmm4
  462b70:	00 
  462b71:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
  462b77:	f2 0f 58 c4          	addsd  %xmm4,%xmm0
  462b7b:	e8 10 c2 bc ff       	call   2ed90 <round@plt>
  462b80:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  462b86:	f3 0f 10 5c 24 18    	movss  0x18(%rsp),%xmm3
  462b8c:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  462b92:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  462b96:	f3 0f 11 85 48 02 00 	movss  %xmm0,0x248(%rbp)
  462b9d:	00 
  462b9e:	f3 0f 5c d3          	subss  %xmm3,%xmm2
  462ba2:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
  462ba7:	f3 0f 59 0d 55 44 04 	mulss  0x44455(%rip),%xmm1        # 4a7004 <_IO_stdin_used+0x4>
  462bae:	00 
  462baf:	c7 85 58 02 00 00 ff 	movl   $0xff7fffff,0x258(%rbp)
  462bb6:	ff 7f ff 
  462bb9:	48 c7 85 50 02 00 00 	movq   $0x0,0x250(%rbp)
  462bc0:	00 00 00 00 
  462bc4:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
  462bc9:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  462bce:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
  462bd3:	0f 14 ca             	unpcklps %xmm2,%xmm1
  462bd6:	f3 0f 7e 54 24 08    	movq   0x8(%rsp),%xmm2
  462bdc:	f3 0f 7e c9          	movq   %xmm1,%xmm1
  462be0:	0f 28 d9             	movaps %xmm1,%xmm3
  462be3:	0f 5c da             	subps  %xmm2,%xmm3
  462be6:	0f 58 d1             	addps  %xmm1,%xmm2
  462be9:	66 41 0f 6e cf       	movd   %r15d,%xmm1
  462bee:	0f 14 c8             	unpcklps %xmm0,%xmm1
  462bf1:	0f 13 8d 68 04 00 00 	movlps %xmm1,0x468(%rbp)
  462bf8:	f3 0f 10 d3          	movss  %xmm3,%xmm2
  462bfc:	0f 13 95 40 02 00 00 	movlps %xmm2,0x240(%rbp)
  462c03:	e9 d9 f4 ff ff       	jmp    4620e1 <skia::textlayout::ParagraphImpl::layout(float)+0x4e1>
  462c08:	83 f8 02             	cmp    $0x2,%eax
  462c0b:	0f 85 e4 f3 ff ff    	jne    461ff5 <skia::textlayout::ParagraphImpl::layout(float)+0x3f5>
  462c11:	e9 d5 f2 ff ff       	jmp    461eeb <skia::textlayout::ParagraphImpl::layout(float)+0x2eb>
  462c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  462c1d:	00 00 00 
  462c20:	48 8b 45 08          	mov    0x8(%rbp),%rax
  462c24:	48 89 ee             	mov    %rbp,%rsi
  462c27:	48 8d 78 68          	lea    0x68(%rax),%rdi
  462c2b:	e8 20 e9 fe ff       	call   451550 <skia::textlayout::ParagraphCache::updateParagraph(skia::textlayout::ParagraphImpl*)>
  462c30:	e9 6b f2 ff ff       	jmp    461ea0 <skia::textlayout::ParagraphImpl::layout(float)+0x2a0>
  462c35:	0f 1f 00             	nopl   (%rax)
  462c38:	4c 89 ef             	mov    %r13,%rdi
  462c3b:	e8 00 62 ed ff       	call   338e40 <SkTextBlob::~SkTextBlob()>
  462c40:	4c 89 ef             	mov    %r13,%rdi
  462c43:	e8 c8 63 ed ff       	call   339010 <SkTextBlob::operator delete(void*)>
  462c48:	e9 97 fc ff ff       	jmp    4628e4 <skia::textlayout::ParagraphImpl::layout(float)+0xce4>
  462c4d:	48 8b 42 18          	mov    0x18(%rdx),%rax
  462c51:	48 8d 15 98 36 be ff 	lea    -0x41c968(%rip),%rdx        # 462f0 <SkWeakRefCnt::weak_dispose() const>
  462c58:	48 39 d0             	cmp    %rdx,%rax
  462c5b:	0f 85 03 02 00 00    	jne    462e64 <skia::textlayout::ParagraphImpl::layout(float)+0x1264>
  462c61:	f0 83 6f 0c 01       	lock subl $0x1,0xc(%rdi)
  462c66:	0f 85 14 fe ff ff    	jne    462a80 <skia::textlayout::ParagraphImpl::layout(float)+0xe80>
  462c6c:	48 8b 07             	mov    (%rdi),%rax
  462c6f:	48 8d 15 ca 36 be ff 	lea    -0x41c936(%rip),%rdx        # 46340 <SkWeakRefCnt::~SkWeakRefCnt()>
  462c76:	48 8b 40 08          	mov    0x8(%rax),%rax
  462c7a:	48 39 d0             	cmp    %rdx,%rax
  462c7d:	0f 85 f2 fd ff ff    	jne    462a75 <skia::textlayout::ParagraphImpl::layout(float)+0xe75>
  462c83:	be 10 00 00 00       	mov    $0x10,%esi
  462c88:	e8 13 b5 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  462c8d:	e9 ee fd ff ff       	jmp    462a80 <skia::textlayout::ParagraphImpl::layout(float)+0xe80>
  462c92:	48 8b 42 18          	mov    0x18(%rdx),%rax
  462c96:	48 8d 15 53 36 be ff 	lea    -0x41c9ad(%rip),%rdx        # 462f0 <SkWeakRefCnt::weak_dispose() const>
  462c9d:	48 39 d0             	cmp    %rdx,%rax
  462ca0:	0f 85 ad 01 00 00    	jne    462e53 <skia::textlayout::ParagraphImpl::layout(float)+0x1253>
  462ca6:	f0 83 6f 0c 01       	lock subl $0x1,0xc(%rdi)
  462cab:	0f 85 1f fd ff ff    	jne    4629d0 <skia::textlayout::ParagraphImpl::layout(float)+0xdd0>
  462cb1:	48 8b 07             	mov    (%rdi),%rax
  462cb4:	48 8d 15 85 36 be ff 	lea    -0x41c97b(%rip),%rdx        # 46340 <SkWeakRefCnt::~SkWeakRefCnt()>
  462cbb:	48 8b 40 08          	mov    0x8(%rax),%rax
  462cbf:	48 39 d0             	cmp    %rdx,%rax
  462cc2:	0f 85 00 fd ff ff    	jne    4629c8 <skia::textlayout::ParagraphImpl::layout(float)+0xdc8>
  462cc8:	be 10 00 00 00       	mov    $0x10,%esi
  462ccd:	e8 ce b4 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  462cd2:	e9 f9 fc ff ff       	jmp    4629d0 <skia::textlayout::ParagraphImpl::layout(float)+0xdd0>
  462cd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  462cde:	00 00 
  462ce0:	49 8b 7c 24 70       	mov    0x70(%r12),%rdi
  462ce5:	49 81 c4 00 01 00 00 	add    $0x100,%r12
  462cec:	e8 af 26 c0 ff       	call   653a0 <sk_free(void*)>
  462cf1:	4c 3b 64 24 08       	cmp    0x8(%rsp),%r12
  462cf6:	0f 82 b4 fb ff ff    	jb     4628b0 <skia::textlayout::ParagraphImpl::layout(float)+0xcb0>
  462cfc:	e9 aa fd ff ff       	jmp    462aab <skia::textlayout::ParagraphImpl::layout(float)+0xeab>
  462d01:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  462d08:	e8 93 26 c0 ff       	call   653a0 <sk_free(void*)>
  462d0d:	e9 f5 fc ff ff       	jmp    462a07 <skia::textlayout::ParagraphImpl::layout(float)+0xe07>
  462d12:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  462d19:	e8 82 26 c0 ff       	call   653a0 <sk_free(void*)>
  462d1e:	e9 37 fc ff ff       	jmp    46295a <skia::textlayout::ParagraphImpl::layout(float)+0xd5a>
  462d23:	4c 8b a5 60 02 00 00 	mov    0x260(%rbp),%r12
  462d2a:	4c 29 e0             	sub    %r12,%rax
  462d2d:	48 89 c2             	mov    %rax,%rdx
  462d30:	48 89 c3             	mov    %rax,%rbx
  462d33:	48 c1 fa 03          	sar    $0x3,%rdx
  462d37:	48 b8 ff ff ff ff ff 	movabs $0xfffffffffffffff,%rax
  462d3e:	ff ff 0f 
  462d41:	48 39 c2             	cmp    %rax,%rdx
  462d44:	0f 84 1c 4b bd ff    	je     37866 <skia::textlayout::ParagraphImpl::layout(float) [clone .cold]>
  462d4a:	48 85 d2             	test   %rdx,%rdx
  462d4d:	b8 01 00 00 00       	mov    $0x1,%eax
  462d52:	48 0f 45 c2          	cmovne %rdx,%rax
  462d56:	48 01 d0             	add    %rdx,%rax
  462d59:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffffff,%rdx
  462d60:	ff ff 0f 
  462d63:	48 39 d0             	cmp    %rdx,%rax
  462d66:	48 0f 47 c2          	cmova  %rdx,%rax
  462d6a:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
  462d71:	00 
  462d72:	4c 89 f7             	mov    %r14,%rdi
  462d75:	e8 b6 b4 bc ff       	call   2e230 <operator new(unsigned long)@plt>
  462d7a:	4c 89 2c 18          	mov    %r13,(%rax,%rbx,1)
  462d7e:	48 89 c1             	mov    %rax,%rcx
  462d81:	48 85 db             	test   %rbx,%rbx
  462d84:	74 11                	je     462d97 <skia::textlayout::ParagraphImpl::layout(float)+0x1197>
  462d86:	48 89 da             	mov    %rbx,%rdx
  462d89:	4c 89 e6             	mov    %r12,%rsi
  462d8c:	48 89 c7             	mov    %rax,%rdi
  462d8f:	e8 6c b3 bc ff       	call   2e100 <memcpy@plt>
  462d94:	48 89 c1             	mov    %rax,%rcx
  462d97:	4c 8d 6c 19 08       	lea    0x8(%rcx,%rbx,1),%r13
  462d9c:	4d 85 e4             	test   %r12,%r12
  462d9f:	74 15                	je     462db6 <skia::textlayout::ParagraphImpl::layout(float)+0x11b6>
  462da1:	48 89 de             	mov    %rbx,%rsi
  462da4:	4c 89 e7             	mov    %r12,%rdi
  462da7:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  462dac:	e8 ef b3 bc ff       	call   2e1a0 <operator delete(void*, unsigned long)@plt>
  462db1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  462db6:	48 89 8d 60 02 00 00 	mov    %rcx,0x260(%rbp)
  462dbd:	4c 01 f1             	add    %r14,%rcx
  462dc0:	4c 89 ad 68 02 00 00 	mov    %r13,0x268(%rbp)
  462dc7:	48 89 8d 70 02 00 00 	mov    %rcx,0x270(%rbp)
  462dce:	e9 99 ef ff ff       	jmp    461d6c <skia::textlayout::ParagraphImpl::layout(float)+0x16c>
  462dd3:	48 8b bd 88 03 00 00 	mov    0x388(%rbp),%rdi
  462dda:	e8 c1 25 c0 ff       	call   653a0 <sk_free(void*)>
  462ddf:	e9 b9 f8 ff ff       	jmp    46269d <skia::textlayout::ParagraphImpl::layout(float)+0xa9d>
  462de4:	48 8b b5 88 03 00 00 	mov    0x388(%rbp),%rsi
  462deb:	4c 89 f7             	mov    %r14,%rdi
  462dee:	e8 0d b3 bc ff       	call   2e100 <memcpy@plt>
  462df3:	e9 98 f8 ff ff       	jmp    462690 <skia::textlayout::ParagraphImpl::layout(float)+0xa90>
  462df8:	44 89 bd 4c 02 00 00 	mov    %r15d,0x24c(%rbp)
  462dff:	c7 85 50 03 00 00 02 	movl   $0x2,0x350(%rbp)
  462e06:	00 00 00 
  462e09:	e9 dd f0 ff ff       	jmp    461eeb <skia::textlayout::ParagraphImpl::layout(float)+0x2eb>
  462e0e:	48 8b 95 48 03 00 00 	mov    0x348(%rbp),%rdx
  462e15:	44 8b 2a             	mov    (%rdx),%r13d
  462e18:	48 3b 8d 70 02 00 00 	cmp    0x270(%rbp),%rcx
  462e1f:	0f 85 39 ef ff ff    	jne    461d5e <skia::textlayout::ParagraphImpl::layout(float)+0x15e>
  462e25:	49 89 cc             	mov    %rcx,%r12
  462e28:	31 db                	xor    %ebx,%ebx
  462e2a:	31 d2                	xor    %edx,%edx
  462e2c:	e9 06 ff ff ff       	jmp    462d37 <skia::textlayout::ParagraphImpl::layout(float)+0x1137>
  462e31:	e8 6a 25 c0 ff       	call   653a0 <sk_free(void*)>
  462e36:	e9 df fb ff ff       	jmp    462a1a <skia::textlayout::ParagraphImpl::layout(float)+0xe1a>
  462e3b:	e8 60 25 c0 ff       	call   653a0 <sk_free(void*)>
  462e40:	e9 28 fb ff ff       	jmp    46296d <skia::textlayout::ParagraphImpl::layout(float)+0xd6d>
  462e45:	ff d0                	call   *%rax
  462e47:	e9 34 fc ff ff       	jmp    462a80 <skia::textlayout::ParagraphImpl::layout(float)+0xe80>
  462e4c:	ff d0                	call   *%rax
  462e4e:	e9 7d fb ff ff       	jmp    4629d0 <skia::textlayout::ParagraphImpl::layout(float)+0xdd0>
  462e53:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  462e58:	ff d0                	call   *%rax
  462e5a:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  462e5f:	e9 42 fe ff ff       	jmp    462ca6 <skia::textlayout::ParagraphImpl::layout(float)+0x10a6>
  462e64:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  462e69:	ff d0                	call   *%rax
  462e6b:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  462e70:	e9 ec fd ff ff       	jmp    462c61 <skia::textlayout::ParagraphImpl::layout(float)+0x1061>
  462e75:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  462e7a:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  462e7f:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
  462e84:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  462e89:	e8 52 b5 bc ff       	call   2e3e0 <__stack_chk_fail@plt>
