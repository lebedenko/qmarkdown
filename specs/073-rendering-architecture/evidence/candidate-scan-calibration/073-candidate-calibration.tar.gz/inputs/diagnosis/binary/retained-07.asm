
/home/andrii/Projects/pet/qmarkdown/build-ci/073-candidate-continuation/retained-build/runtime-trace:     file format elf64-x86-64


Disassembly of section .text:

000000000045a9a0 <skia::textlayout::ParagraphImpl::experimentalPadded() const>:
  45a9a0:	48 8b 87 78 02 00 00 	mov    0x278(%rdi),%rax
  45a9a7:	48 8b 97 80 02 00 00 	mov    0x280(%rdi),%rdx
  45a9ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
  45a9b2:	48 39 c2             	cmp    %rax,%rdx
  45a9b5:	75 1a                	jne    45a9d1 <skia::textlayout::ParagraphImpl::experimentalPadded() const+0x31>
  45a9b7:	eb 27                	jmp    45a9e0 <skia::textlayout::ParagraphImpl::experimentalPadded() const+0x40>
  45a9b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  45a9c0:	0f 2e 40 1c          	ucomiss 0x1c(%rax),%xmm0
  45a9c4:	7a 13                	jp     45a9d9 <skia::textlayout::ParagraphImpl::experimentalPadded() const+0x39>
  45a9c6:	75 11                	jne    45a9d9 <skia::textlayout::ParagraphImpl::experimentalPadded() const+0x39>
  45a9c8:	48 83 c0 20          	add    $0x20,%rax
  45a9cc:	48 39 d0             	cmp    %rdx,%rax
  45a9cf:	74 0f                	je     45a9e0 <skia::textlayout::ParagraphImpl::experimentalPadded() const+0x40>
  45a9d1:	0f 2e 40 18          	ucomiss 0x18(%rax),%xmm0
  45a9d5:	7a 02                	jp     45a9d9 <skia::textlayout::ParagraphImpl::experimentalPadded() const+0x39>
  45a9d7:	74 e7                	je     45a9c0 <skia::textlayout::ParagraphImpl::experimentalPadded() const+0x20>
  45a9d9:	b8 01 00 00 00       	mov    $0x1,%eax
  45a9de:	c3                   	ret
  45a9df:	90                   	nop
  45a9e0:	31 c0                	xor    %eax,%eax
  45a9e2:	c3                   	ret
