from pathlib import Path
p=Path('specs/073-rendering-architecture/demonstrator/candidate-scan-implementation')
f=p/'run.py';s=f.read_text().replace('from prototype import apply','from implementation import apply, diagnostic, diff')
s=s.replace("('oracle','shadow','prototype')", "('oracle','shadow','prototype','clean')")
a=s.index("    source=ROOT/'build-ci/073-ownership-workspace-v2/headline'")
b=s.index('    for case in cases():',a)
s=s[:a]+'''    source=ROOT/'build-ci/073-ownership-workspace-v2/headline'
    for variant in ('clean','prototype'):
        stage=workspace/variant
        shutil.copytree(source,stage,symlinks=True)
        for f in stage.glob('modules/skparagraph/src/*'):
            if f.is_file():assert digest(f)==digest(source/f.relative_to(stage)),str(f)
        supervisor.append(output/'build-commands.jsonl',dict(action='copy verified ownership baseline',source=str(source),destination=str(stage)))
        apply(stage)
        clean_patch=diff(source/'modules/skparagraph/src',stage/'modules/skparagraph/src')
        assert clean_patch==(HERE/'candidate.patch').read_text()
        if variant=='clean':
            (output/'candidate.patch').write_text(clean_patch)
            for f in stage.glob('modules/skparagraph/src/*'):
                if f.is_file():
                    assert not any(token in f.read_text() for token in ('scanMode','scanWork','phaseWork','phaseCandidates','shadowChecks','cutoff-proof'))
        else:
            # Overlay is independently derived from the clean retained copy.
            for f in (source/'modules/skparagraph/src').iterdir():
                if f.is_file():shutil.copy2(f,stage/'modules/skparagraph/src'/f.name)
            diagnostic(stage)
            overlay=diff(workspace/'clean/modules/skparagraph/src',stage/'modules/skparagraph/src')
            assert overlay==(HERE/'diagnostic.patch').read_text()
            (output/'diagnostic.patch').write_text(overlay)
        command(['ninja','-C',stage/'out/comparison','-j2','skparagraph'],output,variant+'-skia-build.log')
        build=workspace/(variant+'-build')
        command(['cmake','-S',HERE,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSKIA='+str(stage),'-DCOUNTERS='+('OFF' if variant=='clean' else 'ON')],output,variant+'-configure.log')
        command(['cmake','--build',build,'-j2','--verbose'],output,variant+'-driver-build.log')
        shutil.copytree(stage/'modules/skparagraph/src',output/(variant+'-sources'))
''' + s[b:]
s=s.replace("    for exe,args in", "    build=workspace/'prototype-build'\n    for exe,args in")
s=s.replace("    shutil.copytree(stage/'modules/skparagraph/src',output/'sources')\n",'')
s=s.replace("    recovery.durable_json(output/'identities.json',identities)",'''    for variant in ('clean','prototype'):
        for f in [*(workspace/variant/'modules/skparagraph/src').glob('*'),
                  *(workspace/variant/'out/comparison').rglob('*.ninja'),
                  *(workspace/variant/'out/comparison').glob('*.a'),
                  *(workspace/(variant+'-build')).glob('*')]:
            if f.is_file():identities[str(f)]=digest(f)
    recovery.durable_json(output/'identities.json',identities)''')
s=s.replace("output/'candidate.patch'])", "output/'candidate.patch',output/'diagnostic.patch'])")
s=s.replace("        for w,g in zip(r['counters'],r['geometry']):", "        if entry['mode']=='clean':\n            assert all(w is None for w in r['counters'])\n            continue\n        for w,g in zip(r['counters'],r['geometry']):")
s=s.replace("assert s['preprocessing']==s['trimming']==s['scratchCapacity']==0", "assert s['preprocessing']==s['trimming']==s['scratchCapacity']==0\n                if entry['variant']=='zero':assert s['guardVisits']==0")
s=s.replace("            for w,o in zip(r['counters'],b['counters']):", "            if entry['mode']=='clean':continue\n            for w,o in zip(r['counters'],b['counters']):")
s=s.replace("cmd=[workspace/'prototype-build/phase-trace',fixture,e['variant'],e['mode']]", "cmd=[workspace/('clean-build' if e['mode']=='clean' else 'prototype-build')/'phase-trace',fixture,e['variant'],e['mode']]")
f.write_text(s)
f=p/'trace.cpp';s=f.read_text().replace('out["scan"]={{"preprocessing",s.preprocessing}', 'out["scan"]={{"guardVisits",s.guardVisits},{"preprocessing",s.preprocessing}')
s=s.replace('mode=="prototype","invalid scan mode"','mode=="prototype" || mode=="clean","invalid scan mode"')
s=s.replace('                impl->scanMode=mode=="oracle"?0:mode=="shadow"?1:2;', '#ifdef PHASE_COUNTERS\n                impl->scanMode=mode=="oracle"?0:mode=="shadow"?1:2;\n#endif')
f.write_text(s)
f=p/'CMakeLists.txt';s=f.read_text().replace('add_executable(ownership-tests ../ownership-experiment/tests.cpp)','if(COUNTERS)\nadd_executable(ownership-tests ../ownership-experiment/tests.cpp)').replace('add_executable(scan-tests tests.cpp)','add_executable(scan-tests tests.cpp)\nendif()').replace('foreach(target phase-trace perf-geometry ownership-tests scan-tests)','set(LINK_TARGETS phase-trace perf-geometry)\nif(COUNTERS)\nlist(APPEND LINK_TARGETS ownership-tests scan-tests)\nendif()\nforeach(target ${LINK_TARGETS})');f.write_text(s)
f=p/'test_harness.py';s=f.read_text().replace('72','96').replace("s[:3]","s[:4]").replace("['oracle','shadow','prototype']","['oracle','shadow','prototype','clean']").replace('scan=dict(evaluations','scan=dict(guardVisits=1,evaluations');f.write_text(s)
f=p/'report.py';s=f.read_text().replace('==72','==96').replace('processes=72,operationRecords=288','processes=96,operationRecords=384').replace("            scans=[w['scan'] for w in r['counters']]", "            if e['mode']=='clean':continue\n            scans=[w['scan'] for w in r['counters']]").replace("('preprocessing','trimming'", "('guardVisits','preprocessing','trimming'");f.write_text(s)
f=p/'archive.py';s=f.read_text().replace("for folder in (HERE,HERE.parent/", "for folder in (HERE,HERE.parent/'candidate-scan-experiment',HERE.parent/").replace("073-candidate-evidence-part-", "073-candidate-implementation-part-")
a=s.index("    for f in (workspace/'prototype/out/comparison').rglob")
b=s.index("    for folder in ('ownership-experiment'",a)
s=s[:a]+'''    for variant in ('clean','prototype'):
        for f in (workspace/variant/'out/comparison').rglob('*.ninja'):
            out=target/variant/f.relative_to(workspace/variant/'out/comparison');out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,out)
        for f in (workspace/variant/'out/comparison/args.gn',workspace/(variant+'-build')/'build.ninja',workspace/(variant+'-build')/'CMakeCache.txt'):
            out=target/variant/f.name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,out)
''' +s[b:];f.write_text(s)
