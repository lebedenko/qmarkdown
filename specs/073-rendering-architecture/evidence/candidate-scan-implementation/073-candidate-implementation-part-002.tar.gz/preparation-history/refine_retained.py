from pathlib import Path
p=Path('specs/073-rendering-architecture/demonstrator/candidate-scan-implementation')
f=p/'implementation.py';s=f.read_text();s=s.replace("    path.write_text(text)\n    path = src/'ParagraphImpl.h'", """    text = text.replace('            if (parent->scanMode && reason!=scan_bound::safe) ++parent->scanWork.fallback[reason];\\n', '')
    text = text.replace('                bare=0;', '                if (parent->scanMode && reason!=scan_bound::safe) ++parent->scanWork.fallback[reason];\\n                bare=0;')
    # Keep the padded-only preparation block readable in both artifacts.
    start = text.index('    SkScalar maxPad=0;')
    stop = text.index('    while (fEndLine.endCluster() != end)', start)
    block = text[start:stop]
    lines = block.splitlines(True)
    text = text[:start]+''.join('    '+line for line in lines[:-1])+lines[-1]+text[stop:]
    path.write_text(text)
    path = src/'ParagraphImpl.h'""")
# strip relocated diagnostic fallback line from clean
s=s.replace("    text = text.replace('parent->scanMode==2 && ', '')", "    text = text.replace('                if (reason!=scan_bound::safe) ++parent->scanWork.fallback[reason];\\n', '')\n    text = text.replace('parent->scanMode==2 && ', '')")
f.write_text(s)
f=p/'trace.cpp';s=f.read_text().replace('#include <chrono>\n','').replace('            double ms=0;\n','').replace('                auto start=std::chrono::steady_clock::now();\n','').replace('                ms+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();\n','').replace('{"diagnosticMs",ms},','');f.write_text(s)
f=p/'tests.cpp';s=f.read_text().replace('for(int reason:{2,4}) {','for(int scenario:{0,1,2,3,4,5,6}) {\n            int reason=scenario<4?2:scenario<6?4:5;')
s=s.replace('if(reason==4){auto spans=impl->experimentalSpans();spans[0].horizontalPadding=-1;impl->experimentalSetSpans(spans);}', '''if(scenario>=4){auto spans=impl->experimentalSpans();
                    spans[0].horizontalPadding=scenario==4?-1:scenario==5?INFINITY:std::numeric_limits<float>::max();
                    impl->experimentalSetSpans(spans);}''')
s=s.replace('int old=std::fegetround();if(reason==2)std::fesetround(FE_DOWNWARD);', '''int old=std::fegetround();auto csr=_mm_getcsr();
                if(scenario==0)std::fesetround(FE_DOWNWARD);
                if(scenario==1)_mm_setcsr(csr|(1u<<15));
                if(scenario==2)_mm_setcsr(csr|(1u<<6));
                if(scenario==3)_mm_setcsr((csr & ~(3u<<13))|(1u<<13));''')
s=s.replace('std::fesetround(old);','std::fesetround(old);_mm_setcsr(csr);')
s=s.replace('impl->scanWork.preprocessing==0 && impl->scanWork.scratchCapacity==0','impl->scanWork.guardVisits==0 && impl->scanWork.preprocessing==0 && impl->scanWork.scratchCapacity==0')
s=s.replace('cases+3','cases+8');f.write_text(s)
