import sys,tempfile,shutil
from pathlib import Path
sys.path.insert(0,'specs/073-rendering-architecture/demonstrator/candidate-scan-implementation')
import implementation as m
source=Path('build-ci/073-ownership-workspace-v2/headline/modules/skparagraph/src')
with tempfile.TemporaryDirectory() as t:
 root=Path(t);src=root/'modules/skparagraph/src';shutil.copytree(source,src)
 m.apply(root);(m.HERE/'candidate.patch').write_text(m.diff(source,src))
 clean=root/'clean';shutil.copytree(src,clean)
 for f in source.iterdir():
  if f.is_file():shutil.copy2(f,src/f.name)
 m.diagnostic(root);(m.HERE/'diagnostic.patch').write_text(m.diff(clean,src))
