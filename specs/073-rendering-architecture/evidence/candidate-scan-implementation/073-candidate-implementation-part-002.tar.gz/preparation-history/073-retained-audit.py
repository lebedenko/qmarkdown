import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'build-ci/073-candidate-implementation-evidence-v4';work=root/'build-ci/073-candidate-implementation-v4'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base=root/'build-ci/073-ownership-workspace-v2/headline/modules/skparagraph/src'
clean=work/'clean/modules/skparagraph/src'
changed=[]
for f in clean.iterdir():
 if not f.is_file():continue
 if not (base/f.name).exists() or digest(f)!=digest(base/f.name):changed.append(f.name)
 assert not any(x in f.read_text() for x in ('scanWork','scanMode','phaseWork','phaseCandidates','shadowChecks','cutoff-proof'))
assert sorted(changed)==['ScanBound.h','TextWrapper.cpp']
cmd=['nm','-C',str(work/'clean/out/comparison/libskparagraph.a')]
nm=subprocess.run(cmd,check=True,text=True,capture_output=True)
(out/'clean-symbols.txt').write_text(nm.stdout)
assert not any(x in nm.stdout for x in ('ScanWork','PhaseWork','scanMode','scanWork','resetPhaseWork'))
prior=json.loads((root/'build-ci/073-candidate-evidence-v3/identities.json').read_text())
proof={name:expected for name,expected in prior.items() if '/demonstrator/candidate-scan-experiment/' in name}
assert proof
for name,expected in proof.items():assert digest(Path(name))==expected,name
manifest=root/'specs/073-rendering-architecture/evidence/candidate-scan-experiment/archives.json'
for name,r in json.loads(manifest.read_text())['archives'].items():assert digest(manifest.parent/name)==r['sha256']
(out/'clean-audit.json').write_text(json.dumps(dict(changedBaselineFiles=sorted(changed),sourceDiagnosticTokens=False,symbolDiagnosticTokens=False,command=cmd,provenSourcesUnchanged=proof,proofArchiveManifestSha256=digest(manifest)),indent=2)+'\n')
(out/'tooling-regressions.json').write_text(json.dumps(dict(results=[dict(command='python3 specs/073-rendering-architecture/demonstrator/'+name,passed=passed,skipped=skipped) for name,passed,skipped in [('candidate-scan-implementation/test_harness.py',4,0),('performance-experiment/test_recovery.py',9,0),('performance-experiment/test_performance.py',8,0),('runtime-comparison/test_runtime.py',11,0),('ownership-experiment/test_verification.py',4,0),('ownership-experiment/test_ownership.py',4,1)]],skipReason='Optional attribution test uses the prior ownership experiment 48-process schema.'),indent=2)+'\n')
print('Clean source/symbol audit and immutable proof checks passed')
