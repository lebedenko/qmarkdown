from pathlib import Path
import sys,json,shutil
from unittest.mock import patch
root=Path.cwd();driver=root/'specs/073-rendering-architecture/demonstrator/candidate-scan-implementation';sys.path.insert(0,str(driver))
import run as runner
report=runner.module('retained_report',driver/'report.py')
out=root/'build-ci/073-candidate-implementation-evidence-v4';workspace=root/'build-ci/073-candidate-implementation-v4';resumed=root/'build-ci/073-candidate-implementation-resume-validation'
assert runner.recovery.phase_complete(out,'finished')
summary=report.report(out)
(out/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in runner.recovery.rows(out/'index.jsonl'):
 rows=runner.old.strict_rows(out/r['raw'])
 for row in rows:
  assert len(row['counters'])==len(row['geometry'])==len(row['shapeDeltas'])
  if r['mode']=='clean':continue
  for c in row['counters']:
   s=c['scan']
   assert s['scratchBytes']==s['scratchCapacity']*32
   assert s['guardVisits'] in (0,1)
   if r['variant']=='zero':assert s['guardVisits']==0
   if s['preprocessing']:assert s['guardVisits']==1
with runner.recovery.execution_lock(root/'build-ci/073-performance-recovery/execution.lock'):
 with patch.object(runner.supervisor,'supervise',side_effect=AssertionError('resume launched child')),patch.object(runner.old,'run_command',side_effect=AssertionError('resume launched command')):
  records=runner.resume(out,resumed)
  runner.execute(workspace,resumed,records)
assert len(records)==96
for name in ('build-commands.jsonl','execution-commands.jsonl','gate-commands.jsonl','index.jsonl'):
 assert (out/name).read_bytes()==(resumed/name).read_bytes()
(out/'resume-validation.json').write_text(json.dumps(dict(destination=str(resumed),records=len(records),processLaunches=0,unchangedJournals=['build-commands.jsonl','execution-commands.jsonl','gate-commands.jsonl','index.jsonl'],assertions='child supervisor and command launcher replaced with fatal sentinels'),indent=2)+'\n')
history=out/'preparation-history';history.mkdir()
for v in (1,2,3):
 prior=root/f'build-ci/073-candidate-implementation-evidence-v{v}'
 shutil.copytree(prior,history/prior.name)
 shutil.copy2(f'/tmp/073-retained-v{v}.log',history/f'073-retained-v{v}.log')
for name in ('073-retained-v4.log','073-retained-audit.py','073-retained-postverify.py','create_retained.py','setup_retained.py','refine_retained.py','generate_retained.py'):
 shutil.copy2('/tmp/'+name,history/name)
print(json.dumps({k:v for k,v in summary.items() if k!='work'},indent=2))
for case in ('long-480-16384','spans-480-32'):
 for mode in ('oracle','prototype'):
  print(next(r for r in summary['work'] if (r['case'],r['variant'],r['mode'],r['phase'])==(case,'padded',mode,'initial')))
