// Copyright 2019 Google LLC
#include "modules/skparagraph/src/ParagraphImpl.h"
#include "modules/skparagraph/src/TextWrapper.h"
#include "modules/skparagraph/src/ScanBound.h"
#include <stdexcept>

#include "include/core/SkFont.h"
#include "include/private/SkTemplates.h"

namespace skia {
namespace textlayout {

namespace {
// The width of the hyphen drawn when the line breaks after cluster, or 0 if none is drawn.
// A soft hyphen that ends the text never breaks a line
SkScalar softHyphenWidth(const SkString* softHyphen, const Cluster* cluster) {
    if (softHyphen == nullptr || !cluster->isSoftHyphen() ||
        cluster->textRange().end >= cluster->owner()->text().size()) {
        return 0;
    }
    const SkFont& font = cluster->run().font();
    skia_private::AutoSTArray<8, SkGlyphID> glyphs(softHyphen->size());
    size_t glyphCount = font.textToGlyphs(
            softHyphen->c_str(), softHyphen->size(), SkTextEncoding::kUTF8, glyphs);
    bool resolved = glyphCount > 0;
    for (size_t i = 0; i < glyphCount; ++i) {
        if (glyphs[i] == 0) {
            resolved = false;
            break;
        }
    }
    if (resolved) {
        return font.measureText(softHyphen->c_str(), softHyphen->size(), SkTextEncoding::kUTF8);
    }
    // When the cluster's font lacks a glyph for the hyphen string, shape with font fallback
    // matching TextLine::createSoftHyphen so reserved and intrinsic widths match the drawn hyphen
    ParagraphImpl* owner = cluster->owner();
    auto hyphenRun = TextLine::ShapeString(
            owner, owner->findAllBlocks(cluster->textRange()), *softHyphen, cluster);
    return hyphenRun ? hyphenRun->advance().fX : 0;
}

struct LineBreakerWithLittleRounding {
    LineBreakerWithLittleRounding(SkScalar maxWidth, bool applyRoundingHack)
        : fLower(maxWidth - 0.25f)
        , fMaxWidth(maxWidth)
        , fUpper(maxWidth + 0.25f)
        , fApplyRoundingHack(applyRoundingHack) {}

    bool breakLine(SkScalar width) const {
        if (width < fLower) {
            return false;
        } else if (width > fUpper) {
            return true;
        }

        auto val = std::fabs(width);
        SkScalar roundedWidth;
        if (fApplyRoundingHack) {
            if (val < 10000) {
                roundedWidth = SkScalarRoundToScalar(width * 100) * (1.0f/100);
            } else if (val < 100000) {
                roundedWidth = SkScalarRoundToScalar(width *  10) * (1.0f/10);
            } else {
                roundedWidth = SkScalarFloorToScalar(width);
            }
        } else {
            if (val < 10000) {
                roundedWidth = SkScalarFloorToScalar(width * 100) * (1.0f/100);
            } else if (val < 100000) {
                roundedWidth = SkScalarFloorToScalar(width *  10) * (1.0f/10);
            } else {
                roundedWidth = SkScalarFloorToScalar(width);
            }
        }
        return roundedWidth > fMaxWidth;
    }

    const SkScalar fLower, fMaxWidth, fUpper;
    const bool fApplyRoundingHack;
};
}  // namespace

// Since we allow cluster clipping when they don't fit
// we have to work with stretches - parts of clusters
void TextWrapper::lookAhead(SkScalar maxWidth,
                            Cluster* endOfClusters,
                            bool applyRoundingHack,
                            const SkString* softHyphen,
                            bool lineMayEllipsize) {

    reset();
    fEndLine.metrics().clean();
    fWords.startFrom(fEndLine.startCluster(), fEndLine.startPos());
    fClusters.startFrom(fEndLine.startCluster(), fEndLine.startPos());
    fClip.startFrom(fEndLine.startCluster(), fEndLine.startPos());

    LineBreakerWithLittleRounding breaker(maxWidth, applyRoundingHack);
    Cluster* nextNonBreakingSpace = nullptr;
    // A line that breaks at a soft hyphen also draws the hyphen, so that break only fits if the
    // hyphen does too. When the last break opportunity is a soft hyphen that doesn't fit with its
    // hyphen, remember the words before it: if the line has to end there, end it before instead.
    // (Like browsers, keep the soft hyphen break if there's no earlier opportunity on the line.)
    bool softHyphenBreakTooWide = false;
    TextStretch wordsBeforeSoftHyphen;
    bool brokeForWidth = false;
    for (auto cluster = fEndLine.endCluster(); cluster < endOfClusters; ++cluster) {
        if (cluster->isHardBreak()) {
        } else if (
                // TODO: Trying to deal with flutter rounding problem. Must be removed...
                SkScalar width = fWords.width() + fClusters.width() + cluster->width();
                breaker.breakLine(width)) {
            if (cluster->isWhitespaceBreak()) {
                // It's the end of the word
                fClusters.extend(cluster);
                fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, this->getClustersTrimmedWidth());
                fWords.extend(fClusters);
                softHyphenBreakTooWide = false;
                continue;
            } else if (cluster->run().isPlaceholder()) {
                if (!fClusters.empty()) {
                    // Placeholder ends the previous word
                    fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, this->getClustersTrimmedWidth());
                    fWords.extend(fClusters);
                    softHyphenBreakTooWide = false;
                }

                if (cluster->width() > maxWidth && fWords.empty()) {
                    // Placeholder is the only text and it's longer than the line;
                    // it does not count in fMinIntrinsicWidth
                    fClusters.extend(cluster);
                    fTooLongCluster = true;
                    fTooLongWord = true;
                } else {
                    // Placeholder does not fit the line; it will be considered again on the next line
                }
                brokeForWidth = true;
                break;
            }

            // Walk further to see if there is a too long word, cluster or glyph
            SkScalar nextWordLength = fClusters.width();
            SkScalar nextShortWordLength = nextWordLength;
            SkScalar nextWordHyphenWidth = 0;
            auto addWidth = [maxWidth](SkScalar length, const Cluster* c) {
                // This is a tricky flutter case: layout(width:0) places 1 cluster on each line
                return maxWidth == 0 ? std::max(length, c->width()) : length + c->width();
            };
            // A force-broken word that goes on past this line gives the same walk again from a
            // later cluster. When that walk can only be shorter, its result is already counted in
            // fMinIntrinsicWidth (with the hyphen), so reuse the earlier one: this keeps long words
            // linear
            bool sameWord =
                    fWordEnd && fWords.empty() && cluster >= fWordFrom && cluster < fWordEnd;
            if (sameWord) {
                for (; fWordFrom < cluster; ++fWordFrom) {
                    fWordFromLength = addWidth(fWordFromLength, fWordFrom);
                }
                // The walk from here is at least this long, so it is too long for the line too
                sameWord = nextWordLength <= fWordFromLength &&
                           addWidth(nextWordLength, cluster) > maxWidth;
            }
            if (sameWord) {
                nextWordLength = fWordLength;
            } else {
                fWordFrom = cluster;
                fWordFromLength = nextWordLength;
            }
            // Only reuse a walk with no intra-word breaks and no negative widths
            bool reusable = true;
            auto further = sameWord ? endOfClusters : cluster;
            for (; further != endOfClusters; ++further) {
                if (further->isHardBreak() || further->isWhitespaceBreak()) {
                    break;
                }
                if (further->isSoftBreak() && !further->isSoftHyphen()) {
                    // Other soft breaks, such as the end of the text, end the word before this
                    // cluster; only a soft hyphen's own (letter-spaced) width counts here
                    break;
                }
                if (further->run().isPlaceholder()) {
                  // Placeholder ends the word
                  break;
                }

                reusable &= !further->isIntraWordBreak() && further->width() >= 0;
                if (nextWordLength > 0 && nextWordLength <= maxWidth && further->isIntraWordBreak()) {
                    // The cluster is spaces but not the end of the word in a normal sense
                    nextNonBreakingSpace = further;
                    nextShortWordLength = nextWordLength;
                }

                nextWordLength = addWidth(nextWordLength, further);
                if (maxWidth > 0 && further->isSoftBreak()) {
                    // Include further->width() before stopping so letter-spaced soft hyphens count
                    nextWordHyphenWidth = softHyphenWidth(softHyphen, further);
                    break;
                }
            }
            if (!sameWord) {
                fWordEnd = reusable ? further : nullptr;
                fWordLength = nextWordLength;
            }
            if (nextWordLength > maxWidth) {
                if (nextNonBreakingSpace != nullptr) {
                    // We only get here if the non-breaking space improves our situation
                    // (allows us to break the text to fit the word)
                    if (SkScalar shortLength = fWords.width() + nextShortWordLength;
                        !breaker.breakLine(shortLength)) {
                        // We can add the short word to the existing line
                        fClusters = TextStretch(fClusters.startCluster(), nextNonBreakingSpace, fClusters.metrics().getForceStrut());
                        fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, nextShortWordLength);
                        fWords.extend(fClusters);
                        softHyphenBreakTooWide = false;
                    } else {
                        // We can place the short word on the next line
                        fClusters.clean();
                    }
                    // Either way we are not in "word is too long" situation anymore
                    brokeForWidth = true;
                    break;
                }
                // If the word is too long we can break it right now and hope it's enough
                fMinIntrinsicWidth =
                        std::max(fMinIntrinsicWidth, nextWordLength + nextWordHyphenWidth);
                if (fClusters.endPos() - fClusters.startPos() > 1 ||
                    fWords.empty()) {
                    fTooLongWord = true;
                } else {
                    // Even if the word is too long there is a very little space on this line.
                    // let's deal with it on the next line.
                }
            } else {
                // Record the hyphenated word width even when nextWordLength <= maxWidth so a word
                // pushed to the next line or cut off by maxLines still counts in fMinIntrinsicWidth
                fMinIntrinsicWidth =
                        std::max(fMinIntrinsicWidth, nextWordLength + nextWordHyphenWidth);
            }

            if (cluster->width() > maxWidth) {
                fClusters.extend(cluster);
                fTooLongCluster = true;
                fTooLongWord = true;
            }
            brokeForWidth = true;
            break;
        }

        if (cluster->run().isPlaceholder()) {
            if (!fClusters.empty()) {
                // Placeholder ends the previous word (placeholders are ignored in trimming)
                fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, getClustersTrimmedWidth());
                fWords.extend(fClusters);
            }

            // Placeholder is separate word and its width now is counted in minIntrinsicWidth
            fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, cluster->width());
            fWords.extend(cluster);
            softHyphenBreakTooWide = false;
        } else {
            fClusters.extend(cluster);

            // Keep adding clusters/words
            if (fClusters.endOfWord()) {
                // A word that ends at a soft hyphen is drawn with a hyphen when the line breaks
                // there, so the hyphen counts in its width (as in CSS min-content)
                SkScalar hyphenWidth = softHyphenWidth(softHyphen, cluster);
                fMinIntrinsicWidth =
                        std::max(fMinIntrinsicWidth, getClustersTrimmedWidth() + hyphenWidth);
                bool tooWide = hyphenWidth > 0 && !lineMayEllipsize && !fWords.empty() &&
                               breaker.breakLine(fWords.width() + fClusters.width() + hyphenWidth);
                if (tooWide && !softHyphenBreakTooWide) {
                    // Keep the last break that fits, even past several soft hyphens that don't.
                    wordsBeforeSoftHyphen = fWords;
                }
                softHyphenBreakTooWide = tooWide;
                fWords.extend(fClusters);
            }
        }

        if ((fHardLineBreak = cluster->isHardBreak())) {
            // Stop at the hard line break
            break;
        }
    }

    if (brokeForWidth && softHyphenBreakTooWide && !fTooLongWord) {
        fWords = wordsBeforeSoftHyphen;
        fClusters.clean();
    }
}

void TextWrapper::moveForward(bool hasEllipsis) {

    // We normally break lines by words.
    // The only way we may go to clusters is if the word is too long or
    // it's the first word and it has an ellipsis attached to it.
    // If nothing fits we show the clipping.
    if (!fWords.empty()) {
        fEndLine.extend(fWords);
#ifdef SK_IGNORE_SKPARAGRAPH_ELLIPSIS_FIX
        if (!fTooLongWord || hasEllipsis) { // Ellipsis added to a word
#else
        if (!fTooLongWord && !hasEllipsis) { // Ellipsis added to a grapheme
#endif
            return;
        }
    }
    if (!fClusters.empty()) {
        fEndLine.extend(fClusters);
        if (!fTooLongCluster) {
            return;
        }
    }

    if (!fClip.empty()) {
        // Flutter: forget the clipped cluster but keep the metrics
        fEndLine.metrics().add(fClip.metrics());
    }
}

// Special case for start/end cluster since they can be clipped
void TextWrapper::trimEndSpaces(TextAlign align) {
    // Remember the breaking position
    fEndLine.saveBreak();
    // Skip all space cluster at the end
    for (auto cluster = fEndLine.endCluster();
         cluster >= fEndLine.startCluster() && cluster->isWhitespaceBreak();
         --cluster) {
        fEndLine.trim(cluster);
    }
    fEndLine.trim();
}

SkScalar TextWrapper::getClustersTrimmedWidth() {
    // Move the end of the line to the left
    SkScalar width = 0;
    bool trailingSpaces = true;
    for (auto cluster = fClusters.endCluster(); cluster >= fClusters.startCluster(); --cluster) {
        if (cluster->run().isPlaceholder()) {
            continue;
        }
        if (trailingSpaces) {
            if (!cluster->isWhitespaceBreak()) {
                width += cluster->trimmedWidth(cluster->endPos());
                trailingSpaces = false;
            }
            continue;
        }
        width += cluster->width();
    }
    return width;
}

// Trim the beginning spaces in case of soft line break
std::tuple<Cluster*, size_t, SkScalar> TextWrapper::trimStartSpaces(Cluster* endOfClusters) {

    if (fHardLineBreak) {
        // End of line is always end of cluster, but need to skip \n
        auto width = fEndLine.width();
        auto cluster = fEndLine.endCluster() + 1;
        while (cluster < fEndLine.breakCluster() && cluster->isWhitespaceBreak())  {
            width += cluster->width();
            ++cluster;
        }
        return std::make_tuple(fEndLine.breakCluster() + 1, 0, width);
    }

    // breakCluster points to the end of the line;
    // It's a soft line break so we need to move lineStart forward skipping all the spaces
    auto width = fEndLine.widthWithGhostSpaces();
    auto cluster = fEndLine.breakCluster() + 1;
    while (cluster < endOfClusters && cluster->isWhitespaceBreak()) {
        width += cluster->width();
        ++cluster;
    }

    if (fEndLine.breakCluster()->isWhitespaceBreak() && fEndLine.breakCluster() < endOfClusters) {
        // In case of a soft line break by the whitespace
        // fBreak should point to the beginning of the next line
        // (it only matters when there are trailing spaces)
        fEndLine.shiftBreak();
    }

    return std::make_tuple(cluster, 0, width);
}

// TODO: refactor the code for line ending (with/without ellipsis)
void TextWrapper::breakTextIntoLines(ParagraphImpl* parent,
                                     SkScalar maxWidth,
                                     const AddLineToParagraph& addLine) {
    fHeight = 0;
    fMinIntrinsicWidth = std::numeric_limits<SkScalar>::min();
    fMaxIntrinsicWidth = std::numeric_limits<SkScalar>::min();

    auto span = parent->clusters();
    if (span.empty()) {
        return;
    }
    auto maxLines = parent->paragraphStyle().getMaxLines();
    auto align = parent->paragraphStyle().effective_align();
    auto unlimitedLines = maxLines == std::numeric_limits<size_t>::max();
    auto endlessLine = !SkIsFinite(maxWidth);
    auto hasEllipsis = parent->paragraphStyle().ellipsized();
    const SkString* softHyphen = nullptr;
    if (parent->paragraphStyle().getRenderSoftHyphens() &&
        !parent->paragraphStyle().getSoftHyphenString().isEmpty()) {
        softHyphen = &parent->paragraphStyle().getSoftHyphenString();
    }

    auto disableFirstAscent = parent->paragraphStyle().getTextHeightBehavior() & TextHeightBehavior::kDisableFirstAscent;
    auto disableLastDescent = parent->paragraphStyle().getTextHeightBehavior() & TextHeightBehavior::kDisableLastDescent;
    bool firstLine = true; // We only interested in fist line if we have to disable the first ascent

    SkScalar softLineMaxIntrinsicWidth = 0;
    fEndLine = TextStretch(span.data(), span.data(), parent->strutForceHeight());
    auto start = span.data();
    auto end = start + span.size() - 1;
    InternalLineMetrics maxRunMetrics;
    bool needEllipsis = false;
    struct Candidate { Cluster* end; Cluster* trimmedEnd; SkScalar trimmed, lower; bool eligible; };
    std::vector<Candidate> scratch; // Layout-local, released after wrapping.
    auto guard = scan_bound::platform<SkScalar>();
    SkScalar maxPad=0;
    if (!scan_bound::finite(maxWidth)) guard=scan_bound::width;
    for (const auto& s : parent->experimentalSpans()) {
        if (!scan_bound::finite(s.horizontalPadding) || s.horizontalPadding < 0) guard=scan_bound::padding;
        else maxPad=std::max(maxPad,s.horizontalPadding);
    }
    // Conservative envelope keeps every slice sum and required addition finite.
    // Each run emits at most one slice; at most two pads per slice. Factor four
    // slack covers rounding even for the largest representable vector size.
    const long double padEnvelope=4.L*maxPad*(parent->runs().size()+1.L);
    if (padEnvelope > std::numeric_limits<SkScalar>::max()/4.L) guard=scan_bound::intermediate;
    if (parent->experimentalPadded() && parent->scanMode && guard==scan_bound::safe) {
        scratch.reserve(span.size());
        parent->scanWork.scratchCapacity=scratch.capacity();
        parent->scanWork.scratchBytes=scratch.capacity()*sizeof(Candidate);
        if (scratch.capacity()>span.size()) throw std::runtime_error("scratch capacity exceeds paragraph");
    }
    while (fEndLine.endCluster() != end) {

        auto lastLine = (hasEllipsis && unlimitedLines) || fLineNumber >= maxLines;
        needEllipsis = hasEllipsis && !endlessLine && lastLine;

        auto fittingWidth = maxWidth;
        Cluster* selectedEnd = end;
        bool emergencyEnd = false;
        auto lineStart = fEndLine.endCluster();
        if (parent->experimentalPadded()) {
            // Finite endpoint scan. Visual fragment costs need not be monotonic.
            // Bound the existing breaker by an upstream cluster endpoint. It
            // retains word stretches, trimming, metrics and emergency handling.
            SkScalar bare = 0;
            Cluster* legalEnd = nullptr;
            Cluster* fallbackEnd = nullptr;
            Cluster* firstUnitEnd = nullptr;
            auto reason=guard;
            scratch.clear();
            if (parent->scanMode && reason==scan_bound::safe) {
                SkScalar sum=0;
                for (auto c=lineStart; c<end; ++c) {
                    ++parent->scanWork.preprocessing;
                    sum += c->width();
                    if (!scan_bound::finite(c->width()) || !scan_bound::finite(sum)) reason=scan_bound::intermediate;
                    auto t=c+1;
                    SkScalar trimmed=sum;
                    while (t>lineStart && (t-1)->isWhitespaceBreak()) {
                        ++parent->scanWork.trimming;
                        --t; trimmed -= t->width();
                        if (!scan_bound::finite(trimmed)) reason=scan_bound::intermediate;
                    }
                    if (!scan_bound::finite(trimmed) ||
                        std::abs(static_cast<long double>(trimmed)) + padEnvelope >
                            std::numeric_limits<SkScalar>::max()/2.L) reason=scan_bound::intermediate;
                    const auto& edges=parent->fExperimentalGraphemeEdges;
                    bool eligible=std::binary_search(edges.begin(),edges.end(),c->textRange().end);
                    if (eligible && !firstUnitEnd) firstUnitEnd=c+1;
                    scratch.push_back({c+1,t,trimmed,trimmed,eligible});
                    if (c->isHardBreak()) break;
                }
                parent->scanWork.scratchSize=std::max(parent->scanWork.scratchSize,scratch.size());
                if (reason==scan_bound::safe) {
                    scan_bound::suffix(scratch);
                    parent->scanWork.suffixComparisons+=scratch.empty()?0:scratch.size()-1;
                }
            }
            ++parent->scanWork.lines;
            if (parent->scanMode && reason!=scan_bound::safe) ++parent->scanWork.fallback[reason];
            if (parent->scanMode==2 && reason==scan_bound::safe) {
                for (size_t i=0;i<scratch.size();++i) {
                    if (scan_bound::skip(scratch[i].lower,maxWidth)) {
                        parent->scanWork.skipped+=scratch.size()-i;
                        break;
                    }
                    const auto& e=scratch[i];
                    ++parent->phaseCandidates;
                    ++parent->scanWork.evaluations;
                    TextRange range(lineStart->textRange().start,
                        e.trimmedEnd>lineStart ? (e.trimmedEnd-1)->textRange().end : lineStart->textRange().start);
                    parent->phaseFitting=true;
                    auto required=e.trimmed+parent->experimentalPadding(range);
                    parent->phaseFitting=false;
                    if (!scan_bound::finite(required)) throw std::runtime_error("cutoff-proof nonfinite required");
                    if (required<=maxWidth && e.eligible) {
                        fallbackEnd=e.end;
                        if ((e.end-1)->isSoftBreak() || (e.end-1)->isHardBreak() || e.end==end) legalEnd=e.end;
                    }
                }
            } else {
            for (auto candidate = lineStart; candidate < end; ++candidate) {
                ++parent->phaseCandidates;
                bare += candidate->width();
                auto trimmedEnd = candidate + 1;
                SkScalar trimmedWidth = bare;
                while (trimmedEnd > lineStart && (trimmedEnd-1)->isWhitespaceBreak()) {
                    ++parent->phaseWhitespace;
                    --trimmedEnd;
                    trimmedWidth -= trimmedEnd->width();
                }
                TextRange range(lineStart->textRange().start,
                    trimmedEnd > lineStart ? (trimmedEnd-1)->textRange().end : lineStart->textRange().start);
                ++parent->scanWork.evaluations;
                parent->phaseFitting = true;
                auto required = trimmedWidth + parent->experimentalPadding(range);
                parent->phaseFitting = false;
                const auto& edges = parent->fExperimentalGraphemeEdges;
                const bool indivisibleEnd = std::binary_search(edges.begin(), edges.end(), candidate->textRange().end);
                if (indivisibleEnd && !firstUnitEnd) firstUnitEnd = candidate+1;
                if (required <= maxWidth && indivisibleEnd) {
                    fallbackEnd = candidate+1;
                    if (candidate->isSoftBreak() || candidate->isHardBreak() || candidate+1 == end)
                        legalEnd = candidate+1;
                }
                if (candidate->isHardBreak()) break;
            }
            }
            if (parent->scanMode==1 && reason==scan_bound::safe) {
                bool skipping=false;
                for (const auto& e:scratch) {
                    skipping=skipping || scan_bound::skip(e.lower,maxWidth);
                    if (!skipping) continue;
                    ++parent->scanWork.skipped;
                    ++parent->scanWork.shadowChecks;
                    TextRange range(lineStart->textRange().start,
                        e.trimmedEnd>lineStart ? (e.trimmedEnd-1)->textRange().end : lineStart->textRange().start);
                    auto saved0=parent->phaseWork[0];auto saved1=parent->phaseWork[1];
                    auto savedLookups=parent->ownerLookups;
                    auto required=e.trimmed+parent->experimentalPadding(range);
                    parent->phaseWork[0]=saved0;parent->phaseWork[1]=saved1;parent->ownerLookups=savedLookups;
                    if (!scan_bound::finite(required) || !(required>maxWidth))
                        throw std::runtime_error("cutoff-proof shadow failure");
                }
            }
            selectedEnd = legalEnd ? legalEnd : (fallbackEnd ? fallbackEnd : (firstUnitEnd ? firstUnitEnd : end));
            emergencyEnd = legalEnd == nullptr;
            // Bound the existing scan by source endpoint, not a synthetic width:
            // otherwise an oversized next cluster can be appended to prior words.
            fittingWidth = std::numeric_limits<SkScalar>::max();
        }
        this->lookAhead(fittingWidth, selectedEnd, parent->getApplyRoundingHack(), softHyphen, needEllipsis);
        if (parent->experimentalPadded() && emergencyEnd) fTooLongWord = true;

        this->moveForward(needEllipsis);
        needEllipsis &= fEndLine.endCluster() < end - 1; // Only if we have some text to ellipsize

        // Do not trim end spaces on the naturally last line of the left aligned text
        this->trimEndSpaces(align);

        // For soft line breaks add to the line all the spaces next to it
        Cluster* startLine;
        size_t pos;
        SkScalar widthWithSpaces;
        std::tie(startLine, pos, widthWithSpaces) = this->trimStartSpaces(end);

        if (needEllipsis && !fHardLineBreak) {
            // This is what we need to do to preserve a space before the ellipsis
            fEndLine.restoreBreak();
            widthWithSpaces = fEndLine.widthWithGhostSpaces();
        }

        // If the line is empty with the hard line break, let's take the paragraph font (flutter???)
        if (fEndLine.metrics().isClean()) {
            fEndLine.setMetrics(parent->getEmptyMetrics());
        }

        // Deal with placeholder clusters == runs[@size==1]
        Run* lastRun = nullptr;
        for (auto cluster = fEndLine.startCluster(); cluster <= fEndLine.endCluster(); ++cluster) {
            auto r = cluster->runOrNull();
            if (r == lastRun) {
                continue;
            }
            lastRun = r;
            if (lastRun->placeholderStyle() != nullptr) {
                SkASSERT(lastRun->size() == 1);
                // Update the placeholder metrics so we can get the placeholder positions later
                // and the line metrics (to make sure the placeholder fits)
                lastRun->updateMetrics(&fEndLine.metrics());
            }
        }

        // Before we update the line metrics with struts,
        // let's save it for GetRectsForRange(RectHeightStyle::kMax)
        maxRunMetrics = fEndLine.metrics();
        maxRunMetrics.fForceStrut = false;

        // TODO: keep start/end/break info for text and runs but in a better way that below
        TextRange textExcludingSpaces(fEndLine.startCluster()->textRange().start, fEndLine.endCluster()->textRange().end);
        TextRange text(fEndLine.startCluster()->textRange().start, fEndLine.breakCluster()->textRange().start);
        TextRange textIncludingNewlines(fEndLine.startCluster()->textRange().start, startLine->textRange().start);
        if (startLine == end) {
            textIncludingNewlines.end = parent->text().size();
            text.end = parent->text().size();
        }
        ClusterRange clusters(fEndLine.startCluster() - start, fEndLine.endCluster() - start + 1);
        ClusterRange clustersWithGhosts(fEndLine.startCluster() - start, startLine - start);

        if (disableFirstAscent && firstLine) {
            fEndLine.metrics().fAscent = fEndLine.metrics().fRawAscent;
        }
        if (disableLastDescent && (lastLine || (startLine == end && !fHardLineBreak ))) {
            fEndLine.metrics().fDescent = fEndLine.metrics().fRawDescent;
        }

        if (parent->strutEnabled()) {
            // Make sure font metrics are not less than the strut
            parent->strutMetrics().updateLineMetrics(fEndLine.metrics());
        }

        if (parent->experimentalPadded()) {
            auto pad = parent->experimentalVerticalPadding(textExcludingSpaces);
            auto& metrics = fEndLine.metrics();
            // Integral baseline and total extent avoid negative rounding delta.
            auto baseline = std::ceil(metrics.baseline() + pad);
            auto descent = std::ceil(metrics.descent() + metrics.leading()/2 + pad);
            metrics.fAscent = -baseline;
            metrics.fDescent = descent;
            metrics.fLeading = 0;
        }
        SkScalar lineHeight = fEndLine.metrics().height();
        firstLine = false;

        if (fEndLine.empty()) {
            // Correct text and clusters (make it empty for an empty line)
            textExcludingSpaces.end = textExcludingSpaces.start;
            clusters.end = clusters.start;
        }

        // In case of a force wrapping we don't have a break cluster and have to use the end cluster
        text.end = std::max(text.end, textExcludingSpaces.end);

        addLine(textExcludingSpaces,
                text,
                textIncludingNewlines, clusters, clustersWithGhosts, widthWithSpaces,
                fEndLine.startPos(),
                fEndLine.endPos(),
                SkVector::Make(0, fHeight),
                SkVector::Make(fEndLine.width(), lineHeight),
                fEndLine.metrics(),
                needEllipsis && !fHardLineBreak);

        softLineMaxIntrinsicWidth += widthWithSpaces;

        fMaxIntrinsicWidth = std::max(fMaxIntrinsicWidth, softLineMaxIntrinsicWidth);
        if (fHardLineBreak) {
            softLineMaxIntrinsicWidth = 0;
        }
        if (parent->experimentalPadded() && startLine <= lineStart) {
            SK_ABORT("experimental line failed monotonic source progress");
        }
        // Start a new line
        fHeight += lineHeight;
        if (!fHardLineBreak || startLine != end) {
            fEndLine.clean();
        }
        fEndLine.startFrom(startLine, pos);
        parent->fMaxWidthWithTrailingSpaces = std::max(parent->fMaxWidthWithTrailingSpaces, widthWithSpaces);

        if (hasEllipsis && unlimitedLines) {
            // There is one case when we need an ellipsis on a separate line
            // after a line break when width is infinite
            if (!fHardLineBreak) {
                break;
            }
        } else if (lastLine) {
            // There is nothing more to draw
            fHardLineBreak = false;
            break;
        }

        ++fLineNumber;
    }

    // We finished formatting the text but we need to scan the rest for some numbers
    // TODO: make it a case of a normal flow
    if (fEndLine.endCluster() != nullptr) {
        auto lastWordLength = 0.0f;
        auto cluster = fEndLine.endCluster();
        while (cluster != end || cluster->endPos() < end->endPos()) {
            fExceededMaxLines = true;
            if (cluster->isHardBreak()) {
                // Hard line break ends the word and the line
                fMaxIntrinsicWidth = std::max(fMaxIntrinsicWidth, softLineMaxIntrinsicWidth);
                softLineMaxIntrinsicWidth = 0;
                fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, lastWordLength);
                lastWordLength = 0;
            } else if (cluster->isWhitespaceBreak()) {
                // Whitespaces end the word
                softLineMaxIntrinsicWidth += cluster->width();
                fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, lastWordLength);
                lastWordLength = 0;
            } else if (cluster->run().isPlaceholder()) {
                // Placeholder ends the previous word and creates a separate one
                fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, lastWordLength);
                // Placeholder width now counts in fMinIntrinsicWidth
                softLineMaxIntrinsicWidth += cluster->width();
                fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, cluster->width());
                lastWordLength = 0;
            } else {
                // Nothing out of ordinary - just add this cluster to the word and to the line
                softLineMaxIntrinsicWidth += cluster->width();
                lastWordLength += cluster->width();
                if (cluster->isSoftBreak()) {
                    // Words after maxLines also split at soft breaks and include any drawn hyphen
                    fMinIntrinsicWidth =
                            std::max(fMinIntrinsicWidth,
                                     lastWordLength + softHyphenWidth(softHyphen, cluster));
                    lastWordLength = 0;
                }
            }
            ++cluster;
        }
        fMinIntrinsicWidth = std::max(fMinIntrinsicWidth, lastWordLength);
        fMaxIntrinsicWidth = std::max(fMaxIntrinsicWidth, softLineMaxIntrinsicWidth);

        if (parent->lines().empty()) {
            // In case we could not place even a single cluster on the line
            if (disableFirstAscent) {
                fEndLine.metrics().fAscent = fEndLine.metrics().fRawAscent;
            }
            if (disableLastDescent && !fHardLineBreak) {
                fEndLine.metrics().fDescent = fEndLine.metrics().fRawDescent;
            }
            fHeight = std::max(fHeight, fEndLine.metrics().height());
        }
    }

    if (fHardLineBreak) {
        if (disableLastDescent) {
            fEndLine.metrics().fDescent = fEndLine.metrics().fRawDescent;
        }

        // Last character is a line break
        if (parent->strutEnabled()) {
            // Make sure font metrics are not less than the strut
            parent->strutMetrics().updateLineMetrics(fEndLine.metrics());
        }

        ClusterRange clusters(fEndLine.breakCluster() - start, fEndLine.endCluster() - start);
        addLine(fEndLine.breakCluster()->textRange(),
                fEndLine.breakCluster()->textRange(),
                fEndLine.endCluster()->textRange(),
                clusters,
                clusters,
                0,
                0,
                0,
                SkVector::Make(0, fHeight),
                SkVector::Make(0, fEndLine.metrics().height()),
                fEndLine.metrics(),
                needEllipsis);
        fHeight += fEndLine.metrics().height();
        parent->lines().back().setMaxRunMetrics(maxRunMetrics);
    }

    if (parent->lines().empty()) {
        return;
    }
    // Correct line metric styles for the first and for the last lines if needed
    if (disableFirstAscent) {
        parent->lines().front().setAscentStyle(LineMetricStyle::Typographic);
    }
    if (disableLastDescent) {
        parent->lines().back().setDescentStyle(LineMetricStyle::Typographic);
    }
}

}  // namespace textlayout
}  // namespace skia
