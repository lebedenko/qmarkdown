import sys,json,tempfile
from pathlib import Path
sys.path.insert(0,str(Path('specs/073-rendering-architecture/demonstrator/candidate-scan-batching-refinement').resolve()))
import run as p
import package
with p.a.no_launches(), tempfile.TemporaryDirectory() as tmp:
 t=Path(tmp);out=t/'out';out.mkdir()
 p.write(out/'identities.json',{})
 (out/'attempts.jsonl').write_text('{"id":"ambiguous"}\n')
 (out/'index.jsonl').write_text('{partial')
 (out/'partial.stderr').write_text('preserved partial error')
 package.package(out,t/'archive')
 assert json.loads((t/'archive/selection.json').read_text())['complete'] is False
 assert json.loads((t/'archive/selection.json').read_text())['selection'] is None
 source=Path('build-ci/073-candidate-batching-refinement')
 e=next(e for e in p.schedule()['commands'] if e['configuration']=='batch-96-enabled' and e['mode']=='correctness')
 row=p.rows(source/(e['id']+'.jsonl'))[0]
 # Use timing validation to test boundary data without geometry source paths.
 e=dict(e,mode='timing');row['mode']='timing';raw=t/'raw.jsonl'
 for metric in ('processCpuNs','voluntary','involuntary'):
  before=row['boundaryDeltas'][metric]
  row['boundaryDeltas'][metric]=123456789
  raw.write_text(json.dumps(row)+'\n')
  try:p.validate_raw(raw,e,source)
  except (AssertionError,ValueError):pass
  else:raise AssertionError('accepted invalid delta')
  row['boundaryDeltas'][metric]=before
  pre=row['boundaryBefore'][metric]
  row['boundaryBefore'][metric]=dict(value=None,reason='synthetic unavailable')
  row['boundaryDeltas'][metric]=None
  raw.write_text(json.dumps(row)+'\n');p.validate_raw(raw,e,source)
  row['boundaryBefore'][metric]=pre;row['boundaryDeltas'][metric]=before
print('PASS: forensic partial archive read-back, no selection, invalid/optional boundary deltas; zero launches')
